package algorithm.test;

import junit.framework.TestCase;
import algorithm.PrimeChecker;

public class PrimeCheckerTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//<$c>
	public void test$$() {
		PrimeChecker primeChecker0 = new PrimeChecker();
		assertEquals(($_), primeChecker0.isPrime((int) $0));
	}
	//<<case-end>>
}
