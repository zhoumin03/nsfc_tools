package sut;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtrlDepGraph {
	public static final List<String> nodes = new ArrayList<String>();
	public static final List<String> targets = new ArrayList<String>();
	public static final Map<String, List<String>> children = new HashMap<String, List<String>>();
	public static final Map<String, Integer> depth = new HashMap<String, Integer>();
	public static final Map<String, List<String>> path = new HashMap<String, List<String>>();
	
	public static final String ENTRY	= "entry";
	public static final String EXIT 	= "exit";
	public static final String B0 		= "b0";
	public static final String B0P 		= "b0p";
	public static final String B1	 	= "b1";
	public static final String B2	 	= "b2";
	public static final String B3	 	= "b3";
	public static final String B4	 	= "b4";
	public static final String B4P	 	= "b4p";
	public static final String B5	 	= "b5";
	public static final String B5P	 	= "b5p";
	public static final String B6	 	= "b6";
	public static final String S1 		= "s1";
	public static final String S2	 	= "s2";
	public static final String S3 		= "s3";
	public static final String D0	 	= "d0";
	public static final String D1 		= "d1";
	public static final String D2	 	= "d2";
	public static final String D3	 	= "d3";
	public static final String D4	 	= "d4";
	
	static {
		nodes.add(ENTRY);
		children.put(ENTRY, buildList(EXIT, B0));
		depth.put(ENTRY, 0);
		path.put(ENTRY, buildList(ENTRY));

		nodes.add(EXIT);
		children.put(EXIT, buildList());
		depth.put(EXIT, 1);
		path.put(EXIT, buildList(ENTRY, EXIT));

		nodes.add(B0);
		children.put(B0, buildList(B0P, D0));
		depth.put(B0, 1);
		path.put(B0, buildList(ENTRY, B0));
		
		nodes.add(B0P);
		children.put(B0P, buildList(B1, B2, B3, B4));
		depth.put(B0P, 2);
		path.put(B0P, buildList(ENTRY, B0, B0P));

		nodes.add(D0);
		children.put(D0, buildList());
		depth.put(D0, 2);
		path.put(D0, buildList(ENTRY, B0, D0));

		nodes.add(B1);
		children.put(B1, buildList(S1));
		depth.put(B1, 3);
		path.put(B1, buildList(ENTRY, B0, B0P, B1));

		nodes.add(S1);
		children.put(S1, buildList());
		depth.put(S1, 4);
		path.put(S1, buildList(ENTRY, B0, B0P, B1, S1));

		nodes.add(B2);
		children.put(B2, buildList(S2));
		depth.put(B2, 3);
		path.put(B2, buildList(ENTRY, B0, B0P, B2));

		nodes.add(S2);
		children.put(S2, buildList());
		depth.put(S2, 4);
		path.put(S2, buildList(ENTRY, B0, B0P, B2, S2));

		nodes.add(B3);
		children.put(B3, buildList(S3));
		depth.put(B3, 3);
		path.put(B3, buildList(ENTRY, B0, B0P, B3));

		nodes.add(S3);
		children.put(S3, buildList());
		depth.put(S3, 4);
		path.put(S3, buildList(ENTRY, B0, B0P, B3, S3));

		nodes.add(B4);
		children.put(B4, buildList(D1, B4P));
		depth.put(B4, 3);
		path.put(B4, buildList(ENTRY, B0, B0P, B4));

		nodes.add(B4P);
		children.put(B4P, buildList(B5));
		depth.put(B4P, 4);
		path.put(B4P, buildList(ENTRY, B0, B0P, B4, B4P));
		
		nodes.add(D1);
		children.put(D1, buildList());
		depth.put(D1, 4);
		path.put(D1, buildList(ENTRY, B0, B0P, B4, D1));

		nodes.add(B5);
		children.put(B5, buildList(D2, B5P));
		depth.put(B5, 5);
		path.put(B5, buildList(ENTRY, B0, B0P, B4, B4P, B5));

		nodes.add(B5P);
		children.put(B5P, buildList(B6));
		depth.put(B5P, 6);
		path.put(B5P, buildList(ENTRY, B0, B0P, B4, B4P, B5, B5P));
		
		nodes.add(D2);
		children.put(D2, buildList());
		depth.put(D2, 6);
		path.put(D2, buildList(ENTRY, B0, B0P, B4, B4P, B5, D2));

		nodes.add(B6);
		children.put(B6, buildList(D3, D4));
		depth.put(B6, 7);
		path.put(B6, buildList(ENTRY, B0, B0P, B4, B4P, B5, B5P, B6));

		nodes.add(D3);
		children.put(D3, buildList());
		depth.put(D3, 8);
		path.put(D3, buildList(ENTRY, B0, B0P, B4, B4P, B5, B5P, B6, D3));

		nodes.add(D4);
		children.put(D4, buildList());
		depth.put(D4, 8);
		path.put(D4, buildList(ENTRY, B0, B0P, B4, B4P, B5, B5P, B6, D4));
		
		targets.addAll(buildList(D0, S1, S2, S3, D1, D2, D3, D4));
}

	private static List<String> buildList(String... args) {
		List<String> ret = new ArrayList<String>();
		for (String s : args) {
			ret.add(s);
		}
		return ret;
	}
}
