package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;

/**
 * 优化算法的具体实现
 * @author aleck
 *
 */
public interface IOptimizer {
	public void setUp();
	
	public void execute(OptimizeParameter parameter, ProblemWrapper wrapper);
	
	public void tearDown();
}
