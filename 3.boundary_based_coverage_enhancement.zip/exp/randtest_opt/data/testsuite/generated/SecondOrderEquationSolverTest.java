package algorithm.test;

import junit.framework.TestCase;
import algorithm.SecondOrderEquationSolver;
import algorithm.SecondOrderEquationSolver.Result;

public class SecondOrderEquationSolverTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T3_5, T1_3, T5_9]
	public void test00() {
		assertEquals((Result.newAny()), SecondOrderEquationSolver.solve(0.0D, 0.0D, 0.0D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T1_2, T4_7, T7_13]
	public void test01() {
		assertEquals((Result.newTwoDistinct(9.279224221570382E-6, 9.279224221570382E-6)), SecondOrderEquationSolver.solve(53.883611173842525D, -9.999962199E-4D, 0.0D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T1_2, T4_7, T7_13]
	public void test02() {
		assertEquals((Result.newTwoDistinct(-0.0, -0.0)), SecondOrderEquationSolver.solve(0.009998985631D, 0.0D, 0.0D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T1_3, T3_6]
	public void test03() {
		assertEquals((Result.newOne(-0.0)), SecondOrderEquationSolver.solve(0.0D, -0.009998994800000001D, 0.0D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T1_2, T4_7, T7_12]
	public void test04() {
		assertEquals((Result.newNone()), SecondOrderEquationSolver.solve(-0.1100159590461828D, 0.166851828D, -0.085984100085228D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T1_2, T4_8]
	public void test05() {
		assertEquals((Result.newTwoIdentical(-0.0)), SecondOrderEquationSolver.solve(-3.05073917E18D, -0.09999485999999999D, 0.0D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#6, coverages: [T3_5, T1_3, T5_10]
	public void test06() {
		assertEquals((Result.newNone()), SecondOrderEquationSolver.solve(0.0D, 0.0D, 0.00999895108246922D));
	}
	//<<case-end>>
}
