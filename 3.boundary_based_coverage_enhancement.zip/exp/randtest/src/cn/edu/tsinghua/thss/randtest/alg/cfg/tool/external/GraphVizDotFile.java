package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.external;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class GraphVizDotFile {
	private String filename;
	private PrintStream ps;
	
	public GraphVizDotFile(String filename) {
		this.filename = filename;
	}
	
	private boolean openFile() {
		try {
			File file = new File(filename);
			file.getParentFile().mkdirs();
			if (!file.exists())
				file.createNewFile();
			ps = new PrintStream(new FileOutputStream(filename));
			return true;
		} catch (IOException e) {
			return false;
		}
	}
	
	public boolean open() {
		if (!openFile())
			return false;
		ps.println("digraph g {");
		return true;
	}
	
	public void appendLine(String s) {
		ps.print("  ");
		ps.println(s);
	}
	
	public void close() {
		ps.println("}");
		ps.close();
		ps = null;
	}
	
	public boolean isWorking() {
		return (ps == null);
	}
}
