package algorithm.test;

import junit.framework.TestCase;
import algorithm.Newton;

public class NewtonTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//#0, coverages: [T1_2, T7_8, T2_4]
	public void test00() {
		double x = Newton.sqrt(1.0099549303590072D);
		double y = (1.00496513895306);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T1_2, T7_9, T2_4]
	public void test01() {
		double x = Newton.sqrt(1.0D);
		double y = (1.0);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
}
