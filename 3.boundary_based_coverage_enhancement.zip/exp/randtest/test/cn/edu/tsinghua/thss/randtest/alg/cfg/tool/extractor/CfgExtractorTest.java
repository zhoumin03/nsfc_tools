package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor;

public class CfgExtractorTest {
	public static void main(String[] args) {
		
	}
}
