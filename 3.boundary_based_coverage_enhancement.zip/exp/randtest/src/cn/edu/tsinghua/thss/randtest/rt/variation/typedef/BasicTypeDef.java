package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;

/**
 * 基本类型，比如Integer
 * @author aleck
 *
 */
public class BasicTypeDef extends TypeDef {
	@SuppressWarnings("rawtypes")
	public final Class klass;
	
	@SuppressWarnings("rawtypes")
	public BasicTypeDef(Class klass) {
		this.klass = klass;
	}
	
	@Override
	public int hashCode() {
		return klass.hashCode();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof BasicTypeDef)) {
			return false;
		}
		BasicTypeDef that = (BasicTypeDef) o;
		return this.klass.equals(that.klass);
	}
	
	@Override
	public String toString() {
		return klass.getCanonicalName();
	}

	@Override
	protected String shortName() {
		return klass.getCanonicalName();
	}
}
