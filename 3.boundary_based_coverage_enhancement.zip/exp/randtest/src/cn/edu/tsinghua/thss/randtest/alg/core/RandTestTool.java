package cn.edu.tsinghua.thss.randtest.alg.core;

import static com.google.common.base.Preconditions.checkNotNull;

import java.io.IOException;
import java.util.Properties;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ImportDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;
import org.eclipse.jdt.core.dom.PackageDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;

import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.Instrumentor;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.JavaExporter;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.exporter.GraphvizExporter;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor.CfgExtractor;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.ASTUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgSimplifier;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;

/**
 * 进行插装和准备的主要类，完成如下事情：
 * 1. 对代码进行插装
 * 2. 输出插装后的代码
 * 3. 解析CFG并且计算IsolationGraph
 * 4. 输出RuntimeAssist（包括IsolationGraph等等信息）
 * @author aleck
 *
 */
public class RandTestTool {
	public static final String TEST_PROJ_BASE_KEY 		= "test_project_base";
	public static final String TEST_PROJ_SRC_BASE_KEY 	= "test_project_src_base";
	public static final String TEST_PACKAGE_KEY 		= "test_package";
	public static final String TEST_CLASS_KEY 			= "test_class";
	public static final String TEST_METHOD_KEY 			= "test_method";
	public static final String WORK_PROJ_BASE_KEY 		= "work_project_base";
	
	private final String testProjectBase;
	private final String testProjectSrcBase;
	private final String testPackage;
	private final String testClass;
	private final String testMethod;
	private final String workProjectBase;

	/**
	 * 工作目录
	 */
	// private Project workProject;
	
	public RandTestTool() {
		this(null);
	}
	
	public RandTestTool(Properties props) {
		testProjectBase = 
				checkNotNull(props.getProperty(TEST_PROJ_BASE_KEY));
		testProjectSrcBase = 
				checkNotNull(props.getProperty(TEST_PROJ_SRC_BASE_KEY));
		testPackage = 
				checkNotNull(props.getProperty(TEST_PACKAGE_KEY));
		testClass = 
				checkNotNull(props.getProperty(TEST_CLASS_KEY));
		testMethod = 
				checkNotNull(props.getProperty(TEST_METHOD_KEY));
		workProjectBase = 
				checkNotNull(props.getProperty(WORK_PROJ_BASE_KEY));
	}
	
	public boolean execute() throws IOException {
		setupWorkProject(workProjectBase);
		parseAndInstrument();
		
		// TODO:
		return true;
	}

	private void parseAndInstrument() throws IOException {
		// (1) 从 源代码 -> 插装之后的源代码
		final String filename = testProjectBase + "/" + 
				testProjectSrcBase + "/" +
				ASTUtils.packageNameToPath(testPackage) + "/" +
				testClass + ".java";
		final String outputFilename = workProjectBase + "/src/" +
				ASTUtils.packageNameToPath(testPackage) + "/" + 
				testClass + ".java";
		
		FileUtils.copy(filename, outputFilename);
		
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		String source = FileUtils.readStringFromFile(outputFilename);
		parser.setSource(source.toCharArray());
		//parser.setSource("/*abc*/".toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
 
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		final ModificationListener ml = new ModificationListener();

		cu.recordModifications();
		
		// search for the class
		cu.accept(new ASTVisitor() {
			public boolean visit(TypeDeclaration td) {
				String name = td.getName().getIdentifier();
				if (name.equals(testClass)) {
					for (MethodDeclaration md : td.getMethods()) {
						String methodname = md.getName().getIdentifier();
						boolean found = methodname.equals(testMethod);
						if (found) {
							System.out.println("Found method: " + testClass + "." + methodname);
							ControlFlowGraph cfg = CfgExtractor.extractFromMethodDeclaration(
									md.getAST(), md);
							// simplify and reduce
							CfgSimplifier.removeUnreachableBlocks(cfg);
							CfgSimplifier.removeEmptyBlocks(md.getAST(), cfg);
							ProblemDescription pd = new ProblemDescription(
									testPackage, testClass, 
									methodname, md, cfg
									);
							Instrumentor instrumentor = new Instrumentor();
							instrumentor.instrument(md.getAST(), pd);
							
							ml.notifyModified();
							ml.registerProblemDescription(pd);
							
							// 输出流程图
							final String cfgFigFilename = workProjectBase + "/data/fig/" +
									testClass + "." + testMethod + ".dot";
							GraphvizExporter ge = new GraphvizExporter();
							try {
								ge.export(cfg, pd, 
										cfgFigFilename, 
										testClass + "." + testMethod, 
										true);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				return true;
			}
		});
		
		if (ml.isModified()) {
			// 输出插装过的文件
			System.out.println("Exporting to: " + outputFilename);
			Document doc = new Document(source);
			TextEdit edits = cu.rewrite(doc, null);
			try {
				edits.apply(doc);
				FileUtils.writeStringToFile(outputFilename, doc.get());
			} catch (MalformedTreeException e) {
				e.printStackTrace();
			} catch (BadLocationException e) {
				e.printStackTrace();
			}
			
			// (2) 输出辅助类
			ProblemDescription pd = ml.getProblemDescription();
			String runtimeAssistFilename = workProjectBase + "/src/" + 
					ASTUtils.packageNameToPath(pd.packagename) + "/" +
					Instrumentor.getRuntimeAssistClassName(pd.classname) + ".java";
			JavaExporter.exportToFile(runtimeAssistFilename, constructRuntimeAssist(pd));
			JavaExporter.format(runtimeAssistFilename);
		} else {
			System.out.println("The code is not modified!");
		}
	}

	@SuppressWarnings("unchecked")
	private CompilationUnit constructRuntimeAssist(ProblemDescription pd) {
		MethodDeclaration mdSetup = pd.getMethodDeclarationSetup();
		AST ast = mdSetup.getAST();
		CompilationUnit cu = ast.newCompilationUnit();
		
		PackageDeclaration pkg = ast.newPackageDeclaration();
		pkg.setName(ASTUtils.inlineQualifiedNameToName(ast, pd.packagename));
		cu.setPackage(pkg);
		
		TypeDeclaration td = ast.newTypeDeclaration();
		td.setInterface(false);
		td.modifiers().add(ast.newModifier(ModifierKeyword.PUBLIC_KEYWORD));
		td.setName(ast.newSimpleName(Instrumentor.getRuntimeAssistClassName(pd.classname)));
		td.bodyDeclarations().add(mdSetup);
		// extends RuntimeAssist
		td.setSuperclassType(ast.newSimpleType(ast.newSimpleName(Instrumentor.RA_BASE_CLASS_NAME)));
		
		cu.types().add(td);
		
		// add imports for RT
		// import TestTarget
		ImportDeclaration ttid = ast.newImportDeclaration();
		ttid.setName(ASTUtils.inlineQualifiedNameToName(ast, TestTarget.class.getName()));
		cu.imports().add(ttid);
		// import RT
		ImportDeclaration rtid = ast.newImportDeclaration();
		rtid.setName(ASTUtils.inlineQualifiedNameToName(ast, RT.class.getName()));
		cu.imports().add(rtid);
		// import RuntimeAssist
		ImportDeclaration raid = ast.newImportDeclaration();
		raid.setName(ASTUtils.inlineQualifiedNameToName(ast, RuntimeAssist.class.getName()));
		cu.imports().add(raid);
		
		return cu;
	}

	private void setupWorkProject(String workProjectBase) {
		FileUtils.createDirectory(workProjectBase);
	}
}
