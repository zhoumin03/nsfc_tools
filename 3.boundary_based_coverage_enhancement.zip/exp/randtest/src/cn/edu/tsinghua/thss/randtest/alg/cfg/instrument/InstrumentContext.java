package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;

/**
 * 在Instrument完成之后，我们需要一个 Integer <--> BasicBlock 的bimap
 * 然后才可以在算法中将track(5)和bb(id=5)对应起来
 * @author aleck
 *
 */
public class InstrumentContext {
	private final Map<BasicBlock, Integer> b2i = new HashMap<BasicBlock, Integer>();
	private final List<BasicBlock> i2b = new ArrayList<BasicBlock>();
	
	/**
	 * 构造
	 * @param decisions
	 * @param actions
	 */
	public void build(List<BasicBlock> decisions, List<BasicBlock> actions) {
		// actionBlock的id出现在前
		b2i.clear();
		i2b.clear();
		int id = 0;
		for (BasicBlock bb : decisions) {
			b2i.put(bb, id);
			i2b.add(bb);
			id++;
		}
		for (BasicBlock bb : actions) {
			b2i.put(bb, id);
			i2b.add(bb);
			id++;
		}
	}
	
	public BasicBlock getBasicBlockById(int id) {
		return i2b.get(id);
	}
	
	public int getIdByBasicBlock(BasicBlock bb) {
		return b2i.get(bb);
	}
	
	public int size() {
		return i2b.size();
	}
}
