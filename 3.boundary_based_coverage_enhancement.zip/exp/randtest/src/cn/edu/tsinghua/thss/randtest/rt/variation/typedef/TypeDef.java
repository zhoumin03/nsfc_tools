package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;

import cn.edu.tsinghua.thss.randtest.rt.variation.Generator;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;

public abstract class TypeDef {
	public boolean isBasicType() {
		return this instanceof BasicTypeDef;
	}
	
	public boolean isDependentType() {
		return this instanceof DependentTypeDef;
	}
	
	public boolean isInductiveType() {
		return this instanceof InductiveTypeDef;
	}
	
	@SuppressWarnings("rawtypes")
	public Generator findGenerator() {
		return GeneratorFactory.getInstance(this);
	}

	/**
	 * 返回比较简短的String表示
	 * @return
	 */
	protected abstract String shortName();
}
