package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class BinarySearch {
	public static int binarySearch(int[] a, 
			int fromIndex, 
			int toIndex,
			int key
			) {
		RT.startInvocation(5749116282906003456L);
				RT.track(1);
		int low = fromIndex;
		int high = toIndex - 1;

		RT.track(2);
		while (((RT.b(0)) && (RT.le(0, low, high))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			int mid = (low + high) >>> 1;
			int midVal = a[mid];

			RT.track(5);
			if (((RT.b(1)) && (RT.lt(0, midVal, key))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(7);
				low = mid + 1;
			}
			else {
				RT.nd(1);
				RT.track(8);
				if (((RT.b(2)) && (RT.gt(0, midVal, key))) && (RT.e(2))) {
					RT.pd(2);
					RT.track(9);
					high = mid - 1;
				}
				else {
					RT.nd(2);
					RT.track(10);
					return mid; // key found
				}
			}
		}
		RT.nd(0);
		RT.track(4);
		return -(low + 1); // key not found.
	}

}
