package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;

import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.ComposedFormula;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.FormulaBinding;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropAtom;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropFormula;

public class ExpressionUtils {
	public static Expression createInfixExpression(AST ast, 
			InfixExpression.Operator op,
			Expression lhs,
			Expression rhs) {
		// deeply copy it first
		lhs = (Expression) ASTNode.copySubtree(ast, lhs);
		rhs = (Expression) ASTNode.copySubtree(ast, rhs);
		
		InfixExpression ret = ast.newInfixExpression();
		ret.setOperator(op);
		ret.setLeftOperand(lhs);
		ret.setRightOperand(rhs);
		return ret;
	}
	
	public static Expression createPrefixExpression(AST ast, 
			PrefixExpression.Operator op,
			Expression operand) {
		// deeply copy it first
		operand = (Expression) ASTNode.copySubtree(ast, operand);
		
		PrefixExpression ret = ast.newPrefixExpression();
		ret.setOperator(op);
		ret.setOperand(operand);
		return ret;
	}
	
	public static Expression createBooleanLiteral(AST ast, boolean value) {
		return ast.newBooleanLiteral(value);
	}

	public static Expression lazyNegation(AST ast, Expression expr) {
		if (expr instanceof BooleanLiteral) {
			BooleanLiteral bl = (BooleanLiteral) expr;
			return createBooleanLiteral(ast, !bl.booleanValue());
		} else {
			if (expr instanceof PrefixExpression) {
				PrefixExpression pe = (PrefixExpression) expr;
				if (pe.getOperator() == PrefixExpression.Operator.NOT) {
					return (Expression) ASTNode.copySubtree(ast, pe.getOperand());
				}
			}
			// other wise
			return createPrefixExpression(ast, PrefixExpression.Operator.NOT, 
					wrapWithParenthesis(ast, expr));
		}
	}

	public static Expression createEquality(AST ast, 
			Expression lhs,
			Expression rhs) {
		return createInfixExpression(ast, InfixExpression.Operator.EQUALS, lhs, rhs);
	}

	public static Expression createConjunction(AST ast, 
			Expression lhs,
			Expression rhs) {
		return createInfixExpression(ast, 
				InfixExpression.Operator.CONDITIONAL_AND, 
				wrapWithParenthesis(ast, lhs), 
				wrapWithParenthesis(ast, rhs)
				);
	}
	
	public static Expression createDisjunction(AST ast, 
			Expression lhs,
			Expression rhs) {
		return createInfixExpression(ast, 
				InfixExpression.Operator.CONDITIONAL_OR, 
				wrapWithParenthesis(ast, lhs), 
				wrapWithParenthesis(ast, rhs)
				);
	}

	/**
	 * Return true on null
	 * @param expression
	 * @return
	 */
	public static Expression trueOnNull(AST ast, Expression expression) {
		return (expression == null ? createBooleanLiteral(ast, true) : expression);
	}

	public static boolean equalsToBooleanLiteral(Expression expr, boolean value) {
		if (expr != null && expr instanceof BooleanLiteral) {
			BooleanLiteral literal = (BooleanLiteral) expr;
			return literal.booleanValue() == value;
		} else {
			return false;
		}
	}
	

	/**
	 * Conjunct two boolean expressions
	 * when one of them is true, just ignore it
	 * when one of them is false, return false
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static Expression lazyConjunction(AST ast,
			Expression lhs, Expression rhs) {
		if (lhs == null && rhs == null) {
			return null;
		} else {
			boolean leftIsTrue = (lhs == null || ExpressionUtils.equalsToBooleanLiteral(lhs, true));
			boolean rightIsTrue = (rhs == null || ExpressionUtils.equalsToBooleanLiteral(rhs, true));
			if (leftIsTrue && rightIsTrue) {
				// one of lhs or rhs is not null
				return ExpressionUtils.createBooleanLiteral(ast, true);
			} else if (leftIsTrue && !rightIsTrue) {
				return (Expression) ASTNode.copySubtree(ast, rhs);
			} else if (!leftIsTrue && rightIsTrue) {
				return (Expression) ASTNode.copySubtree(ast, lhs);
			} else {
				if (ExpressionUtils.equalsToBooleanLiteral(lhs, false) ||
						ExpressionUtils.equalsToBooleanLiteral(rhs, false)) {
					return ExpressionUtils.createBooleanLiteral(ast, false);
				} else {
					return ExpressionUtils.createConjunction(ast, lhs, rhs);
				}
			}
		}
	}
	
	/**
	 * 将括号剥离
	 * @param expr
	 * @return
	 */
	public static Expression retainParenthesizedChild(Expression expr) {
		if (expr instanceof ParenthesizedExpression) {
			ParenthesizedExpression pe = (ParenthesizedExpression) expr;
			return retainParenthesizedChild(pe.getExpression());
		} else {
			return expr;
		}
	}

	/**
	 * 从Expression转换到公式
	 * @return
	 */
	public static PropFormula expr2skeleton(Expression expr, boolean positive, 
			FormulaBinding binding) {
		expr = retainParenthesizedChild(expr);
		if (expr instanceof InfixExpression) {
			InfixExpression ie = (InfixExpression) expr;
			if (ie.getOperator() == InfixExpression.Operator.CONDITIONAL_AND) {
				ComposedFormula cf = positive ? 
						ComposedFormula.createConjunction() :
						ComposedFormula.createDisjunction();
				cf.addSubFormula(expr2skeleton(ie.getLeftOperand(), positive, binding));
				cf.addSubFormula(expr2skeleton(ie.getRightOperand(), positive, binding));
				for (Object exo : ie.extendedOperands()) {
					Expression ex = (Expression) exo;
					PropFormula extended = expr2skeleton(ex, positive, binding);
					ComposedFormula ncf = positive ? 
							ComposedFormula.createConjunction() : ComposedFormula.createDisjunction();
					ncf.addSubFormula(cf);
					ncf.addSubFormula(extended);
					cf = ncf;
				}
				return cf;
			} else if (ie.getOperator() == InfixExpression.Operator.CONDITIONAL_OR) {
				ComposedFormula cf = positive ? 
						ComposedFormula.createDisjunction() :
						ComposedFormula.createConjunction();
				cf.addSubFormula(expr2skeleton(ie.getLeftOperand(), positive, binding));
				cf.addSubFormula(expr2skeleton(ie.getRightOperand(), positive, binding));
				for (Object exo : ie.extendedOperands()) {
					Expression ex = (Expression) exo;
					PropFormula extended = expr2skeleton(ex, positive, binding);
					ComposedFormula ncf = positive ?
							ComposedFormula.createDisjunction() : ComposedFormula.createConjunction();
					ncf.addSubFormula(cf);
					ncf.addSubFormula(extended);
					cf = ncf;
				}
				return cf;
			}
		} else if (expr instanceof PrefixExpression) {
			PrefixExpression pe = (PrefixExpression) expr;
			if (pe.getOperator() == PrefixExpression.Operator.NOT) {
				return expr2skeleton(pe.getOperand(), !positive, binding);
			}
		}
		// if above code is not applicable to the formula, treat it as an atom
		int stub = binding.bindNext(expr);
		PropAtom pa = new PropAtom(positive, stub);
		return pa;
	}
	
	/**
	 * 
	 * @param ast
	 * @param expr
	 * @return
	 */
	private static Expression wrapWithParenthesis(AST ast, Expression expr) {
		expr = (Expression) ASTNode.copySubtree(ast, expr);

		ParenthesizedExpression pe = ast.newParenthesizedExpression();
		pe.setExpression(expr);
		return pe;
	}

}
