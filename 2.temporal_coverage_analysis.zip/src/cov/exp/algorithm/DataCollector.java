package cov.exp.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cov.exp.model.Bin;
import cov.exp.model.State;

/**
 * Collect data in simulation
 * @author aleck
 *
 */
public class DataCollector {
	private List<State> trace = new ArrayList<>();
	private boolean bugDetected = false;
	
	public void reach(State s) {
		trace.add(s);
		if (s.bug)
			bugDetected = true;
	}

	public boolean isBugDetected() {
		return bugDetected;
	}
	
	public String getTraceStr() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < trace.size(); i++) {
			if (i > 0) {
				sb.append(" --> ");
			}
			State s = trace.get(i);
			sb.append(s);
			if (s.bug)
				sb.append("(*)");
		}
		return sb.toString();
	}
	
	public Set<Bin> summarizeReachedBins() {
		Set<Bin> bins = new HashSet<>();
		for (State s : trace) {
			bins.add(s.bin);
		}
		return bins;
	}
	
	public String getSummaryStr() {
		StringBuilder sb = new StringBuilder();
		sb.append("detect = " + bugDetected);
		sb.append('\n');
		Set<Bin> bins = summarizeReachedBins();
		List<Bin> orderedBins = new ArrayList<>(bins);
		Collections.sort(orderedBins, new Comparator<Bin>() {
			@Override
			public int compare(Bin x, Bin y) {
				return x.id() - y.id();
			}
		});
		sb.append("bins = ");
		for (Bin b : orderedBins) {
			sb.append(b);
		}
		return sb.toString();
	}
	
	public List<State> getTrace() {
		return trace;
	}
	
	@Override
	public String toString() {
		return getSummaryStr();
	}
}
