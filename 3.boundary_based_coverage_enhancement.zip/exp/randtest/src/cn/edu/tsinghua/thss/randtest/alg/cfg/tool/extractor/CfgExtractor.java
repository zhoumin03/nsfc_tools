package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.AssertStatement;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.EmptyStatement;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.LabeledStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.SynchronizedStatement;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TryStatement;
import org.eclipse.jdt.core.dom.TypeDeclarationStatement;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ActionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.DecisionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge.BranchType;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.ExpressionUtils;

/**
 * Extract CFG from Java program 转换过程保持如下几个性质：
 * 1. 所有Edge上的条件都需要可以回溯到源代码中的条件 
 *   (a) 当Edge条件为null时，表示无条件跳转，可以不对应源代码中的条件 
 *   (b) 当条件不为null时，必须要有对应的来源信息 
 * 2. 所有BasicBlock中的表达式都要对应到源代码中的语句 
 *   (a) 当为空BasicBlock时可以不对应 
 *   (b) 当不为空时需要记录源代码中的语句信息(Statement or Expression)
 *     -- 在ForStatement中，Expression被用于initializer, updator 
 * 3. 转换过程需要保证 不存在一个模块，即包含Action，又包含Decision
 * 
 * @note: we currently do not consider programs written with 'label' statement
 * @node: 解析过程不会改变原有程序的AST
 * 
 * @author aleck
 * 
 */
public class CfgExtractor {
	@SuppressWarnings("serial")
	public static class UnhandledStatementException extends RuntimeException {
		public UnhandledStatementException(String msg) {
			super(msg);
		}
	}

	/**
	 * Extract a CFG from a method
	 * 
	 * @param cntxt
	 * @param method
	 * @return
	 */
	public static ControlFlowGraph extractFromMethodDeclaration(AST ast,
			MethodDeclaration method) {
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();
		JumpContext jump = new JumpContext(exit);
		ExtractorContext cntxt = new ExtractorContext(ast, jump);
		ControlFlowGraph bodyGraph = handleBlock(cntxt, method.getBody());
		CfgUtils.concatenate(entry, bodyGraph);
		CfgUtils.concatenate(bodyGraph, exit);
		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * if a statement is a simple statement
	 * 1. those simple Statements
	 * 2. Expression (which is used in ForStatement as initializer and updator)
	 * 
	 * @param stat
	 * @return
	 */
	private static boolean isSimpleStatement(ASTNode stat) {
		return stat instanceof SuperConstructorInvocation
				|| stat instanceof ExpressionStatement
				|| stat instanceof EmptyStatement
				|| stat instanceof ConstructorInvocation
				|| stat instanceof AssertStatement
				|| stat instanceof ThrowStatement
				|| stat instanceof TypeDeclarationStatement
				|| stat instanceof VariableDeclarationStatement
				|| stat instanceof Expression; // <-- notice here
	}

	/**
	 * Extract the control flow graph from a statement
	 * 
	 * @param stat
	 * @param cntxt
	 * @return
	 */
	private static ControlFlowGraph handleStatement(ExtractorContext cntxt,
			Statement stat) {
		if (isSimpleStatement(stat)) {
			BasicBlock entry = BasicBlock.newActionBlock();
			BasicBlock exit = BasicBlock.newActionBlock();
			ActionBlock body = BasicBlock.newActionBlock();
			body.addStatement(stat);
			CfgUtils.concatenate(entry, body);
			CfgUtils.concatenate(body, exit);
			return new ControlFlowGraph(entry, exit);
		} else {
			return handleComposedStatement(cntxt, stat);
		}
	}

	/**
	 * Construct the CFG for statements inside a block
	 * 
	 * @param ast
	 * @param stat
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static ControlFlowGraph handleBlock(ExtractorContext cntxt,
			Block block) {
		List stats = block.statements();
		// already statement list, no need for conversion
		return handleStatementList(cntxt, stats);
	}

	/**
	 * Construct the CFG for a list of sequential statements There is always an
	 * ENTRY BUT, the EXIT may not always exists For instance, if the control
	 * flow jumps to some upper level,
	 * 
	 * while (xxx) { if (xxx) break; // jumps to L1 } L1: // jumps to here
	 * 
	 * Then, if we are parsing 'if', the control flow does not follow the
	 * sequential order. In this condition, we think the 'EXIT' does not exist.
	 * 
	 * @param stats
	 * @return
	 */
	private static ControlFlowGraph handleStatementList(ExtractorContext cntxt,
			List<ASTNode> stats) {
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();
		ActionBlock current = BasicBlock.newActionBlock();

		CfgUtils.concatenate(entry, current);

		// current working basic block and graph
		ControlFlowGraph graph = null;
		boolean lastElementIsGraph = false;
		boolean controlFlowLeaves = false;

		for (ASTNode stat : stats) {
			if (controlFlowLeaves)
				throw new RuntimeException("dead code detected");
			if (isSimpleStatement(stat)) {
				// bb -> graph
				if (lastElementIsGraph) {
					CfgUtils.concatenate(graph, current);
				}
				// simple statements
				current.addStatement(stat);
				lastElementIsGraph = false;
			} else {
				// stat is must a Statement
				ControlFlowGraph cfg = handleComposedStatement(cntxt, (Statement) stat);
				// detect dead code
				if (!cfg.hasValidExit()) {
					controlFlowLeaves = true;
				}

				// concatenate
				// ENTRY --> b1 --> b2 --> EXIT
				// 1. link b1 after current
				// 2. current point to b2
				// 3. remove ENTRY and EXIT
				if (lastElementIsGraph) {
					// cfg -> cfg
					CfgUtils.concatenate(graph, cfg);
				} else {
					// bb -> cfg
					CfgUtils.concatenate(current, cfg);
					// create a new block
					current = BasicBlock.newActionBlock();
				}
				graph = cfg;
				lastElementIsGraph = true;
			}
		}

		if (lastElementIsGraph) {
			CfgUtils.concatenate(graph, exit);
		} else {
			CfgUtils.concatenate(current, exit);
		}

		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * Construct CFG for composed statement
	 * 
	 * @param stat
	 * @return
	 */
	private static ControlFlowGraph handleComposedStatement(
			ExtractorContext cntxt, Statement stat) {
		throwExceptionOnUnhandledStatement(stat);
		if (stat instanceof Block) {
			return handleBlock(cntxt, (Block) stat);
		} else if (stat instanceof ForStatement) {
			return handleForStatement(cntxt, (ForStatement) stat);
		} else if (stat instanceof WhileStatement) {
			return handleWhileStatement(cntxt, (WhileStatement) stat);
		} else if (stat instanceof DoStatement) {
			return handleDoStatement(cntxt, (DoStatement) stat);
		} else if (stat instanceof IfStatement) {
			return handleIfStatement(cntxt, (IfStatement) stat);
		} else if (stat instanceof SwitchStatement) {
			return handleSwitchStatement(cntxt, (SwitchStatement) stat);
		} else if (stat instanceof TryStatement) {
			return handleTryStatement(cntxt, (TryStatement) stat);
		} else if (stat instanceof SynchronizedStatement) {
			return handleSynchronizedStatement(cntxt,
					(SynchronizedStatement) stat);
		} else if (stat instanceof BreakStatement) {
			return handleBreakStatement(cntxt, (BreakStatement) stat);
		} else if (stat instanceof ContinueStatement) {
			return handleContinueStatement(cntxt, (ContinueStatement) stat);
		} else if (stat instanceof ReturnStatement) {
			return handleReturnStatement(cntxt, (ReturnStatement) stat);
		} else if (stat instanceof SwitchCase) {
			throw new IllegalArgumentException(
					"SwitchCaseStatement should be handled inside 'handleSwitchStatement'.");
		} else {
			throw new IllegalArgumentException(
					"other statements should be handled in 'handleBlockStatement'.");
		}
	}

	/**
	 * switch statement accepts only INT-convertible value as expression
	 * 
	 * @note we assume the expression has NO side-effect, if there is, we should
	 *       replace it with some intermediate variable
	 * @param cntxt
	 * @param stat
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private static ControlFlowGraph handleSwitchStatement(
			ExtractorContext cntxt, SwitchStatement stat) {
		// SWITCH (EXPRESSION) {
		// CASE X1
		// BODY1
		// CASE X2
		// BODY2
		// DEFAULT
		// ELSE_BODY
		// }
		//
		// Semantically, if X! holds, both of BODY1 and BODY2 will be executed
		//
		// ENTRY
		// |
		// v
		// SC1 --> (C1) --> BODY1
		// | |
		// (not C1) |
		// v v
		// SC2 --> (C2) --> BODY2
		// | |
		// (not C2) |
		// v v
		// SC3 --> (C3) --> BODY3 (if there is a break, then jump to break
		// target)
		// | |
		// (not C3) |
		// v v
		// DEFAULT --> BODY_DEFAULT
		// | |
		// v ???<<<--------- | -----(if no default, then the last SC has to
		// check condition)
		// BT <---------------+
		// |
		// v
		// EXIT
		//
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock bt = BasicBlock.newActionBlock(); // break target
		BasicBlock exit = BasicBlock.newActionBlock();

		// AFTER -> EXIT
		CfgUtils.concatenate(bt, exit);

		// push context
		cntxt.getJump().pushBreakContext(bt);

		// here ------> trueBlockGraph
		// |
		// v
		// falseBasicBlock
		DecisionBlock falsebb = BasicBlock.newDecisionBlock();
		ControlFlowGraph truebg = null;

		CfgUtils.concatenate(entry, falsebb);

		Expression testExpr = stat.getExpression();
		List<Statement> statements = stat.statements();

		SwitchCase sc = null;
		List<ASTNode> segment = new ArrayList<ASTNode>();
		for (Statement s : statements) {
			if (s instanceof SwitchCase) {
				if (sc != null) {
					Expression condition = ExpressionUtils.createEquality(
							cntxt.getAst(), testExpr, sc.getExpression());
					falsebb.setConditionAndItsSource(condition, sc);
					
					// new segment, generate a graph for even empty block
					// already statement list, no need for conversion
					ControlFlowGraph bg = handleStatementList(cntxt, segment);
					// oldTrueBG
					// | [2]
					// [1] v
					// oldFalseBB -----> newTrueBG
					// | [3]
					// v
					// newFalseBB
					//
					// [1] -->
					BasicBlock entrance = bg.getBasicBlockAfterEntry();
					CfgUtils.concatenate(falsebb, bg, BranchType.TRUE_BRANCH);
					// [2] |
					// v
					if (truebg != null) {
						// may fail
						// the original 'ENTRY' may already be removed, use
						// entrance
						CfgUtils.concatenate(truebg, entrance);
					}
					// [3] |
					// v
					DecisionBlock next = BasicBlock.newDecisionBlock();
					CfgUtils.concatenate(falsebb, next, BranchType.FALSE_BRANCH);

					falsebb = next;
					truebg = bg;
				}

				sc = (SwitchCase) s;
				segment.clear();
			} else {
				if (sc == null) {
					throw new UnhandledStatementException(
							"There should be some SwitchCase ahead.");
				} else {
					segment.add(s);
				}
			}
		}

		// the last block
		if (segment.size() != 0) {
			// new segment
			ControlFlowGraph bg = handleStatementList(cntxt, segment);
			if (sc.getExpression() == null) {
				// it is a 'default:'
				// its TRUE and FALSE branch all goes to this block
				falsebb.setConditionAndItsSource(
						ExpressionUtils.createBooleanLiteral(cntxt.getAst(), true), 
						sc);
				BasicBlock dest = bg.getBasicBlockAfterEntry();
				CfgUtils.removeBasicBlock(bg.getEntry());
				CfgUtils.concatenate(falsebb, dest, BranchType.TRUE_BRANCH);
				CfgUtils.concatenate(falsebb, dest, BranchType.FALSE_BRANCH);
				// may fail
				CfgUtils.concatenate(bg, bt);
			} else {
				// the last switchcase is as normal
				// new segment, generate a graph for even empty block
				Expression condition = ExpressionUtils.createEquality(
						cntxt.getAst(), testExpr, sc.getExpression());
				falsebb.setConditionAndItsSource(condition, sc);
				// already statement list, no need for conversion
				// oldTrueBG
				// | [2]
				// [1] v
				// oldFalseBB -----> newTrueBG
				// | [3]
				// v
				// newFalseBB
				//
				// [1] -->
				BasicBlock entrance = bg.getBasicBlockAfterEntry();
				CfgUtils.concatenate(falsebb, bg, BranchType.TRUE_BRANCH);
				// [2] |
				// v
				if (truebg != null) {
					// may fail
					// the original 'ENTRY' may already be removed, use entrance
					CfgUtils.concatenate(truebg, entrance);
				}
				// [3] |
				// v
				CfgUtils.concatenate(falsebb, bt, BranchType.FALSE_BRANCH);
				// may fail
				CfgUtils.concatenate(bg, bt);
			}
		} else {
			CfgUtils.concatenate(falsebb, bt);
			// truebg must not be null
			// may fail
			CfgUtils.concatenate(truebg, bt);
		}

		// pop context
		cntxt.getJump().popBreakContext();

		return new ControlFlowGraph(entry, exit);
	}

	private static ControlFlowGraph handleTryStatement(ExtractorContext cntxt,
			TryStatement stat) {
		// TRY TRY_BODY CATCH_BODY_1 ... CATCH_BODY_N FINALLY_BODY
		// note: currently, we remove all statements in catch and finally
		// note: reason is that CFG of the following program is too complex
		// for (int i = 0; i < 10; i++) {
		// try {
		// continue;
		// } catch (Exception e) {
		// // do nothing
		// } finally {
		// System.out.println(i);
		// }
		// System.out.println("haha!");
		// }
		BasicBlock entry = BasicBlock.newActionBlock();
		ControlFlowGraph bodyGraph = handleBlock(cntxt, stat.getBody());
		BasicBlock exit = BasicBlock.newActionBlock();

		CfgUtils.concatenate(entry, bodyGraph);
		// may fail
		CfgUtils.concatenate(bodyGraph, exit);

		if (exit.getInDegree() == 0)
			exit = null;
		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * No EXIT, but make sure it has valid ENTRY
	 * 
	 * @param cntxt
	 * @param stat
	 * @return
	 */
	private static ControlFlowGraph handleBreakStatement(
			ExtractorContext cntxt, BreakStatement stat) {
		// ENTRY --> empty --> break, no EXIT
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock empty = BasicBlock.newActionBlock();
		CfgUtils.concatenate(entry, empty);
		CfgUtils.concatenate(empty, cntxt.getJump().redirectBreak());
		BasicBlock exit = null;

		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * No EXIT, but make sure it has valid ENTRY
	 * 
	 * @param cntxt
	 * @param stat
	 * @return
	 */
	private static ControlFlowGraph handleContinueStatement(
			ExtractorContext cntxt, ContinueStatement stat) {
		// ENTRY --> empty --> continue, no EXIT
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock empty = BasicBlock.newActionBlock();
		CfgUtils.concatenate(entry, empty);
		CfgUtils.concatenate(entry, cntxt.getJump().redirectContinue());
		BasicBlock exit = null;

		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * No EXIT, but make sure it has valid ENTRY
	 * 
	 * @param cntxt
	 * @param stat
	 * @return
	 */
	private static ControlFlowGraph handleReturnStatement(
			ExtractorContext cntxt, ReturnStatement stat) {
		// ENTRY --> return --> RETURN_POINT, no EXIT
		BasicBlock entry = BasicBlock.newActionBlock();
		ActionBlock retBlock = BasicBlock.newActionBlock();
		retBlock.addStatement(stat);
		CfgUtils.concatenate(entry, retBlock);
		CfgUtils.concatenate(retBlock, cntxt.getJump().redirectReturn());
		BasicBlock exit = null;

		return new ControlFlowGraph(entry, exit);
	}

	private static ControlFlowGraph handleSynchronizedStatement(
			ExtractorContext cntxt, SynchronizedStatement stat) {
		return handleBlock(cntxt, stat.getBody());
	}

	private static ControlFlowGraph handleIfStatement(ExtractorContext cntxt,
			IfStatement stat) {
		// IF (EXPRESSION) THEN { THEN_BODY } ELSE { ELSE_BODY }
		//
		// ENTRY -> decision -> (E) -> THEN_BODY -|
		//             |                          |
		//          (not E)                       v
		//             |-----> ELSE_BODY -----> after --> EXIT
		//
		// note: it is possible the ELSE_BODY does not exist
		// note: THEN_BODY or ELSE_BODY does not have an EXIT itself, it will
		// not link to this EXIT, either
		// note: if both of them have no EXIT, neither does the whole
		// IfStatement
		//
		boolean hasElseBody = (stat.getElseStatement() != null);
		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock after = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();
		Expression condition = stat.getExpression();

		DecisionBlock decision = BasicBlock.newDecisionBlock(condition, stat);
		ControlFlowGraph thenBody = handleStatement(cntxt,
				stat.getThenStatement());

		CfgUtils.concatenate(entry, decision);
		CfgUtils.concatenate(decision, thenBody, BranchType.TRUE_BRANCH);
		// may fail
		CfgUtils.concatenate(thenBody, after);
		CfgUtils.concatenate(after, exit);

		ControlFlowGraph elseBody = null;
		if (hasElseBody) {
			elseBody = handleStatement(cntxt, stat.getElseStatement());
			CfgUtils.concatenate(decision, elseBody, BranchType.FALSE_BRANCH);
			// may fail
			CfgUtils.concatenate(elseBody, after);
		} else {
			// no ELSE_BODY
			CfgUtils.concatenate(decision, after, BranchType.FALSE_BRANCH);
		}

		// if no EXIT
		if (exit.getInDegree() == 0) {
			exit = null;
		}

		return new ControlFlowGraph(entry, exit);
	}

	private static ControlFlowGraph handleDoStatement(ExtractorContext cntxt,
			DoStatement stat) {
		// DO { BODY} WHILE (EXPRESSION)
		//
		//            |--------(E)--------|
		//            v                   |
		// ENTRY -> before --> BODY --> after -(not E)-> break target -> EXIT
		//
		Expression condition = stat.getExpression();

		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();

		BasicBlock before = BasicBlock.newActionBlock(); // continue target
		DecisionBlock after = BasicBlock.newDecisionBlock(condition, stat);
		BasicBlock bt = BasicBlock.newActionBlock(); // break target

		cntxt.getJump().pushContinueContext(before);
		cntxt.getJump().pushBreakContext(bt);
		ControlFlowGraph bodyGraph = handleStatement(cntxt, stat.getBody());
		cntxt.getJump().popBreakContext();
		cntxt.getJump().popContinueContext();

		CfgUtils.concatenate(entry, before);
		CfgUtils.concatenate(before, bodyGraph);
		// may fail
		CfgUtils.concatenate(bodyGraph, after);
		CfgUtils.concatenate(after, before, BranchType.TRUE_BRANCH);
		CfgUtils.concatenate(after, bt, BranchType.FALSE_BRANCH);
		CfgUtils.concatenate(bt, exit);

		return new ControlFlowGraph(entry, exit);
	}

	private static ControlFlowGraph handleWhileStatement(
			ExtractorContext cntxt, WhileStatement stat) {
		// WHILE (EXPRESSION) { BODY }
		//            |-------------------|
		//            v                   |
		// ENTRY -> empty -(E)-> BODY --> |
		//            |
		//           not E
		//            |
		//            |--> bt --> EXIT
		Expression condition = stat.getExpression();

		BasicBlock entry = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();
		BasicBlock bt = BasicBlock.newActionBlock(); // break target
		DecisionBlock empty = BasicBlock.newDecisionBlock(condition, stat); // continue target

		cntxt.getJump().pushContinueContext(empty);
		cntxt.getJump().pushBreakContext(bt);
		ControlFlowGraph bodyGraph = handleStatement(cntxt, stat.getBody());
		cntxt.getJump().popBreakContext();
		cntxt.getJump().popContinueContext();

		CfgUtils.concatenate(entry, empty);
		CfgUtils.concatenate(empty, bodyGraph, BranchType.TRUE_BRANCH);
		// may fail
		CfgUtils.concatenate(bodyGraph, empty);

		CfgUtils.concatenate(empty, bt, BranchType.FALSE_BRANCH);
		CfgUtils.concatenate(bt, exit);

		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * 在ForStatement中，Expression被用于initializer和updator。而这两者又不是Statement的子类
	 * 为了能够溯源，因此不对其进行赋值，而是直接实用其引用。
	 * 因此，这里的Expression也当成表达式来对待
	 * @param cntxt
	 * @param stat
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private static ControlFlowGraph handleForStatement(ExtractorContext cntxt,
			ForStatement stat) {
		// FOR (INITIALIZER; EXPRESSION; UPDATER) { BODY }
		//                            |----------------------------------------|
		//                            v                                        |
		// ENTRY -> INITIALIZER --> empty -(E)-> BODY --> skip --> UPDATOR --> |
		//                            |
		//                          not E
		//                            |
		//                            |--> after(break target) --> EXIT
		Expression condition = stat.getExpression();

		BasicBlock entry = BasicBlock.newActionBlock();
		DecisionBlock empty = BasicBlock.newDecisionBlock(condition, stat); // continue target
		BasicBlock skip = BasicBlock.newActionBlock(); // continue target
		BasicBlock after = BasicBlock.newActionBlock(); // break target
		BasicBlock exit = BasicBlock.newActionBlock();

		cntxt.getJump().pushContinueContext(skip);
		cntxt.getJump().pushBreakContext(after);
		ControlFlowGraph bodyGraph = handleStatement(cntxt, stat.getBody());
		ControlFlowGraph initGraph = handleStatementList(cntxt, stat.initializers());
		ControlFlowGraph updatorGraph = handleStatementList(cntxt, stat.updaters());
		cntxt.getJump().popBreakContext();
		cntxt.getJump().popContinueContext();

		CfgUtils.concatenate(entry, initGraph);
		CfgUtils.concatenate(initGraph, empty);
		CfgUtils.concatenate(empty, bodyGraph, BranchType.TRUE_BRANCH);
		// may fail
		CfgUtils.concatenate(bodyGraph, skip);
		CfgUtils.concatenate(skip, updatorGraph);
		CfgUtils.concatenate(updatorGraph, empty);
		CfgUtils.concatenate(empty, after, BranchType.FALSE_BRANCH);
		CfgUtils.concatenate(after, exit);

		return new ControlFlowGraph(entry, exit);
	}

	/**
	 * Cast an arbitrary list to statement list now, consider expressions only
	 * 
	 * e.g for (int i = 0; i < 100; i++) { ... }
	 * 
	 * the 'initializer' 'ini i = 0' is a expression rather than a statement
	 * 
	 * @param updaters
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unused" })
	private static List<Statement> castToStatementList(AST ast, List list) {
		List<Statement> stats = new ArrayList<Statement>();
		Iterator iter = list.iterator();
		while (iter.hasNext()) {
			ASTNode node = (ASTNode) iter.next();
			if (node instanceof Statement) {
				stats.add((Statement) node);
			} else {
				// otherwise, to an expression statement
				ExpressionStatement es = ast
						.newExpressionStatement((Expression) ASTNode
								.copySubtree(ast, node));
				stats.add(es);
			}
		}
		return stats;
	}

	/**
	 * 暂时不考虑EnhancedForStatement(可以手工转换为一般的ForStatement) 暂时不考虑LabeledStatement
	 * 
	 * @param stat
	 */
	private static void throwExceptionOnUnhandledStatement(Statement stat) {
		if (stat instanceof EnhancedForStatement) {
			throw new UnhandledStatementException(
					"EnhancedForStatement should be converted to ForStatement first.");
		} else if (stat instanceof LabeledStatement) {
			throw new UnhandledStatementException(
					"LabeledStatement is not supported.");
		}
	}
}
