package cn.edu.tsinghua.thss.randtest.cases.test;

public class IntBarrier {
	public static int f(int x) {
		if (x > 0) {
			return 1;
		} else {
			return 0;
		}
	}
}
