package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;


public class ByteGenerator extends AbstractGenerator<Byte> {

	public void registerSpecials() {
		registerSpecial((byte) 0);
		registerSpecial((byte) 1);
		registerSpecial((byte) -1);
		registerSpecial((byte) 2);
		registerSpecial((byte) -2);
		registerSpecial(Byte.MAX_VALUE);
		registerSpecial(Byte.MIN_VALUE);
		for (int i = 0; i < 8; i++) {
			registerSpecial((byte) (1 << i));
			registerSpecial((byte) -(1 << i));
		}
	}

	@Override
	public Byte nextRandom() {
		return (byte) (rand.nextInt((int)1 + Byte.MAX_VALUE - Byte.MIN_VALUE) + 
				Byte.MIN_VALUE);
	}

	@Override
	public Byte nextBiasedRandom() {
		if (rand.nextBoolean()) {
			return (byte) logBiasedLong(Byte.MAX_VALUE);
		} else {
			return (byte) -logBiasedLong(-(long)Byte.MIN_VALUE);
		}
	}

	@Override
	public Byte nextNeighbour(Byte current, double scale) {
		if (current == Byte.MIN_VALUE) {
			return (byte) (current + 1);
		} else if (current == Byte.MAX_VALUE) {
			return (byte) (current - 1);
		} else {
			return (byte) (rand.nextBoolean() ? current + 1 : current - 1);
		}
	}

	@Override
	public Byte copy(Byte origin) {
		return Byte.valueOf(origin.byteValue());
	}

	@Override
	public Byte[] allNeighbours(Byte current, double scale) {
		if (current == Byte.MIN_VALUE) {
			return new Byte[] {(byte) (current + 1)};
		} else if (current == Byte.MAX_VALUE) {
			return new Byte[] {(byte) (current - 1)};
		} else {
			return new Byte[] {(byte) (current - 1), (byte) (current + 1)};
		}
	}
}
