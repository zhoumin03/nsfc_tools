package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.cases.Perpendicular;
import junit.framework.TestCase;

public class PerpendicularTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T1_3, T3_6]
	public void test00() {
		assertEquals((false), Perpendicular.isPerpendicular(-24687908, -7486, 1, 0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T1_2]
	public void test01() {
		assertEquals((false), Perpendicular.isPerpendicular(0, 0, -34936270, 177018));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T3_5, T1_3]
	public void test02() {
		assertEquals((false), Perpendicular.isPerpendicular(-18736723, 15580833, 0, 0));
	}
	//<<case-end>>
}
