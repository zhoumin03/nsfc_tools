package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class Perpendicular {
	public static boolean isPerpendicular(int x1, int y1, int x2, int y2) {
		RT.startInvocation(6587939683183828992L);
		RT.track(1);
		if (((RT.b(0)) && (((RT.eq(0, x1, 0)) || (RT.eq(1, y1, 0))))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return false;
		}
		RT.nd(0);
		RT.track(3);
		if (((RT.b(1)) && (((RT.eq(0, x2, 0)) || (RT.eq(1, y2, 0))))) && (RT.e(1))) {
			RT.pd(1);
			RT.track(5);
			return false;
		}
		RT.nd(1);
		RT.track(6);
		if (((RT.b(2)) && (RT.eq(0, x1 * y2 - x2 * y1, 0))) && (RT.e(2))) {
			RT.pd(2);
			RT.track(7);
			return true;
		} else {
			RT.nd(2);
			RT.track(8);
			return false;
		}
	}
}
