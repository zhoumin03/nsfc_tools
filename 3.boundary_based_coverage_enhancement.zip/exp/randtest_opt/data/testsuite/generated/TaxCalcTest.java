package algorithm.test;

import junit.framework.TestCase;
import algorithm.TaxCalc;

public class TaxCalcTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//#0, coverages: [T11_13, T7_9, T2_4, T9_11, T13_14, T4_7]
	public void test00() {
		assertEquals((13418.267351055787), TaxCalc.tax(57410.89117018596D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T7_9, T2_4, T9_11, T11_12, T4_7]
	public void test01() {
		assertEquals((7571.732684417619), TaxCalc.tax(37806.930737670475D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T7_9, T2_4, T4_7, T9_10]
	public void test02() {
		assertEquals((1209.3565198871806), TaxCalc.tax(12321.782599435903D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T2_4, T4_6]
	public void test03() {
		assertEquals((44.10891779999998), TaxCalc.tax(4970.297259999999D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T11_13, T7_9, T2_4, T9_11, T13_15, T15_16, T4_7]
	public void test04() {
		assertEquals((21940.552983660553), TaxCalc.tax(81915.86566760158D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T7_8, T2_4, T4_7]
	public void test05() {
		assertEquals((336.08911), TaxCalc.tax(7910.8911D));
	}
	//<<case-end>>
	//<<case-begin>>
	//#6, coverages: [T11_13, T7_9, T2_4, T15_17, T9_11, T13_15, T4_7]
	public void test06() {
		assertEquals((23222.2721055438), TaxCalc.tax(85116.16023454178D));
	}
	//<<case-end>>
}
