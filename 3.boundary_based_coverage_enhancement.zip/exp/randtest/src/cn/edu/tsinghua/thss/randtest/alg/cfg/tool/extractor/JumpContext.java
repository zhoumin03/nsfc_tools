package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor;

import java.util.NoSuchElementException;
import java.util.Stack;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;

/**
 * A table which record that
 * where the control flow will be redirected to when a 
 * - 'break', 
 * - 'continue', 
 * - 'return' 
 * is met
 * @author aleck
 *
 */
public class JumpContext {
	private BasicBlock bbReturn;
	// continue may be used inside a loop
	private Stack<BasicBlock> bbContinue;
	// break may be used inside a loop or in a switch case
	private Stack<BasicBlock> bbBreak;
	
	public JumpContext(BasicBlock bbr) {
		if (bbr == null) {
			throw new IllegalArgumentException("the basic block for return should be given");
		}
		this.bbReturn = bbr;
		bbContinue = new Stack<BasicBlock>();
		bbBreak = new Stack<BasicBlock>();
	}
	
	public BasicBlock redirectReturn() {
		return bbReturn;
	}
	
	public BasicBlock redirectContinue() {
		if (bbContinue.size() == 0) {
			throw new NoSuchElementException("do not know where 'continue' leads to.");
		}
		return bbContinue.peek();
	}
	
	public BasicBlock redirectBreak() {
		if (bbBreak.size() == 0) {
			throw new NoSuchElementException("do not know where 'break' leads to.");
		}
		return bbBreak.peek();
	}
	
	public void pushContinueContext(BasicBlock bb) {
		if (bb == null) {
			throw new IllegalArgumentException("null is not expected.");
		}
		bbContinue.push(bb);
	}
	
	public void popContinueContext() {
		if (bbContinue.size() == 0) {
			throw new NoSuchElementException("'continue' context is empty.");
		}
		bbContinue.pop();
	}

	public void pushBreakContext(BasicBlock bb) {
		if (bb == null) {
			throw new IllegalArgumentException("null is not expected.");
		}
		bbBreak.push(bb);
	}
	
	public void popBreakContext() {
		if (bbBreak.size() == 0) {
			throw new NoSuchElementException("'break' context is empty.");
		}
		bbBreak.pop();
	}

}
