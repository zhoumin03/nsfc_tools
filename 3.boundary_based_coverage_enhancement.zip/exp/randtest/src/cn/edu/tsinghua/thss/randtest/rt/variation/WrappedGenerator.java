package cn.edu.tsinghua.thss.randtest.rt.variation;

import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.WrappedTypeDef;


/**
 * 用于给DependentType和InductiveType作为基础Generator的类
 * @author aleck
 *
 * @param <T>
 */
public interface WrappedGenerator<T> extends Generator<T> {
	@SuppressWarnings("rawtypes")
	public void setDepdentGenerators(Generator ...gens);
	
	@SuppressWarnings("rawtypes")
	public Generator getDependentGenerator(int idx);

	public void refineDependentGenerators(WrappedTypeDef wtd);
	
}
