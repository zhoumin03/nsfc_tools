package cov.exp.model;

/**
 * A concrete system state
 * @author aleck
 *
 */
public class State {
	
	public State() {
		initial = false;
		bug = false;
		bin = null;
	}
	
	// the value of flip-flop, encoded as a bit vector
	public int flipflops;
	// transitions: InputPattern --> State
	public State[] transitions;
	// the bin that owns this state
	public Bin bin;
	// is initial
	public boolean initial;
	// if this state detects a bug
	public boolean bug;
	
	public String getName() {
		return "S" + flipflops;
	}
	
	@Override
	public String toString() {
		return getName();
	}
}
