package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.Evaluator.Strategy;

public class OptimizeParameter {
	// 每个测试重复运行REPEAT次取平均
	public static final int REPEAT = 200;
	// 当执行以exception结束时，对当前输入的penalty
	public static final double EXCEPTION_PENALTY = -8;
	// 当使用Random的方法生成测试用例时，使用的默认Fitness
	public static final double DEFAULT_RANDOM_FITNESS = -5;
	
	// 测试 statement 还是 branch
	private static Category TEST_CATEGORY = Category.STATEMENT;
	// 采用 node 还是 node+distance
	private static Strategy EVALUATION_STRATEGY = Strategy.NODE_PLUS_DIST;
	
	public static Category getCategory() {
		return TEST_CATEGORY;
	}
	
	public static void setCategory(Category category) {
		TEST_CATEGORY = category;
	}
	
	public static Strategy getStrategy() {
		return EVALUATION_STRATEGY;
	}
	
	public static void setStrategy(Strategy strategy) {
		EVALUATION_STRATEGY = strategy;
	}
	
	//////////////////////////////////////////////////////////////////////////// 
	// 比较细的参数 
	//////////////////////////////////////////////////////////////////////////// 
	public static final OptimizeParameter PAR_MEMETIC = new OptimizeParameter(
			1000, 
			10000, 
			60000
			);
	
	public static final OptimizeParameter PAR_RANDOM = new OptimizeParameter(
			1000 * MemeticOptimizer.POPULATION_SIZE, 
			10000 * MemeticOptimizer.POPULATION_SIZE, 
			60000
			);

	public final int maxIterationPerTarget;
	public final int maxIteration;
	public final long maxRunTime;
	
	public OptimizeParameter(
			int maxIterationPerTarget, 
			int maxIteration,
			long maxRunTime
			) {
		super();
		this.maxIterationPerTarget = maxIterationPerTarget;
		this.maxIteration = maxIteration;
		this.maxRunTime = maxRunTime;
	}
}
