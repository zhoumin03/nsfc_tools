package cn.edu.tsinghua.thss.randtest.rt.algorithm.util;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringEscapeUtils;

import cn.edu.tsinghua.thss.randtest.cases.SecondOrderEquationSolver.Result;

public class ClassUtils {
    private static final Set<Class<?>> WRAPPER_TYPES = getWrapperTypes();

    public static boolean isWrapperType(Class<?> clazz)
    {
        return WRAPPER_TYPES.contains(clazz);
    }

    private static Set<Class<?>> getWrapperTypes() {
        Set<Class<?>> ret = new HashSet<Class<?>>();
        ret.add(Boolean.class);
        ret.add(Character.class);
        ret.add(Byte.class);
        ret.add(Short.class);
        ret.add(Integer.class);
        ret.add(Long.class);
        ret.add(Float.class);
        ret.add(Double.class);
        ret.add(Void.class);
        return ret;
    }

	public static String strRepr(Object x) {
		if (x == null) {
			return "null";
		} else if (x instanceof Character) {
			return "'" + x + "'";
		} else if (x instanceof String) {
			return "\"" + StringEscapeUtils.escapeJava((String) x) + "\"";
		} else {
			Class<? extends Object> k = x.getClass();
			if (k.isArray()) {
				// array
				StringBuilder sb = new StringBuilder();
				sb.append("new " + k.getCanonicalName() + "{");

				if (x instanceof boolean[]) {
					boolean[] elements = (boolean[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof byte[]) {
					byte[] elements = (byte[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof short[]) {
					short[] elements = (short[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof char[]) {
					char[] elements = (char[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof int[]) {
					int[] elements = (int[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof long[]) {
					long[] elements = (long[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof float[]) {
					float[] elements = (float[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof double[]) {
					double[] elements = (double[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				} else if (x instanceof Object[]) {
					Object[] elements = (Object[]) x;
					if (elements.length > 0) {
						sb.append(ClassUtils.strRepr(elements[0]));
					}
					for (int i = 1; i < elements.length; i++) {
						sb.append(", ");
						sb.append(elements[i]);
					}
					sb.append("}");
				}
				return sb.toString();
			} else if (k.isEnum()) {
				// enum
				// return k.getCanonicalName() + "." + x.toString();
				return k.getSimpleName() + "." + x.toString();
			} else if (k.isPrimitive()) {
				// primitive
				return x.toString();
			} else if (isWrapperType(k)) {
				// wrapper of primitive types
				return x.toString();
			} else if (x instanceof Result) {
				// XXX:dirty hack
				return ((Result) x).strRepr();
			} else {
				throw new RuntimeException("Unhandled object to java string: " + x.getClass().getName());
			}
		}
	}

}
