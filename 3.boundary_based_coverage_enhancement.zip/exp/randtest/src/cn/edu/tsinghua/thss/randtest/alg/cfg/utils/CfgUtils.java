package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge.BranchType;
import cn.edu.tsinghua.thss.randtest.alg.core.ProblemDescription;

public class CfgUtils {

	/**
	 * 将CFG连接到block的后面
	 * @note: 如果此时CFG有合法的entry，则会被删除掉
	 * @param block
	 * @param cfg
	 * @param condition
	 */
	public static boolean concatenate(BasicBlock block, ControlFlowGraph cfg, 
			BranchType type) {
		if (cfg.hasValidEntry()) {
			BasicBlock dest = cfg.getBasicBlockAfterEntry();
			removeBasicBlock(cfg.getEntry());
			return concatenate(block, dest, type);
		} else {
			return false;
		}
	}

	public static boolean concatenate(BasicBlock block, ControlFlowGraph cfg) {
		return concatenate(block, cfg, BranchType.NON_CONDITIONAL);
	}

	/**
	 * 将block连接到CFG的后面
	 * @note: 如果此时CFG有合法的exit，则会被删除掉
	 * @param block
	 * @param cfg
	 * @param condition
	 */
	public static boolean concatenate(ControlFlowGraph cfg, BasicBlock block, 
			BranchType type) {
		if (cfg.hasValidExit()) {
			BasicBlock src = cfg.getBasicBlockBeforeExit();
			removeBasicBlock(cfg.getExit());
			return concatenate(src, block, type);
		} else {
			return false;
		}
	}

	public static boolean concatenate(ControlFlowGraph cfg, BasicBlock block) {
		return concatenate(cfg, block, BranchType.NON_CONDITIONAL);
	}

	/**
	 * 连接两个CFG
	 * @note: 将会删除前者的exit以及后者的entry
	 * @param g1
	 * @param g2
	 * @param condition
	 */
	public static boolean concatenate(ControlFlowGraph g1, ControlFlowGraph g2, 
			BranchType type) {
		if (g1.hasValidExit() && g2.hasValidEntry()) {
			BasicBlock src = g1.getBasicBlockBeforeExit();
			BasicBlock dest = g2.getBasicBlockAfterEntry();
			removeBasicBlock(g1.getExit());
			removeBasicBlock(g2.getEntry());
			return concatenate(src, dest, type);
		} else {
			return false;
		}
	}

	public static boolean concatenate(ControlFlowGraph g1, ControlFlowGraph g2) {
		return concatenate(g1, g2, BranchType.NON_CONDITIONAL);
	}

	/**
	 * 连接两个BasicBlock
	 * @param b1
	 * @param b2
	 * @param condition
	 */
	public static boolean concatenate(BasicBlock b1, BasicBlock b2, 
			BranchType type) {
		Edge.createAndAttach(b1, b2, type);
		return true;
	}

	public static boolean concatenate(BasicBlock b1, BasicBlock b2) {
		return concatenate(b1, b2, BranchType.NON_CONDITIONAL);
	}
	
	/**
	 * Collect forward reachable nodes
	 * 有时候需要扩展的节点以一个固定的顺序呈现，故返回一个List
	 * @param cfg
	 * @param forward
	 * @return
	 */
	public static List<BasicBlock> collectForwardReachableNodesFromEntry(
			ControlFlowGraph cfg) {
		return collectReachableNodes(cfg, cfg.getEntry(), true);
	}
	
	/**
	 * Collect forward reachable nodes
	 * 有时候需要扩展的节点以一个固定的顺序呈现，故返回一个List
	 * @param cfg
	 * @param forward
	 * @return
	 */
	public static List<BasicBlock> collectForwardReachableNodes(
			ControlFlowGraph cfg, BasicBlock start) {
		return collectReachableNodes(cfg, start, true);
	}
	
	/**
	 * Collect backward reachable nodes
	 * 有时候需要扩展的节点以一个固定的顺序呈现，故返回一个List
	 * @param cfg
	 * @param forward
	 * @return
	 */
	public static List<BasicBlock> collectBackwardReachableNodes(
			ControlFlowGraph cfg, BasicBlock start) {
		return collectReachableNodes(cfg, start, false);
	}
	
	/**
	 * Collect all nodes in a CFG
	 * 有时候需要扩展的节点以一个固定的顺序呈现，故返回一个List
	 * NOTE: 返回的节点顺序为按照从 entry 开始的距离升序排列，需要越大距离越远
	 * @param cfg
	 * @param forward true:forward; false:backward
	 * @return
	 */
	private static List<BasicBlock> collectReachableNodes(ControlFlowGraph cfg, 
			BasicBlock start, boolean forward) {
		List<BasicBlock> collection = new ArrayList<BasicBlock>();
		Queue<BasicBlock> visit = new LinkedList<BasicBlock>();
		
		// explore and collect all nodes
		collection.add(start);
		visit.add(start);
		while (!visit.isEmpty()) {
			BasicBlock current = visit.poll();
			// forward or backward
			List<BasicBlock> expand = forward ? 
					current.getOutBlocks() : current.getInBlocks();
			for (BasicBlock bb : expand) {
				if (collection.contains(bb)) {
					// exists, ignore
				} else {
					collection.add(bb);
					visit.add(bb);
				}
			}
		}
		return collection;
	}


	/** 
	 * remove a node from a CFG
	 * just remove and detach all its edges
	 * @param bb
	 */
	public static void removeBasicBlock(BasicBlock node) {
		// cache them in detachList to avoid concurrent modification
		List<Edge> detachList = new ArrayList<Edge>();
		detachList.addAll(node.getInEdges());
		detachList.addAll(node.getOutEdges());
		// detach
		for (Edge e : detachList) {
			e.detach();
		}
	}

	/**
	 * 计算针对Target的Isolation距离
	 * 
	 * @param target 目标的id
	 * @param pd
	 * @param isolation ID => isolation node or not
	 * @param distance ID => accumulated distance
	 */
	public static void calcIsolationGraph(ProblemDescription pd, int target, 
			List<Boolean> isolation, List<Double> distance) {
		// ancestors of target, nodes that are possible to reach target
		Set<BasicBlock> ancestors = new HashSet<BasicBlock>(
				collectBackwardReachableNodes(pd.cfg, pd.id2node(target)));
		// isolation
		for (int i = 0; i < pd.graphSize(); i++) {
			BasicBlock current = pd.id2node(i);
			if (i != target && ancestors.contains(current)) {
				boolean reach = false;
				boolean unreach = false;
				for (BasicBlock next: current.getOutBlocks()) {
					if (ancestors.contains(next)) {
						reach = true;
					} else {
						unreach = true;
					}
				}
				if (reach && unreach) {
					// isolation node
					isolation.add(true);
				} else {
					isolation.add(false);
				}
			} else {
				// non-ancestors are not isolation nodes
				// self is not an isolation node
				isolation.add(false);
			}
		}
		// distance
		for (int i = 0; i < pd.graphSize(); i++) {
			distance.add(Double.MAX_VALUE);
		}
		// pending 是当前被发现，且没有被扩展过的节点集合
		List<Integer> pending = new ArrayList<Integer>();
		// 所有被发现过的点（即：pending + explored）
		Set<Integer> seen = new HashSet<Integer>();
		// 所有被扩展过的点
		Set<Integer> explored = new HashSet<Integer>();
		seen.add(target);
		distance.set(target, 0.0);
		pending.add(target);
		int idxMinDist;
		while (pending.size() > 0) {
			// find the minimal node
			double minDist = distance.get(pending.get(0));
			idxMinDist = 0;
			for (int i = 1; i < pending.size(); i++) {
				double dist = distance.get(pending.get(i));
				if (dist < minDist) {
					minDist = dist;
					idxMinDist = i;
				}
			}
			// expand
			explored.add(pending.get(idxMinDist));
			BasicBlock current = pd.id2node(pending.get(idxMinDist));
			for (BasicBlock b : current.getInBlocks()) {
				int id = pd.node2id(b);
				double dist;
				if (isolation.get(id)) {
					dist = minDist + 1;
				} else {
					dist = minDist;
				}
				if (dist < distance.get(id)) {
					distance.set(id, dist);
					if (!explored.contains(id)) {
						pending.add(id);
						seen.add(id);
					}
				}
			}
			// update
			pending.set(idxMinDist, pending.get(pending.size() - 1));
			pending.remove(pending.size() - 1);
			seen.add(idxMinDist);
		}
	}
	
	/**
	 * 计算圈复杂度
	 * 对于单一Entry, 单一Exit的控制流图，圈复杂度等于 DecisionNode + 1
	 * @see http://en.wikipedia.org/wiki/Cyclomatic_complexity
	 * @param cfg
	 * @return
	 */
	public static int calcCyclomaticComplexity(ControlFlowGraph cfg) {
		List<BasicBlock> all = collectForwardReachableNodes(cfg, cfg.getEntry());
		int count = 0;
		for (BasicBlock b : all) {
			if (b.isDecisionBlock()) {
				count++;
			}
		}
		return count + 1;
	}
}
