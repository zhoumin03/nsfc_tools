package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import java.util.List;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.AssertStatement;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.EmptyStatement;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.LabeledStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.SynchronizedStatement;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TryStatement;
import org.eclipse.jdt.core.dom.TypeDeclarationStatement;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

public class CountStatementUtils {

	public static int countMethodDeclaration(MethodDeclaration md) {
		return countBlock(md.getBody());
	}

	/**
	 * if a statement is a simple statement
	 * 1. those simple Statements
	 * 2. Expression (which is used in ForStatement as initializer and updator)
	 * 
	 * @param stat
	 * @return
	 */
	private static boolean isSimpleStatement(ASTNode stat) {
		return stat instanceof SuperConstructorInvocation
				|| stat instanceof ExpressionStatement
				|| stat instanceof EmptyStatement
				|| stat instanceof ConstructorInvocation
				|| stat instanceof AssertStatement
				|| stat instanceof ThrowStatement
				|| stat instanceof TypeDeclarationStatement
				|| stat instanceof VariableDeclarationStatement
				|| stat instanceof Expression // <-- notice here
				|| stat instanceof BreakStatement
				|| stat instanceof ReturnStatement
				|| stat instanceof ContinueStatement
				|| stat instanceof SwitchCase
				;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static int countBlock(Block block) {
		List stats = block.statements();
		// already statement list, no need for conversion
		return countStatementList(stats);
	}

	private static int countStatementList(List<ASTNode> stats) {
		int count = 0;
		for (ASTNode stat : stats) {
			count += countAnyStatement((Statement) stat);
		}
		return count;
	}
	
	private static int countAnyStatement(Statement stat) {
		if (isSimpleStatement(stat)) {
			return 1;
		} else {
			return countComposedStatement((Statement) stat);
		}
	}

	private static int countComposedStatement(Statement stat) {
		throwExceptionOnUnhandledStatement(stat);
		if (stat instanceof Block) {
			return countBlock((Block) stat);
		} else if (stat instanceof ForStatement) {
			return countForStatement((ForStatement) stat);
		} else if (stat instanceof WhileStatement) {
			return countWhileStatement((WhileStatement) stat);
		} else if (stat instanceof DoStatement) {
			return countDoStatement((DoStatement) stat);
		} else if (stat instanceof IfStatement) {
			return countIfStatement((IfStatement) stat);
		} else if (stat instanceof SwitchStatement) {
			return countSwitchStatement((SwitchStatement) stat);
		} else if (stat instanceof TryStatement) {
			return countTryStatement((TryStatement) stat);
		} else if (stat instanceof SynchronizedStatement) {
			return countSynchronizedStatement((SynchronizedStatement) stat);
		} else {
			throw new IllegalArgumentException(
					"unhandled composed statement: " + stat.toString());
		}
	}

	/**
	 * 不+1
	 * @param stat
	 * @return
	 */
	private static int countSynchronizedStatement(SynchronizedStatement stat) {
		return countBlock(stat.getBody());
	}

	/**
	 * 不考虑catch和finally，不+1
	 * @param stat
	 * @return
	 */
	private static int countTryStatement(TryStatement stat) {
		return countBlock(stat.getBody());
	}

	@SuppressWarnings("unchecked")
	private static int countSwitchStatement(SwitchStatement stat) {
		return countStatementList(stat.statements()) + 1;
	}

	private static int countIfStatement(IfStatement stat) {
		int elseCount = (stat.getElseStatement() == null) ? 0 : countAnyStatement(stat.getElseStatement());
		return countAnyStatement(stat.getThenStatement()) + elseCount + 1;
	}

	private static int countDoStatement(DoStatement stat) {
		return countAnyStatement(stat.getBody()) + 1;
	}

	private static int countWhileStatement(WhileStatement stat) {
		return countAnyStatement(stat.getBody()) + 1;
	}

	private static int countForStatement(ForStatement stat) {
		return countAnyStatement(stat.getBody()) + stat.initializers().size() + stat.updaters().size() + 1;
	}

	/**
	 * 暂时不考虑EnhancedForStatement(可以手工转换为一般的ForStatement) 暂时不考虑LabeledStatement
	 * 
	 * @param stat
	 */
	private static void throwExceptionOnUnhandledStatement(Statement stat) {
		if (stat instanceof EnhancedForStatement) {
			throw new RuntimeException(
					"EnhancedForStatement should be converted to ForStatement first.");
		} else if (stat instanceof LabeledStatement) {
			throw new RuntimeException(
					"LabeledStatement is not supported.");
		}
	}

}
