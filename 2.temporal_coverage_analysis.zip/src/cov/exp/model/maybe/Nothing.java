package cov.exp.model.maybe;

public class Nothing<T> extends Maybe<T> {
	public static<T> Nothing<T> create() {
		return new Nothing<T>();
	}

	@Override
	public String toString() {
		return "[Nothing]";
	}
}
