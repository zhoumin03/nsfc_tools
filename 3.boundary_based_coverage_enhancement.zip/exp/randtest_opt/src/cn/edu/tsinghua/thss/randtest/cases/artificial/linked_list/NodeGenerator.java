package cn.edu.tsinghua.thss.randtest.cases.artificial.linked_list;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractWrappedGenerator;

public class NodeGenerator extends AbstractWrappedGenerator<Node> {

	@Override
	public Node nextRandom() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node nextBiasedRandom() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node nextNeighbour(Node current, double scale) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node[] allNeighbours(Node current, double scale) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node copy(Node origin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void registerSpecials() {
		// TODO Auto-generated method stub
		
	}

}
