package cov.exp.experiment;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import cov.exp.algorithm.AbstractProblem;
import cov.exp.algorithm.CoverageAnalyzer;
import cov.exp.algorithm.ExpParameter;
import cov.exp.model.Bin;
import cov.exp.model.CoverageEstimation;
import cov.exp.model.State;
import cov.exp.model.SystemModel;
import cov.exp.model.maybe.Maybe;

/**
 * �����е�С����
 * @author aleck
 *
 */
public class PaperExample1 {
	private static final String OUTPUT_FILE = "./data/results/paper-example/1/data.txt";

	public static class ExpSetting {
		public ExpParameter params;
		public SystemModel system;
		public Set<Integer> targets;
		
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			sb.append("n=" + params.nInputPins + ", ");
			sb.append("m=" + params.nFlipflops + ", ");
			sb.append("b=" + params.nBins + ", ");
			sb.append("t=" + params.targetSize + ", ");
			sb.append("M=" + params.cycles + ", ");
			sb.append("R=" + params.simulationRepeats + ", ");
			sb.append("init=" + params.initialStateRatio + ", ");
			sb.append("#init=" + system.initials.size() + ", ");
			sb.append("bug=" + params.bugDetectStateRatio);
			sb.append("]");
			return sb.toString();
		}
	}

	public static void main(String[] args) throws IOException {
		// manual test case 1
		ExpParameter params = new ExpParameter();
		params.nInputPins = 2;
		params.nFlipflops = 3;
		params.nBins = 8;
		params.bugDetectStateRatio = 0.125;
		params.cycles = 3;
		params.simulationRepeats = 10000;
		
		Set<Integer> targets = new HashSet<>();
		SystemModel system = new SystemModel();
		State s000 = new State();	s000.flipflops = 0;
		State s001 = new State();	s001.flipflops = 1;
		State s010 = new State();	s010.flipflops = 2;
		State s011 = new State();	s011.flipflops = 3;
		State s100 = new State();	s100.flipflops = 4;
		State s101 = new State();	s101.flipflops = 5;
		State s110 = new State();	s110.flipflops = 6;
		State s111 = new State();	s111.flipflops = 7;
		s111.bug = true;
		system.states = new State[] {s000, s001, s010, s011, s100, s101, s110, s111};
		// input: [i,r] - { -r-i, -r+i, +r-i, +r+i}
		s000.transitions = new State[] {s000, s001, s000, s000};
		s001.transitions = new State[] {s001, s010, s000, s000};
		s010.transitions = new State[] {s010, s011, s000, s000};
		s011.transitions = new State[] {s011, s100, s000, s000};
		s100.transitions = new State[] {s100, s101, s000, s000};
		s101.transitions = new State[] {s101, s110, s000, s000};
		s110.transitions = new State[] {s110, s111, s000, s000};
		s111.transitions = new State[] {s111, s000, s000, s000};
		Bin b0 = new Bin(0);
		Bin bx = new Bin(1);
		Bin b7 = new Bin(2);
		system.bins = new Bin[] {b0, bx, b7};
		b0.attach(s000);
		bx.attach(s001);
		bx.attach(s010);
		bx.attach(s011);
		bx.attach(s100);
		bx.attach(s101);
		bx.attach(s110);
		b7.attach(s111);
		system.addInitial(s000);
		system.params = params;
		system.numOfBins = 3;
		system.numOfInputPatterns = 4;
		system.numOfStates = 8;
		system.display(System.out);

		long timeStart = 0;
		
		// analyze
		timeStart = System.currentTimeMillis();
		CoverageAnalyzer analyzer = new CoverageAnalyzer(params, system);
		
		AbstractProblem ap = analyzer.abstraction(params, system);
		ap.q[2] = 1.0/4;
		ap.display(System.out);
		
		AbstractProblem nap = new AbstractProblem();
		nap.n = ap.n + 8;
		nap.init = new double[nap.n];
		nap.init[0] = 1.0;
		for (int i = 1; i < nap.n; i++) {
			nap.init[i] = 0;
		}
		// b0 -> b0 :: b0 -> y0 -> b0
		// bx -> bx :: bx -> y1 -> bx
		// b7 -> b7 :: b7 -> y2 -> b7
		// b0 -> bx :: b0 -> y3 -> bx
		// bx -> b0 :: bx -> y4 -> b0
		// bx -> b7 :: bx -> y5 -> b7
		// b7 -> b0 :: b7 -> y6(+) -> b0, b7 -> y7(-) -> b0
		double[][] op = ap.p;
		nap.p = new double[][] {
				// b0		bx		b7		y0		y1		y2		y3		y4		y5		y6(+)	y7(-)
				// b0
				{	0, 		0,		0,	op[0][0],	0,		0,	op[0][1],	0,		0,		0,		0,},
				// bx
				{	0,		0,		0,		0,	op[1][1],	0,		0,	op[1][0], op[1][2],	0,		0,},
				// b7
				{	0,		0,		0,		0,		0,	op[2][2],	0,		0,		0,	op[2][0]*1/3, op[2][0]*2/3,},
				// y0
				{	1,		0,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y1
				{	0,		1,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y2
				{	0,		0,		1,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y3
				{	0,		1,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y4
				{	1,		0,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y5
				{	0,		0,		1,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y6
				{	1,		0,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
				// y7
				{	1,		0,		0,		0,		0,		0,		0,		0,		0,		0,		0,},
		};
		
		// 						b0	bx	b7	y0	y1	y2	y3	y4	y5	y6(+)y7(-)
		nap.q = new double[] {	0, 	0, 	0, 	0, 	0, 	0, 	0, 	0, 	0, 	1, 	0};
		
		ap.display(System.out);
		nap.display(System.out);

		File output = new File(OUTPUT_FILE);
		if (!output.exists()) {
			output.getParentFile().mkdirs();
			output.createNewFile();
		}
		
		try (PrintStream ps = new PrintStream(output)) {
			for (int M = 1; M <= 1000; M++) {
				// CoverageEstimation ce1 = analyzer.analyze(M, targets, ap);
				CoverageEstimation ce2 = analyzer.analyze(M * 2 - 1, targets, nap);
				// System.out.println(String.format("[A][M=%d, P=%s]", M, ce1.r1.toString()));
				// double r = simulation(system, M, 10000, ce2.r1);
				// System.out.println(r);
				System.out.println(String.format("[M=%d][M'=%d][P=%s]", M, M * 2 + 1, ce2.r1.toString()));
				ps.println(M + "\t" + (M * 2 + 1) + "\t" + ce2.r1.toString());
			}
		}
	}

	private static double simulation(SystemModel system, int M, int SIMULATION_REPEATS, Maybe<Double> reference) {
		Random rand = new Random();
		int detected = 0;
		for (int repeats = 0; repeats < SIMULATION_REPEATS; repeats++) {
			State s = system.states[0];
			for (int i = 1; i <= M; i++) {
				int k = rand.nextInt(s.transitions.length);
				// states[7] => s_111, k == 3 => \neg r \land i
				if (s == system.states[7] && k == 1) {
					// bug detected
					detected ++;
					break;
				}
				s = s.transitions[k];
			}
		}
		return 1.0 * detected / SIMULATION_REPEATS;
	}
}
