package cn.edu.tsinghua.thss.randtest.cases;

public class FindMax {
	public static Integer max(int[] a) {
		if (a == null || a.length == 0)
			return null;
		else {
			int m = a[0];
			for (int i = 1; i < a.length; i++) {
				if (a[i] > m)
					m = a[i];
			}
			return m;
		}
	}
}
