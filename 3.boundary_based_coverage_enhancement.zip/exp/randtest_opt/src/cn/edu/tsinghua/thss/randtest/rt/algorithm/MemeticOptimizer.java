package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.variation.RandomFactory;


public class MemeticOptimizer extends AbstractOptimizer {
	// 种群大小
	public static final int POPULATION_SIZE		= 100;
	// 最多的重启次数
	private static final int MAX_RESTART		= 3;
	// 通过杂交获得的新个体个数
	private static final int CROSSOVER_SIZE 	= Math.max((int) (POPULATION_SIZE * 0.1), 1);
	// 通过自身变异获得的新个体个数
	@SuppressWarnings("unused")
	private static final int MUTATION_SIZE 		= Math.max((int) (POPULATION_SIZE * 0.1), 1);
	// 需要进行LocalSearch的个体个数
	private static final int LOCAL_SEARCH_SIZE 	= Math.max((int) (POPULATION_SIZE * 0.1), 1);
	// 每次LocalSearch搜索多少步？
	@SuppressWarnings("unused")
	private static final int LOCAL_SEARCH_STEP 	= 3;
	// 每次LocalSearch最多能够同时改变多少个参数？
	private static final int LOCAL_SEARCH_MAX_DIM = 2;
	// 是否必须对每个 target 都进行学习
	private static final boolean FORCE_TRAIN_EVERY_TARGET = true;
	
	private Random rand;
	private List<Chromosome> population;
	
	private Chromosome multiDimLocalSearchCurrentBest = null;
	
	private OptimizerLogger logger;
	
	public MemeticOptimizer(Category category, Evaluator evaluator, ProblemWrapper wrapper, OptimizerLogger logger) {
		super(category, evaluator, wrapper);
		population = new ArrayList<Chromosome>(POPULATION_SIZE);
		rand = RandomFactory.newInstance();
		
		this.logger = logger;
	}
	
	public void initialPopulation() {
		population.clear();
		for (int i = 0; i < POPULATION_SIZE; i++) {
			Input input = InputModifier.generateByPolicy(wrapper.getFormalParameter());
			Chromosome c = new Chromosome();
			c.input = input;
			c.fitness = evaluate(input);
			population.add(c);
		}
	}
	/**
	 * 返回当前领域内最好的一个邻居
	 * 总是返回一个copy
	 * @param input
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Chromosome singleDimLocalSearch(Chromosome base, double cooldown) {
		Chromosome best = null;
		for (int i = 0; i < base.input.fp.size(); i++) {
			Input current = InputModifier.copy(base.input);
			Object[] neighbours = wrapper.getFormalParameter().getGenerator(i)
					.allNeighbours(base.input.data[i], cooldown);
			for (int j = 0; j < neighbours.length; j++) {
				current.data[i] = neighbours[j];
				double fitness = evaluate(current);
				if (best == null || fitness > best.fitness) {
					best = new Chromosome(InputModifier.copy(current), fitness);
				}
			}
		}
		return best;
	}
	
	/**
	 * 改变多个维度的LocalSearch,最多改变LOCAL_SEARCH_MAX_DIM个维度
	 * @param reuseInput
	 * @param idx
	 * @param fieldsToModify 从当前（包括）维度往后，还有多少个维度需要更改
	 * @param cooldown 表示当前的搜索进度，它的取值范围是(0, 1]。越接近于0，搜索的范围被限制的越小
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public void multiDimLocalSearch(Input reuseInput, int idx, int fieldsToModify, double cooldown) {
		FormalParameter fp = wrapper.getFormalParameter();
		if (idx >= fp.size()) {
			double fitness = evaluate(reuseInput);
			if (multiDimLocalSearchCurrentBest == null ||
					fitness > multiDimLocalSearchCurrentBest.fitness) {
				multiDimLocalSearchCurrentBest = new Chromosome(
						InputModifier.copy(reuseInput), fitness);
			}
		} else {
			// 1. modify current
			if (fieldsToModify > 0) {
				Object old = reuseInput.data[idx];
				// (a) by mutation
				InputModifier.mutateField(reuseInput, idx);
				multiDimLocalSearch(reuseInput, idx + 1, fieldsToModify - 1, cooldown);
				// (b) by in the neighbourhood
				Object[] neighbours = fp.getGenerator(idx).allNeighbours(old, cooldown);
				for (int j = 0; j < neighbours.length; j++) {
					reuseInput.data[idx] = neighbours[j];
					multiDimLocalSearch(reuseInput, idx + 1, fieldsToModify - 1, cooldown);
				}
				reuseInput.data[idx] = old;
			}
			// 2. do not modify current
			multiDimLocalSearch(reuseInput, idx + 1, fieldsToModify, cooldown);
		}
	}
	
	public void memeticPhase(double cooldown) {
		boolean changed = false;
		for (int i = 0; i < LOCAL_SEARCH_SIZE; i++) {
			if (i >= population.size()) {
				break;
			}
			Chromosome base = population.get(i);
			Input input = InputModifier.copy(base.input);
			
			multiDimLocalSearchCurrentBest = null;
			multiDimLocalSearch(input, 0, LOCAL_SEARCH_MAX_DIM, cooldown);
			
			if (multiDimLocalSearchCurrentBest != null) {
				if (multiDimLocalSearchCurrentBest.fitness > base.fitness) {
					population.set(i, multiDimLocalSearchCurrentBest);
					multiDimLocalSearchCurrentBest = null;
					changed = true;
				}
			}
		}
		if (changed) {
			Collections.sort(population);
		}
	}

	public void geneticPhase() {
		for (int i = 0; i < CROSSOVER_SIZE; i++) {
			int ip1 = pickChromosome();
			int ip2 = pickChromosome();
			Chromosome p1, p2;
			p1 = population.get(ip1);
			p2 = population.get(ip2);
			Chromosome c = crossover(p1, p2);
			population.add(c);
//			// 如果杂交得到更好的，则替换父母中适应度较小的节点，避免出现很多统一领域内的节点
//			if (c.fitness > p1.fitness || c.fitness > p2.fitness) {
//				if (ip1 == ip2) {
//					population.set(ip1, c);
//				} else {
//					if (p1.fitness < p2.fitness) {
//						population.set(ip1, c);
//					} else {
//						population.set(ip2, c);
//					}
//				}
//			}
		}
		// 每次都要排序，效率不高？
		Collections.sort(population);
		while (population.size() > POPULATION_SIZE) {
			population.remove(population.size() - 1);
		}
	}
	
	@SuppressWarnings("unused")
	private Chromosome mutate(Chromosome base) {
		Input input = InputModifier.copy(base.input);
		// TODO: mutate 1 field, may not be good
		InputModifier.mutateField(input, rand.nextInt(wrapper.getFormalParameter().size()));
		
		Chromosome c = new Chromosome();
		c.input = input;
		c.fitness = evaluate(input);
		return c;
	}

	private Chromosome crossover(Chromosome c1, Chromosome c2) {
		Chromosome base, borrow;
		if (rand.nextBoolean()) {
			base = c1;
			borrow = c2;
		} else {
			base = c2;
			borrow = c1;
		}
		FormalParameter fp = wrapper.getFormalParameter();
		Input input = InputModifier.copy(base.input);
		// exchange certain parts, no more than 30% of input parameters
		// at least 1
		boolean crossed = false;
		for (int i = 0; i < fp.size(); i++) {
			if (rand.nextDouble() <= 0.3) {
				crossed = true;
				InputModifier.copyField(borrow.input, input, i);
			}
		}
		if (!crossed) {
			int idx = rand.nextInt(fp.size());
			InputModifier.copyField(borrow.input, input, idx);
		}
		// TODO: mutate 1 field, may not be good
		InputModifier.mutateField(input, rand.nextInt(fp.size()));
		
		Chromosome c = new Chromosome();
		c.input = input;
		c.fitness = evaluate(input);
		return c;
	}

	/**
	 * 选取前50%中的染色体
	 * 按照概率选取，越靠前的被选中概率越大
	 * chromosome	1 2 3 4 5 6 7 8 9
	 * probability	9 8 7 6 5 4 3 2 1
	 * @return
	 */
	private int pickChromosome() {
		int n = population.size();
		// n, (n-1), (n-2), ..., 1, sum=n(n+1)/2
		int sum = n * (n + 1) / 2;
		int r = rand.nextInt(sum) + 1;
		// 1 + 2 + ... + t >= r >= 1 + 2 + ... + (t - 1)
		// t^2 + t = (t+1)^2 - (t+1) >= 2r > t^2 - t
		// t 取值 [1, ..., n]
		// 令 t0 = sqrt(2r) 是符合要求的
		// 并且 f(t) = t^2-t 在 >=1 时 单调增加
		// 可以证明取 round(sqrt(2r)) 是合理的
		int t = (int) Math.round(Math.sqrt(2 * r));
		// t为从后往前的坐标，从1开始计数
		return (n - t);
	}

	private void genAndSortPopulation() {
		initialPopulation();
		Collections.sort(population);
	}
	
	@Override
	public void execute(OptimizeParameter parameter, ProblemWrapper wrapper) {
		// TargetManager is already cleared
		
		// init
		int iteration = 0;
		logger.init();

		// start to count time
		clockStart();
		
		// try it randomly
		final int MAX_RANDOM_ITERATIONS = parameter.maxIteration / 20;	// 5% random iterations
		for (int i = 0; i < MAX_RANDOM_ITERATIONS && tm.remainsToBeCovered(); i++) {
			initialPopulation();
			iteration ++;
		}
		
		// 直到没有下一个目标
		while (tm.remainsToBeCovered()) {
			tm.pickAnyRemainingTarget();
			// 选取一个target，初始化并且开始迭代
			
			// 允许restart若干次
			int restart = 0;
			while (restart < MAX_RESTART && !tm.currentTargetCovered()) {
				// 直到当前target被覆盖
				System.out.println("- try to cover " + tm.currentTarget() + ", round " + (restart + 1));

				int iterationForThisTarget = 1;
				
				logger.logRemaining(tm.numOfRemainingTargets());
				
				genAndSortPopulation();
				while (!tm.currentTargetCovered()) {
					if (iteration >= parameter.maxIteration || 
							iterationForThisTarget >= parameter.maxIterationPerTarget) {
						break;
					}
					// System.out.println("#" + iteration + " remaining " + numOfRemainingTargets());
					
					logger.logBestFitness(tm.currentTarget(), currentBestFitness());
					logger.logRemaining(tm.numOfRemainingTargets());
					
					geneticPhase();
					// calculate cooldown based on progress
					double cooldown = calcCooldown(1.0 * iterationForThisTarget / parameter.maxIterationPerTarget);
					memeticPhase(cooldown);
					
					iterationForThisTarget ++;
					iteration ++;
				}
				
				if (tm.currentTargetCovered()) {
					// approaching the boundary
					for (int i = 0; i < parameter.maxIterationPerTarget / 2; i++) {
						geneticPhase();
						memeticPhase(1.0 * 2 * i / parameter.maxIterationPerTarget);
					}
					// register test cases for the current target
					tm.registerTestCase(population);
					// 覆盖到
					logger.logBestFitness(tm.currentTarget(), currentBestFitness());
					logger.logEffort(tm.currentTarget(), iterationForThisTarget);
					break;
				} else if (restart + 1 >= MAX_RESTART) {
					// 未覆盖到，且达到上限
					System.out.println("abandon target: " + tm.currentTarget());
					tm.abandonTarget(tm.currentTarget());
					break;
				} else {
					// 未覆盖到，且未达到上限
					// just continue
				}
				
				restart ++;
			}
		}
		
		if (FORCE_TRAIN_EVERY_TARGET) {
			// 补充对每个目标执行Memetic算法，主要用于提高通过自动化算法没有覆盖到的target的覆盖性
			// 总共进行 parameter.iteration次，因此效率最低是2倍
			int nTrainedTargets = 0;
			for (TestTarget target : tm.getAllTargets()) {
				if (tm.hasTrained(target))
					nTrainedTargets ++;
			}
			if (nTrainedTargets < tm.numOfAllTargets()) {
				for (TestTarget target : tm.getAllTargets()) {
					if (!tm.hasTrained(target)) {
						tm.setCurrentTarget(target);
						int maxRemedyIterPerTarget = Math.max(
								Math.min(
										parameter.maxIteration / (tm.numOfAllTargets() - nTrainedTargets),
										parameter.maxIterationPerTarget / 4
										),
								100
								);
						initialPopulation();
						for (int i = 0; i < maxRemedyIterPerTarget; i++) {
							geneticPhase();
							// calculate cooldown based on progress
							double cooldown = calcCooldown(1.0 * i / maxRemedyIterPerTarget);
							memeticPhase(cooldown);
						}
					}
					if (tm.currentTargetCovered()) {
						// register test cases for the current target
						tm.registerTestCase(population);
					}
				}
			}
		}
		
		logger.logRemaining(tm.numOfRemainingTargets());
		logger.logPerformance(tm.numOfAllTargets(), tm.numOfCoveredTargets(), tm.numOfAbandonedTargets(), iteration, currentTimeConsumed());
		
		if (tm.allTargetCovered()) {
			System.out.println("all target covered after " + iteration + " iterations.");
		} else {
			System.out.println("stopped after " + iteration + " iterations.");
			System.out.println("covered=" + tm.numOfCoveredTargets() + ", abandon=" + tm.numOfAbandonedTargets());
		}
	}

	private double calcCooldown(double progress) {
		// scale cooldown such that: 80% left after 50% progress
		return 1.0 - progress;
	}

	private double currentBestFitness() {
		if (population.size() > 0) {
			return population.get(0).fitness;
		} else {
			return -Double.MAX_VALUE;
		}
	}
}
