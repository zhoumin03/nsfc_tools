package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.IsPowerOfTwo;
import cn.edu.tsinghua.thss.randtest.cases.IsPowerOfTwoRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class IsPowerOfTwoProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Long.class)
				);
		return fp;
	}

	@Override
	public Object invoke(Input input) {
		return IsPowerOfTwo.isPowerOfTwo((Long) input.data[0]);
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new IsPowerOfTwoRuntimeAssist();
	}

}
