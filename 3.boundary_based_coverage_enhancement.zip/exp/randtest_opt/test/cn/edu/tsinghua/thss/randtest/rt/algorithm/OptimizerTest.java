package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.Evaluator.Strategy;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.StatisticUtils.StatResult;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;

/**
 * 用于执行Optimizer并且统计数据的类
 * @author aleck
 *
 */
public abstract class OptimizerTest {
	protected static final String GLOBAL_LOG_FILE = "./data/log/global.txt";
	private static final DateFormat df = new SimpleDateFormat("yyyyMMdd_HH:mm:ss");

	// 这里只保存已经实现了的方法，全集应该参考OptimizeParameter
	private static final Category[] CATEGORIES = new Category[] { Category.STATEMENT, Category.BRANCH };
	private static final Strategy[] STRATEGIES = new Strategy[] { Strategy.NODE_ONLY, Strategy.NODE_PLUS_DIST };
	
	protected static int numOfCombCategoryAndStrategy() {
		return CATEGORIES.length * STRATEGIES.length;
	}
	
	protected static void setCategoryAndStrategy(int i) {
		if (i < 0 || i >= numOfCombCategoryAndStrategy()) {
			throw new IllegalArgumentException("invalid combination id: " + i);
		} else {
			int cid = i / STRATEGIES.length;
			int sid = i % STRATEGIES.length;
			OptimizeParameter.setCategory(CATEGORIES[cid]);
			OptimizeParameter.setStrategy(STRATEGIES[sid]);
		}
	}
	
	private int repeat;
	private List<OptimizerLogger> loggers;
	private ProblemWrapper wrapper;
	
	protected OptimizerTest(int repeat) {
		this.repeat = repeat;
		createLoggers();
	}
	
	protected void createLoggers() {
		loggers = new ArrayList<OptimizerLogger>();
		for (int i = 0; i < repeat; i++) {
			loggers.add(new OptimizerLogger());
		}
	}
	
	protected OptimizerLogger getLogger(int idx) {
		return loggers.get(idx);
	}
	
	protected int getRepeat() {
		return repeat;
	}
	
	protected void setCurrentWrapper(ProblemWrapper wrapper) {
		this.wrapper = wrapper;
	}
	
	protected ProblemWrapper getCurrentWrapper() {
		return wrapper;
	}
	
	protected void statistics(PrintStream ps) {
		int totalTargets 	= getLogger(0).getTotalTargets();
		double[] iter		= new double[getRepeat()];
		int[] covered		= new int[getRepeat()];
		double[] coverage	= new double[getRepeat()];
		double[] time		= new double[getRepeat()];
		for (int i = 0; i < getRepeat(); i++) {
			OptimizerLogger logger = getLogger(i);
			iter[i] = logger.getIterationUsed();
			covered[i] = logger.getCoveredTargets();
			coverage[i] = 1.0 * logger.getCoveredTargets() / logger.getTotalTargets();
			time[i] = 1.0 * logger.getTimeConsumed() / 1000;
		}
		StatResult srIter = StatisticUtils.stat(iter);
		StatResult srCovered = StatisticUtils.stat(covered);
		StatResult srCoverage = StatisticUtils.stat(coverage);
		StatResult srTime = StatisticUtils.stat(time);
		int maxCover = totalTargets;
		int maxCoverCount = 0;
		do {
			maxCoverCount = StatisticUtils.count(covered, maxCover);
			if (maxCoverCount > 0) {
				break;
			} else {
				maxCover --;
			}
		} while (true);
		
		// print to PrintStream
		ps.println(">>>-------------------------------------");
		ps.println("timestamp=" 	+ df.format(Calendar.getInstance().getTime()));
		ps.println("statement=" 	+ RT.getStatementCount());
		ps.println("cyclomatic=" 	+ RT.getCyclomaticComplexity());
		ps.println("category=" 		+ OptimizeParameter.getCategory());
		ps.println("strategy=" 		+ OptimizeParameter.getStrategy());
		ps.println("optimizer=" 	+ this.getClass().getName());
		ps.println("problem=" 		+ this.wrapper.getClass().getName());
		ps.println("repeat=" 		+ getRepeat());
		ps.println("targets=" 		+ totalTargets);
		ps.println("iteration=" 	+ srIter.toString());
		ps.println("covered=" 		+ srCovered.toString());
		ps.println("coverage=" 		+ srCoverage.toString());
		ps.println("max_cover=" 	+ maxCover);
		ps.println("max_cover_cnt=" + maxCoverCount + "(" + (100.0 * maxCoverCount / getRepeat()) + "%)");
		ps.println("time=" 			+ srTime.toString());
		ps.println("<<<-------------------------------------");
		
		// print to Console
		System.out.println("----------------------------------------");
		System.out.println(df.format(Calendar.getInstance().getTime()));
		System.out.println("#Statment=" 	+ RT.getStatementCount());
		System.out.println("Cyclomatic=" 	+ RT.getCyclomaticComplexity());
		System.out.println("CATEGORY:\t"	+ OptimizeParameter.getCategory());
		System.out.println("STRATEGY:\t" 	+ OptimizeParameter.getStrategy());
		System.out.println("OPTIMIZER:\t" 	+ this.getClass().getSimpleName());
		System.out.println("PROBLEM:\t" 	+ this.wrapper.getClass().getSimpleName());
		System.out.println("targets:\t" 	+ totalTargets);
		System.out.println("iteration:\t" 	+ srIter.toString());
		System.out.println("covered:\t" 	+ srCovered.toString());
		System.out.println("coverage:\t" 	+ srCoverage.toString());
		System.out.println("max_cover=" 	+ maxCover);
		System.out.println("max_cover_cnt=" + maxCoverCount + "(" + (100.0 * maxCoverCount / getRepeat()) + "%)");
		System.out.println("time:\t\t" 		+ srTime.toString());
	}

	/**
	 * 执行前的所有准备
	 */
	public abstract void setUp();
	
	// run test for 1 problem (may run for several rounds)
	protected abstract void runTest();
	
	/**
	 * 执行后的处理
	 */
	public abstract void tearDown();
	
	/**
	 * 执行优化，3步合一
	 */
	public void optimize() {
		setUp();
		runTest();
		tearDown();
	}
}
