package randtest;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import sut.CtrlDepGraph;
import sut.TriangleClassifier;

public class RandTestCaseRunner {

	private static final int MAX_INT = 10000;
	
	private static Random rand = new Random();
	private static TriangleClassifier tc = new TriangleClassifier();
	private static Queue<String> targets = new LinkedList<String>();
	
	public static void main(String[] args) {
		int rounds = 0;
		
		rand.setSeed(0);
		targets.addAll(CtrlDepGraph.targets);
		
		TestInput instance = newRandTestCase();
		
		List<TestInput> selection = new ArrayList<TestInput>();

		String target = targets.peek();
		System.out.println("*** target is: " + target);
		PathFitness fitness = new PathFitness(tc, targets.peek());
		
		while (true) {
			rounds ++;
			
			PathFitnessValue pfv = (PathFitnessValue) fitness.eval(instance);
			
			if (pfv.path.contains(target)) {
				selection.add(instance);
				targets.poll();
				
				System.out.println("*** current rounds=" + rounds);
				
				if (completelyCovered()) {
					break;
				}

				target = targets.peek();
				fitness = new PathFitness(tc, target);

				System.out.println("*** target is: " + target);
			} else {
				instance = newRandTestCase();
			}
		}
		
		System.out.println("Achived after " + rounds + " rounds.");
	}

	private static boolean completelyCovered() {
		return targets.isEmpty();
	}

	private static TestInput newRandTestCase() {
		TestInput ti = new TestInput();
		ti.a = rand.nextInt() % MAX_INT;
		ti.b = rand.nextInt() % MAX_INT;
		ti.c = rand.nextInt() % MAX_INT;
		
		System.out.println("new testcase: " + ti.toString());
		
		return ti;
	}
}
