package algorithm.test;

import algorithm.Palindromic;
import junit.framework.TestCase;

public class PalindromicTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T3_5, T2_3]
	public void test00() {
		assertEquals((false), 
				Palindromic.isPalindromic((String) ("BaA"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T3_5, T3_6, T2_3]
	public void test01() {
		assertEquals((false), 
				Palindromic.isPalindromic((String) ("\t\"\u00C6w;\t"))
				);
	}
	//<<case-end>>
}
