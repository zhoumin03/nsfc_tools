package cov.exp.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import cov.exp.model.Bin;
import cov.exp.model.CoverageEstimation;
import cov.exp.model.State;
import cov.exp.model.SystemModel;
import cov.exp.model.maybe.Just;
import cov.exp.model.maybe.Nothing;

public class Simulator {
	public void simulate(SystemModel system, DataCollector collector, int cycles, Random rand) {
		State init = system.initials.get(rand.nextInt(system.initials.size()));
		collector.reach(init);
		State current = init;
		for (int i = 0; i < cycles; i++) {
			int randInput = rand.nextInt(system.numOfInputPatterns);
			current = current.transitions[randInput];
			collector.reach(current);
		}
	}
	
	public CoverageEstimation batchSimulation(SystemModel system, int cycles, Set<Integer> subset, int repeats, Random rand) {
		int detected = 0;
		int coverAny = 0;
		int coverAnyAndDetected = 0;
		int coverAll = 0;
		int coverAllAndDetected = 0;
		for (int i = 0; i < repeats; i++) {
			DataCollector collector = new DataCollector();
			simulate(system, collector, cycles, rand);
			if (collector.isBugDetected())
				detected ++;
			// see how many bins are reached
			Set<Bin> bins = collector.summarizeReachedBins();
			Set<Integer> bids = new HashSet<>();
			for (Bin b : bins) {
				bids.add(b.id());
			}
			boolean any = !Collections.disjoint(bids, subset);
			boolean all = true;
			for (int bid : subset) {
				if (!bids.contains(bid)) {
					all = false;
					break;
				}
			}
			if (any) {
				coverAny ++;
				if (collector.isBugDetected())
					coverAnyAndDetected ++;
			}
			if (all) {
				coverAll ++;
				if (collector.isBugDetected())
					coverAllAndDetected ++;
			}
		}
		CoverageEstimation ce = new CoverageEstimation();
		if (repeats > 0) {
			ce.r1 = Just.create(1.0 * detected / repeats);
		} else {
			ce.r1 = Nothing.create();
		}
		if (coverAny > 0) {
			ce.r2 = Just.create(1.0 * coverAnyAndDetected / coverAny);
		} else {
			ce.r2 = Nothing.create();
		}
		if (coverAll > 0) {
			ce.r3 = Just.create(1.0 * coverAllAndDetected / coverAll);
		} else {
			ce.r3 = Nothing.create();
		}
		return ce;
	}

	public List<DataCollector> simulateWithVariousCycles(SystemModel system, ExpParameter params, Random rand) {
		List<DataCollector> dcs = new ArrayList<>();
		for (int i = 0; i < params.simulationRepeats; i++) {
			DataCollector dc = new DataCollector();
			// random value in [1, params.cycles]
			int cycles = 1 + rand.nextInt(params.cycles);
			simulate(system, dc, cycles, rand);
			dcs.add(dc);
		}
		return dcs;
	}
}
