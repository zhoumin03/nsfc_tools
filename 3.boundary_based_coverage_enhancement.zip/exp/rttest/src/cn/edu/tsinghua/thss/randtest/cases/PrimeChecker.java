package cn.edu.tsinghua.thss.randtest.cases;

public class PrimeChecker {

	public boolean isPrime(int n) {
		if (n <= 1) {
			return false;
		} else if (n > 100000000) {
			// I don't accept large input
			return false;
		}
		int m = (int) Math.sqrt(n);
		boolean isPrime = true;
		for (int i = 2; i <= m; i++) {
			if (n % i == 0) {
				isPrime = false;
				break;
			}
		}
		// force isPrime = true|false to be covered
		if (isPrime) {
			return isPrime;
		} else {
			return isPrime;
		}
	}
	
}
