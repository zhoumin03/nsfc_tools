package cn.edu.tsinghua.thss.randtest.cases;

public class AlphabetChecker {
	public static boolean isAlphabet(char c) {
		boolean isLower;
		boolean isUpper;
		if ('a' <= c && c <= 'z')
			isLower = true;
		else
			isLower = false;
		if ('A' <= c && c <= 'Z')
			isUpper = true;
		else
			isUpper = false;
		return isLower || isUpper;
	}
}
