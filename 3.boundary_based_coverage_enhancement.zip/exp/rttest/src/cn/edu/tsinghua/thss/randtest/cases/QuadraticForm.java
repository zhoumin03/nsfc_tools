package cn.edu.tsinghua.thss.randtest.cases;

public class QuadraticForm {
    public static class QuadraticType {
        public int value;

        public QuadraticType() { }
        
        public QuadraticType(int value) { 
        	this.value = value;
        }

        public static final int Universe = -1;
        public static final int Empty = 0;
        public static final int Degenerate = 1;
        
        public static final int Ellipse = 2;
        public static final int Parabola = 4;
        public static final int Hyperbola = 8;
        
        public static final int PointEllipse = Ellipse | Degenerate;
        public static final int ParallelLines = Parabola | Degenerate;
        public static final int IntersectedLines = Hyperbola | Degenerate;

        public static final int Line = Degenerate | 16;
        
        public static final int Circle = Ellipse | 32;
        public static final int RectangularHyperbola = Hyperbola | 64;
    };

    public static int getGeometryType(double A, double B, double C, double D, double E, double F) {
        //B/4(ED-BF)
        if ((A == 0) && (B == 0) && (C == 0))
        {
            if ((D == 0) && (E == 0))
                if (F == 0)
                    return QuadraticType.Universe;
                else
                    return QuadraticType.Empty;
            else
                return QuadraticType.Line;
        }

        // now, A != 0 || B != 0 || C != 0
        double delta = (A * C - B * B / (double)(4)) * F + B * E * D / (double)(4) 
                            - C * D * D / (double)(4) - A * E * E / (double)(4);
        double d = B * B - A * C * (double)(4);
        if (delta == 0)
        {
            // degenerate cases
            if (d < 0)
                return QuadraticType.PointEllipse;
            else if (d > 0)
                return QuadraticType.IntersectedLines;
            else
                return QuadraticType.ParallelLines;
        }

        // non-degenerate cases
        if (d < 0)
        {
            if (C * delta > 0)
                return QuadraticType.Empty;
            else if ((B == 0) && (A - C == 0))
                return QuadraticType.Circle;
            else
                return QuadraticType.Ellipse;
        }
        if (d == 0)
        {
            return QuadraticType.Parabola;
        }
        // d > 0
        if (A + C == 0)
            return QuadraticType.RectangularHyperbola;
        else
            return QuadraticType.Hyperbola;
    }
}

