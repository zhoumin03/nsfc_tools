package cn.edu.tsinghua.thss.randtest.rt.algorithm;

public class StatisticUtils {
	public static class StatResult {
		final public double average;
		final public double min;
		final public double max;
		final public double stdev;
		
		public StatResult(double average, double min, double max, double stdev) {
			super();
			this.average = average;
			this.min = min;
			this.max = max;
			this.stdev = stdev;
		}
		
		public String toString() {
			return String.format("(min=%f, max=%f, average=%f, stdev=%f)", min, max, average, stdev);
		}
	}
	
	public static StatResult stat(int[] data) {
		double[] ds = new double[data.length];
		for (int i = 0; i < data.length; i++) {
			ds[i] = data[i];
		}
		return stat(ds);
	}
	
	public static StatResult stat(double[] data) {
		double average;
		double min;
		double max;
		double stdev;
		double sum = 0;
		min = Double.MAX_VALUE;
		max = -Double.MAX_VALUE;
		for (int i = 0; i < data.length; i++) {
			double d = data[i];
			if (d < min) {
				min = d;
			}
			if (d > max) {
				max = d;
			}
			sum += d;
		}
		if (data.length == 0) {
			throw new IllegalArgumentException("too few data: size=" + data.length);
		} else if (data.length == 1) {
			average = sum / data.length;
			stdev = 0;
		} else {
			average = sum / data.length;
			double x = 0;
			for (int i = 0; i < data.length; i++) {
				x += (data[i] - average) * (data[i] - average);
			}
			stdev = Math.sqrt(x / (data.length - 1));
		}
		
		return new StatResult(average, min, max, stdev);
	}

	public static int count(int[] array, int key) {
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] == key) {
				count++;
			}
		}
		return count;
	}
}
