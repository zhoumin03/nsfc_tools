package algorithm.test;

import junit.framework.TestCase;
import algorithm.StringIsNumber;

public class StringIsNumberTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T24_29, T5_7, T17_24, T24_30, T9_12, T12_17, T1_3]
	public void test00() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("..1"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T32_37, T13_18, T12_17, T1_3, T28_36, T36_42, T23_28, T37_43, T5_7, T18_26, T12_16, T26_32, T17_23, T9_12]
	public void test01() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("6e."))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T26_32, T9_13, T1_3]
	public void test02() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("a"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T26_32, T9_13, T46_47, T1_3]
	public void test03() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("L"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T5_6, T8_10, T1_3]
	public void test04() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("0x"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T23_27, T27_34, T27_33, T12_17, T1_3, T28_36, T36_42, T23_28, T33_40, T5_7, T12_16, T17_23, T9_12]
	public void test05() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("5E+'!C"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#6, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T17_24, T26_32, T24_30, T9_12, T12_17, T1_3]
	public void test06() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) (".a"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#7, coverages: [T28_36, T23_28, T5_7, T36_41, T17_23, T9_12, T12_17, T1_3]
	public void test07() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("ejYpCqn"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#8, coverages: [T5_7, T13_18, T18_26, T26_31, T9_13, T1_3]
	public void test08() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("e"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#9, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T26_32, T9_13, T1_3]
	public void test09() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("a"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#10, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T26_32, T9_13, T1_3]
	public void test10() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("-M"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#11, coverages: [T23_27, T5_7, T33_39, T12_16, T27_33, T17_23, T9_12, T12_17, T1_3]
	public void test11() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("9+ "))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#12, coverages: [T5_7, T13_19, T9_13, T1_3]
	public void test12() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("-"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#13, coverages: [T37_44, T5_7, T32_37, T13_18, T18_26, T12_16, T26_32, T9_12, T1_3]
	public void test13() {
		assertEquals((true), 
				StringIsNumber.isNumber((String) ("3."))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#14, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T26_32, T9_13, T1_3]
	public void test14() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("\t"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#15, coverages: [T5_7, T13_18, T38_46, T18_26, T32_38, T46_48, T26_32, T9_13, T1_3]
	public void test15() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("a"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#16, coverages: [T5_7, T13_18, T18_26, T38_45, T32_38, T26_32, T9_13, T1_3]
	public void test16() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("d"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#17, coverages: [T28_36, T23_28, T5_7, T36_41, T17_23, T9_12, T12_17, T1_3]
	public void test17() {
		assertEquals((false), 
				StringIsNumber.isNumber((String) ("Ea"))
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#18, coverages: [T5_7, T13_18, T18_25, T9_13, T1_3]
	public void test18() {
		assertEquals((true), 
				StringIsNumber.isNumber((String) ("1"))
				);
	}
	//<<case-end>>
}
