package cn.edu.tsinghua.thss.randtest.alg.core;

public class ModificationListener {
	private boolean modified = false;
	private ProblemDescription pd = null;
	
	public boolean isModified() {
		return modified;
	}
	
	public void notifyModified() {
		modified = true;
	}
	
	public void registerProblemDescription(ProblemDescription pd) {
		this.pd = pd;
	}
	
	public ProblemDescription getProblemDescription() {
		return this.pd;
	}
}
