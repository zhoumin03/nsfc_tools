import java.util.List;


public class SampleJavaProgram {
	// A complex method which contains different kinds of structures
	public void complexMethod() {
		for (int i = 0; i < 100; i++) {
			if (i < 10) {
				try {
					int delay = 1000;
					switch (i) {
					case 0:
						delay = 1000;
						break;
					case 1:
					case 2:
					case 3:
						delay = 2000;
						break;
					case 4:
						delay = 3000;
					case 5:
						delay = 4000;
					case 6:
						delay = 5000;
						break;
					default:
						delay = 1000;
					}
					Thread.sleep(delay);
				} catch (RuntimeException e1) {
					int x;
					while (true)
						x = 1;
					while (true) {
						int i, j, k;
						i = j = k = 0;
						k = i & j;
						boolean b;
						b = (true && false);
						if (true || !(i > j) && i < k) 
							break;
						else if (j == k)
							break;
						else
							break;
					}
				} catch (RuntimeException e2) {
					int t = 0;
					List<Integer> list = null;
					for (int i : list) {
						continue;
					}
					for (int i = 0, t = 0; i < list.size(); i++, t++) {
						continue;
					}
				}
			}
		}
	}

	public void testFor() {
		for (int i = 0; i < 100; i++)
			i++;
		for (int i = 0; i < 100; i++) {
			break;
		}
	}

	public void testSwitch() {
		switch (i) {
		case 0:
			delay = 1000;
			break;
		case 1:
		case 2:
		case 3:
			delay = 2000;
			break;
		case 4:
			delay = 3000;
		case 5:
			delay = 4000;
		case 6:
			delay = 5000;
			break;
		default:
			delay = 1000;
		}
	}
	
	public void testBlock() {
		int delay = 1000;
		switch (i) {
		case 0:
			delay = 1000;
			break;
		case 1:
		case 2:
		case 3:
			delay = 2000;
			break;
		case 4:
			delay = 3000;
		case 5:
			delay = 4000;
		case 6:
			delay = 5000;
			break;
		default:
			delay = 1000;
		}
		Thread.sleep(delay);
	}
	
	public void testTry() {
		try {
			int delay = 1000;
			switch (i) {
			case 0:
				delay = 1000;
				break;
			case 1:
			case 2:
			case 3:
				delay = 2000;
				break;
			case 4:
				delay = 3000;
			case 5:
				delay = 4000;
			case 6:
				delay = 5000;
				break;
			default:
				delay = 1000;
			}
			Thread.sleep(delay);
		} catch (RuntimeException e1) {
			int x;
			while (true)
				x = 1;
			while (true) {
				int i, j, k;
				i = j = k = 0;
				if (true || !(i > j) && i < k) 
					break;
				else if (j == k)
					break;
				else
					break;
			}
		} catch (RuntimeException e2) {
			int t = 0;
			List<Integer> list = null;
			for (int i : list) {
				continue;
			}
			for (int i = 0, t = 0; i < list.size(); i++, t++) {
				continue;
			}
		}
	}
	
	public void testIf() {
		int i, j, k;
		i = 1;
		if (true)
			k = 1;
		else
			k = 2;
		k = 0;
		if (i > 0 && (!(k < 0) || j != 0)) {
			if (j != 0) {
				k = 1;
			}
		} else if (i == 0) {
			
		} else {
			
		}
		i = 0;
	}
	
	public void testWhile() {
		int x;
		while (true)
			x = 1;
		while (true) {
			int i, j, k;
			i = j = k = 0;
			if (true || !(i > j) && i < k) 
				break;
			else if (j == k)
				break;
			else
				break;
		}
	}
	
	public void testCondition() {
		int i, j, k, l;
		
		if (i < k || !(i < j && j < k)) {
			l = 0;
		} else {
			l = 1;
		}
	}
}
