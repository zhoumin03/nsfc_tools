package algorithm.test;

import junit.framework.TestCase;
import algorithm.FindMax;

public class FindMaxTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//<$c>
	public void test$$() {
		Object[] data = (Object[]) ($0);
		int[] a = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
		}
		assertEquals((int)($_), FindMax.max(a));
	}
	//<<case-end>>
}