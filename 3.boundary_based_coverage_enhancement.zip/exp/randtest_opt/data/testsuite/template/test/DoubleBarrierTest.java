package algorithm.test;

import cn.edu.tsinghua.thss.randtest.cases.test.DoubleBarrier;
import junit.framework.TestCase;

public class IntBarrierTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//<$c>
	public void test$$() {
		assertEquals(($_), DoubleBarrier.f((double) $0));
	}
	//<<case-end>>
}
