package algorithm.test;

import algorithm.AlphabetChecker;
import junit.framework.TestCase;

public class AlphabetCheckerTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//#0, coverages: [T5_7, T2_3]
	public void test00() {
		assertEquals((true), AlphabetChecker.isAlphabet('b'));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_4, T5_7]
	public void test01() {
		assertEquals((false), AlphabetChecker.isAlphabet('['));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T2_4, T5_7]
	public void test02() {
		assertEquals((false), AlphabetChecker.isAlphabet('['));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T5_6, T2_4]
	public void test03() {
		assertEquals((true), AlphabetChecker.isAlphabet('B'));
	}
	//<<case-end>>
}
