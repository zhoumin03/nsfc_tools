package cn.edu.tsinghua.thss.randtest.cases;

public class Newton {
	public static double sqrt(double x) {
		if (x < 1e-9) {
			return 0;
		} else if (x > 1e40) {
			return 0;
		} else {
			double k = 1.0; // 可任取
			while (Math.abs(k * k - x) > 1e-8 * x) {
				k = (k + x / k) / 2;
			}
			return k;
		}
	}
}
