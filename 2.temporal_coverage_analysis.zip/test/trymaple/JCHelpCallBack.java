package trymaple;

/* import the required classes */
import java.util.Vector;

import com.maplesoft.openmaple.HelpCallBacks;

/* implement the HelpCallBacks interface, we implement both functions so no
 * need to extend the default class */
class JCHelpCallBack implements HelpCallBacks
{
    /* store the attribute seperated lines of the help page */
    Vector lines;
    /* the attribute used for the current pages */
    int attrib;
    /* a string buffer used to collected the characters for writing */
    StringBuffer buf;

    class Line
    {
	public int attrib;
	public String line;
    }

    private void toLine()
    {
	if ( buf.length() > 0 )
	{
	    Line l = new Line();

	    l.attrib = attrib;
	    l.line = buf.toString();

	    buf.delete( 0, buf.length() );

	    lines.add( l );
	}
    }

    public JCHelpCallBack()
    {
	lines = new Vector();
	buf = new StringBuffer();
    }

    public void initHelp()
    {
	attrib = MAPLE_ATTRIB_NORMAL;
	lines.clear();
	if ( buf.length() > 0 )
	{
	    buf.delete( 0, buf.length() );
	}
    }

    public void display()
    {
	int i, len;
	Line l;

	toLine();

	len = lines.size();

	for ( i = 0; i < len; i++ )
	{
	    l = (Line)lines.get( i );
	    /* System.out does not support other "fonts" so we must ignore
	     * attributes */
	    System.out.print( l.line );
	}
    }

    public boolean writeChar( Object data, int c )
    {
	buf.append( (char)c );
	return false;
    }

    public boolean writeAttrib( Object data, int a )
    {
	if ( buf.length() > 0 )
	{
	    toLine();
	}

	attrib = a;
	return false;
    }
}
