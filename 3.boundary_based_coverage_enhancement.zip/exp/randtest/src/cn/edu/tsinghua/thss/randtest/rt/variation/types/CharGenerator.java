package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;

public class CharGenerator extends AbstractGenerator<Character> {

	public void registerSpecials() {
		registerSpecial('a');
		registerSpecial('b');
		registerSpecial('c');
		registerSpecial('A');
		registerSpecial('B');
		registerSpecial('C');
		registerSpecial(' ');
		registerSpecial('\t');
		registerSpecial('\n');
	}
	
	@Override
	public Character nextRandom() {
		// 目前只返回ASCII字符
		return (char) rand.nextInt(256);
	}
	
	@Override
	public Character nextBiasedRandom() {
		// 优先返回大小写、数字、符号
		if (rand.nextDouble() < 0.8) {
			// from 32 to 126
			return (char) (32 + rand.nextInt(127-32));
		} else {
			return nextRandom();
		}
	}

	@Override
	public Character nextNeighbour(Character current, double scale) {
		if (current == 0) {
			return (char) 1;
		} else if (current == 255) {
			return (char) 254;
		} else {
			return (char) (rand.nextBoolean() ? current + 1 : current - 1);
		}
	}

	@Override
	public Character copy(Character origin) {
		return Character.valueOf(origin.charValue());
	}

	@Override
	public Character[] allNeighbours(Character current, double scale) {
		if (current == 0) {
			return new Character[] {(char) 1};
		} else if (current == 255) {
			return new Character[] {(char) 254};
		} else {
			return new Character[] {(char) (current - 1), (char) (current + 1)};
		}
	}

}
