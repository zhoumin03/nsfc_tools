package cn.edu.tsinghua.thss.randtest.alg.cfg.model;


/**
 * Switch among basic blocks
 * @author aleck
 *
 */
public class Edge {
	private BasicBlock src;
	private BasicBlock dest;
	
	public enum BranchType {
		NON_CONDITIONAL,
		TRUE_BRANCH,
		FALSE_BRANCH,
	}

	private BranchType type;

	public static Edge createAndAttachNonConditional(BasicBlock src, BasicBlock dest) {
		return createAndAttach(src, dest, BranchType.NON_CONDITIONAL);
	}
	
	public static Edge createAndAttachTrueBranch(BasicBlock src, BasicBlock dest) {
		return createAndAttach(src, dest, BranchType.TRUE_BRANCH);
	}
	
	public static Edge createAndAttachFalseBranch(BasicBlock src, BasicBlock dest) {
		return createAndAttach(src, dest, BranchType.FALSE_BRANCH);
	}
	
	public static Edge createAndAttach(BasicBlock src, BasicBlock dest, BranchType type) {
		Edge e = new Edge(src, dest, type);
		e.attach();
		return e;
	}
	
	/**
	 * Create an edge
	 * @param src
	 * @param dest
	 */
	private Edge(BasicBlock src, BasicBlock dest) {
		this.src = src;
		this.dest = dest;
		this.type = BranchType.NON_CONDITIONAL;
	}
	
	/**
	 * Create an edge with condition
	 * @param src
	 * @param dest
	 * @param condition
	 */
	private Edge(BasicBlock src, BasicBlock dest, BranchType type) {
		this.src = src;
		this.dest = dest;
		this.type = type;
	}

	/**
	 * Attach the to the graph
	 */
	public void attach() {
		src.addEdge(this);
		dest.addEdge(this);
	}
	
	/**
	 * 重设边的起点重点, CFG Simplification的时候用
	 * @param src
	 * @param dest
	 */
	public void reattach(BasicBlock src, BasicBlock dest) {
		detach();
		this.src = src;
		this.dest = dest;
		attach();
	}

	/**
	 * Detach from the graph
	 */
	public void detach() {
		src.removeOutEdge(this);
		dest.removeInEdge(this);
	}
	
	public BasicBlock getSrc() {
		return src;
	}
	
	public void setSrc(BasicBlock src) {
		this.src = src;
	}
	
	public BasicBlock getDest() {
		return dest;
	}
	
	public void setDest(BasicBlock dest) {
		this.dest = dest;
	}
	
	public boolean isNonConditionalBranch() {
		return type == BranchType.NON_CONDITIONAL;
	}

	public boolean isConditionalBranch() {
		return (type == BranchType.TRUE_BRANCH || type == BranchType.FALSE_BRANCH);
	}

	public boolean isTrueBranch() {
		return (type == BranchType.TRUE_BRANCH);
	}

	public boolean isFalseBranch() {
		return (type == BranchType.FALSE_BRANCH);
	}
}
