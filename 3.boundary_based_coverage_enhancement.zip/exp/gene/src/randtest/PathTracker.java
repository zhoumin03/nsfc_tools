package randtest;

import java.util.ArrayList;
import java.util.List;

public class PathTracker implements ITracker {
	List<Object> trace = new ArrayList<Object>();
	
	@Override
	public void reset() {
		trace = new ArrayList<Object>();
		System.out.println("--- new trace ---");
	}

	@Override
	public void track(Object trackPoint) {
		trace.add(trackPoint);
		System.out.println("track: " + trackPoint);
	}

	@Override
	public List<Object> getTrace() {
		return trace;
	}	
}
