package algorithm.test;

import junit.framework.TestCase;
import algorithm.FindMax;

public class FindMaxTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T7_10, T7_9, T6_7, T1_3]
	public void test00() {
		Object[] data = (Object[]) (new java.lang.Object[]{-13070749, 10, -107712, -1, 0, -127781004, 10, 1510038, 18618452});
		int[] a = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
		}
		assertEquals((int)(18618452), FindMax.max(a));
	}
	//<<case-end>>
}
