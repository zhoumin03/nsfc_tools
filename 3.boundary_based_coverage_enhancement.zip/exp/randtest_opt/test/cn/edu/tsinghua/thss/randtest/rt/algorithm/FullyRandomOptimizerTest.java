package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.cases.artificial.ColdBranchTestProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.Evaluator.Strategy;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;

/**
 * 纯随机的测试
 * @author aleck
 *
 */
public class FullyRandomOptimizerTest extends OptimizerTest {
	
	protected FullyRandomOptimizerTest(ProblemWrapper wrapper) {
		super(OptimizeParameter.REPEAT);
		setCurrentWrapper(wrapper);
	}

	@Override
	public void setUp() {
		getCurrentWrapper().registerTypeDefs();
	}

	@Override
	protected void runTest() {
		ProblemWrapper wrapper = getCurrentWrapper();
		Evaluator evaluator = new Evaluator(OptimizeParameter.getStrategy());

		for (int i = 0; i < getRepeat(); i++) {
			System.out.println("- run algorithm for the " + (i + 1) + "-th time");
			
			FullyRandomOptimizer fro = new FullyRandomOptimizer(
					OptimizeParameter.getCategory(), 
					evaluator,
					wrapper, 
					getLogger(i)
					);
			wrapper.getRuntimeAssist().setup();
			
			fro.setUp();
			fro.execute(OptimizeParameter.PAR_RANDOM, wrapper);
			fro.tearDown();
		}
	}

	@Override
	public void tearDown() {
		File file = new File(GLOBAL_LOG_FILE);
		if (FileUtils.ensureFile(file)) {
			try {
				FileOutputStream fos = new FileOutputStream(file, true);
				PrintStream ps = new PrintStream(fos);
				statistics(ps);
				ps.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public static void handleOneProblem(ProblemWrapper wrapper) {
		FullyRandomOptimizerTest frot = new FullyRandomOptimizerTest(wrapper);
		frot.optimize();
	}
	
	public static void handleOneProblem(Class<? extends ProblemWrapper> clazz) 
			throws InstantiationException, IllegalAccessException {
		ProblemWrapper wrapper = clazz.newInstance();
		handleOneProblem(wrapper);
	}
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		// FullyRandom的不需要设置 Strategy，只设置 Category
		for (Category category : Category.values()) {
			OptimizeParameter.setCategory(category);
			OptimizeParameter.setStrategy(Strategy.NODE_ONLY);	// set to NODE_ONLY, this parameter is not used
//			handleOneProblem(TriangleClassifierProblemWrapper.class);
//			handleOneProblem(ArrayIsMonotonicProblemWrapper.class);
//			handleOneProblem(BinarySearchProblemWrapper.class);
//			handleOneProblem(BubbleSortProblemWrapper.class);
//			handleOneProblem(GreatestCommonDividerProblemWrapper.class);
//			handleOneProblem(HeapSortProblemWrapper.class);
//			handleOneProblem(InvHyperbolicSineProblemWrapper.class);
//			handleOneProblem(IsPowerOfTwoProblemWrapper.class);
//			handleOneProblem(PrimeCheckerProblemWrapper.class);
//			handleOneProblem(SecondOrderEquationSolverProblemWrapper.class);
//			handleOneProblem(TriangleClassifierProblemWrapper.class);
//			handleOneProblem(QuadraticFormProblemWrapper.class);
			handleOneProblem(ColdBranchTestProblemWrapper.class);
		}
	}
}
