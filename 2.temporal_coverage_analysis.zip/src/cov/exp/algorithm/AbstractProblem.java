package cov.exp.algorithm;

import java.io.PrintStream;

/**
 * The mathematical representation of the abstract problem: 
 * i.e., computing the bug detection probability while given:
 * (1) the transition probability matrix 'p'
 * (2) the probablity of detecting bug, 'q'
 * (3) the initial distribution 'init'
 * @author aleck
 *
 */
public class AbstractProblem {
	public int n;
	public double[][] p;
	public double[] q;
	public double[] init;
	
	public void display(PrintStream ps) {
		ps.println("n=" + n);
		ps.println("initial distribution: ");
		for (int i = 0; i < n; i++) {
			ps.println("init[" + i + "]=" + init[i]);
		}
		ps.println("transition probability matrix:");
		for (int i = 0; i < n; i++) {
			ps.print("from v" + i + ": ");
			for (int j = 0; j < n; j++) {
				if (p[i][j] > 1e-8)
					ps.print("v" + j + "(" + p[i][j] + ") ");
			}
			ps.println();
		}
		ps.println("detection probability:");
		for (int i = 0; i < n; i++) {
			if (q[i] > 1e-8)
				ps.println("q_" + i + "=" + q[i]);
		}
	}
}

