package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class FindMax {
	public static Integer max(int[] a) {
		RT.startInvocation(4502002847583219712L);
		RT.track(1);
		if (((RT.b(0)) && (((RT.eq(0, a, null)) || (RT.eq(1, a.length, 0)))))
				&& (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return null;
		} else {
			RT.nd(0);
			RT.track(3);
			int m = a[0];
			RT.track(5);
			RT.track(6);
			for (int i = 1; ((RT.b(1)) && (RT.lt(0, i, a.length))) && (RT.e(1)); i++) {
				RT.pd(1);
				RT.track(7);
				if (((RT.b(2)) && (RT.gt(0, a[i], m))) && (RT.e(2))) {
					RT.pd(2);
					RT.track(9);
					m = a[i];
				}
				RT.nd(2);
				RT.track(10);
			}
			RT.nd(1);
			RT.track(8);
			return m;
		}
	}
}
