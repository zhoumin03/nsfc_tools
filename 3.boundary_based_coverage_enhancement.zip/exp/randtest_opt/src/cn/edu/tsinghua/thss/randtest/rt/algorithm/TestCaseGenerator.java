package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Stack;

import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.cases.artificial.AlphabetCheckerProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.ArrayIsMonotonicProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.BinarySearchProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.BubbleSortProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.ColdBranchTestProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.DateUtilProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.FindMaxProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.GreatestCommonDividerProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.HeapSortProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.InvHyperbolicSineProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.IsPowerOfTwoProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.Max3ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.NewtonProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.PalindromicProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.PerpendicularProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.PrimeCheckerProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.QuadraticFormProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.SecondOrderEquationSolverProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.StringIsNumberProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.TaxCalcProblemWrapper;
import cn.edu.tsinghua.thss.randtest.cases.artificial.TriangleClassifierProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.Evaluator.Strategy;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.util.ClassUtils;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

/**
 * 生成测试用例，使用最好的参数:
 * MemeticOptimizer with: BRANCH + NODE_PLUS_DIST
 * @author aleck
 *
 */
public class TestCaseGenerator extends OptimizerTest {
	private static class InputProfile {
		public boolean exception;
		public List<Integer> trace;
		public Set<TestTarget> targets;
		public double fitness;

		@Override		
		public String toString() {
			if (exception) {
				return "Exception";
			} else {
				return "[f=" + fitness + ",Len=" + trace.size() + ",Tar=" + targets.size() + "]";
			}
		}
	}

	private static class InputScore {
		public double jaccard;	// jaccard distance
		public int length;	// length of trace
		public int far;		// the far-est reachability
		public double fitness;	// fitness
		
		@Override		
		public String toString() {
			return "[j=" + jaccard + ",len=" + length + ",far=" + far + ",fit=" + fitness + "]";
		}
	}
	
	// 是否使用reduce之后的测试集，为true时，当一个target被其他测试用例覆盖时，将忽略当前的测试用例。
	public static final boolean USE_LUCKY_TEST_CASE = true;
	
	private static final Comparator<InputScore> ASCENDING_INPUT_SCORE_COMPARATOR = new Comparator<InputScore>() {
		@Override
		public int compare(InputScore x, InputScore y) {
			if (Math.abs(x.jaccard - y.jaccard) > 1e-5) {
				return Double.compare(x.jaccard, y.jaccard);
			} else if (x.length != y.length) {
				return Integer.compare(x.length, y.length);
			} else if (x.far != y.far) {
				return Integer.compare(x.far, y.far);
			} else {
				return Double.compare(x.fitness, y.fitness);
			}
		}
	};
	
	public static final String TEST_SUITE_OUTPUT_DIRECTORY = "./data/testsuite/generated";
	
	private AbstractOptimizer optimizer;
	private Map<TestTarget, PriorityQueue<Chromosome>> testcases;
	
	public TestCaseGenerator(ProblemWrapper wrapper) {
		super(OptimizeParameter.REPEAT);
		setCurrentWrapper(wrapper);
	}

	@Override
	public void setUp() {
		testcases = new HashMap<TestTarget, PriorityQueue<Chromosome>>();
		getCurrentWrapper().registerTypeDefs();
	}

	@Override
	public void runTest() {
		ProblemWrapper wrapper = getCurrentWrapper();
		Evaluator evaluator = new Evaluator(OptimizeParameter.getStrategy());
		
		for (int i = 0; i < getRepeat(); i++) {
			System.out.println("- run algorithm for the " + (i + 1) + "-th time");
			
			optimizer = new MemeticOptimizer(
					OptimizeParameter.getCategory(), 
					evaluator,
					wrapper, 
					getLogger(i)
					);
			wrapper.getRuntimeAssist().setup();
			
			optimizer.setUp();
			optimizer.execute(OptimizeParameter.PAR_MEMETIC, wrapper);
			Map<TestTarget, PriorityQueue<Chromosome>> tc = optimizer.getTargetManager().collectTestCases();
			merge(tc);
			optimizer.tearDown();
		}	
	}
	
	private void merge(Map<TestTarget, PriorityQueue<Chromosome>> tc) {
		for (Map.Entry<TestTarget, PriorityQueue<Chromosome>> e : tc.entrySet()) {
			if (!testcases.containsKey(e.getKey())) {
				testcases.put(e.getKey(), e.getValue());
			} else {
				PriorityQueue<Chromosome> merged = testcases.get(e.getKey());
				merged.addAll(e.getValue());
				testcases.put(e.getKey(), merged);
			}
		}
	}

	@Override
	public void tearDown() {
		File file = new File(GLOBAL_LOG_FILE);
		if (FileUtils.ensureFile(file)) {
			try {
				FileOutputStream fos = new FileOutputStream(file, true);
				PrintStream ps = new PrintStream(fos);
				statistics(ps);
				ps.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public static void handleOneProblem(ProblemWrapper wrapper, String template, int numOfCases) throws IOException {
		TestCaseGenerator gen = new TestCaseGenerator(wrapper);
		gen.optimize();
		gen.genTestSuite(wrapper, template, numOfCases);
	}
	
	private void genTestSuite(ProblemWrapper wrapper, String template, int numOfCases) throws IOException {
		Map<Input, InputProfile> testcases = reduce(
				wrapper,
				optimizer.getTargetManager(),
				numOfCases
				);
		List<String> contents = readFile(template);
		int begin = -1, end = -1;
		int i = 0;
		while (i < contents.size()) {
			String line = contents.get(i);
			if (line.contains("<<case-begin>>")) {
				begin = i;
			} else if (line.contains("<<case-end>>")) {
				end = i + 1;
			}
			i++;
		}
		String name = wrapper.getClass().getSimpleName();
		if (name.endsWith("ProblemWrapper"))
			name = name.substring(0, name.indexOf("ProblemWrapper"));
		name = name + "Test";
		String filename = TEST_SUITE_OUTPUT_DIRECTORY + "/" + name + ".java";
		ensureFile(filename);
		PrintStream ps = new PrintStream(filename);
		if (-1 < begin && begin < end && end < contents.size()) {
			for (i = 0; i < begin; i++) {
				ps.println(contents.get(i));
			}
			i = 0;
			for (Map.Entry<Input, InputProfile> entry : testcases.entrySet()) {
				StringBuilder single = new StringBuilder();
				Input input = entry.getKey();
				Set<TestTarget> targets = entry.getValue().targets;
				try {
					String result = null;
					try {
						result = wrapper.invokeStr(input);
						// only output test cases that produces no exception
						for (int j = begin; j < end; j++) {
							String line = contents.get(j);
							if (line.contains("//--")) {
								// ignore
							} else if (line.contains("<$c>")) {
								String comment = "#" + i + ", coverages: " + targets.toString();
								line = replaceAll(line, "<$c>", comment);
								single.append(line);
								single.append('\n');
							} else {
								// replace all $_, $n
								// NOTE: there is a bug, I don't want to fix it currently
								// If $n appears inside a string, I will still replace it.
								// NOTE: I assume #parameters < 10
								if (line.contains("$$")) {
									line = replaceAll(line, "$$", String.format("%02d", i));
								}
								if (line.contains("$_")) {
									line = replaceAll(line, "$_", result);
								}
								for (int k = 0; k < 10; k++) {
									if (line.contains("$" + k)) {
										line = replaceAll(line, "$" + k, ClassUtils.strRepr(input.data[k]));
									}
								}
								single.append(line);
								single.append('\n');
							}
						}
						ps.print(single.toString());
					} catch (Exception e) {
						// exception is expected, then I will use 'null'
						System.err.println(e.getMessage());
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception: " + e.getMessage());
				}
				i++;
			}
			for (i = end; i < contents.size(); i++) {
				ps.println(contents.get(i));
			}
		} else {
			ps.println("Invalid template, check the template!");
		}
		ps.close();
	}
	
	/**
	 * 缩减到 total 个测试用例
	 * @param tm
	 * @param useLuckyTestCase
	 * @param total
	 * @return
	 */
	private Map<Input, InputProfile> reduce(ProblemWrapper wrapper, TargetManager tm, int total) {
		// the order affects phase 1
		List<TestTarget> allTargets = sortTargets(tm.getAllTargets(), false);
		Set<Input> reserve = new HashSet<Input>();
		// phase 0: profile
		Map<Input, InputProfile> profile = new HashMap<Input, InputProfile>();
		for (PriorityQueue<Chromosome> q : testcases.values()) {
			for (Chromosome c : q) {
				InputProfile ip = new InputProfile();
				try {
					wrapper.invoke(c.input);
					ip.exception = false;
					ip.trace = RT.currentTrace();
					ip.targets = tm.collectTargetsAlongTrace(ip.trace);
					ip.fitness = c.fitness;
				} catch (Exception e) {
					ip.exception = true;
				}
				profile.put(c.input, ip);
			}
		}
		// phase 1: cover targets
		Set<TestTarget> currentCovered = new HashSet<TestTarget>();
		for (TestTarget target : allTargets) {
			if (reserve.size() >= total)
				break;
			PriorityQueue<Chromosome> cases = testcases.get(target);
			if (cases != null && cases.size() > 0) {
				if (USE_LUCKY_TEST_CASE && currentCovered.contains(target)) {
					// ignore
					System.out.println("ignored 1 test target which is already covered.");
				} else {
					PriorityQueue<Chromosome> desc = new PriorityQueue<Chromosome>(Chromosome.DESCENDING_CHROMOSOME_COMPARATOR);
					desc.addAll(cases);
					while (!desc.isEmpty()) {
						Chromosome top = desc.poll();
						Input selected = top.input;
						InputProfile ip = profile.get(selected);
						if (!ip.exception) {
							if (reserve.contains(selected)) {
								// ignore it
							} else {
								// add and break
								reserve.add(selected);
								currentCovered.addAll(ip.targets);
								break;
							}
						} else {
							System.out.println("ignored 1 test input that produces exceptions.");
						}
					}
				}
			} else {
				System.out.println("warning: no test input is recoreded for: " + target);
			}
		}
		System.out.println("collected " + reserve.size() + " test cases for coverage.");
		// phase 2: collect inputs that generates divorced trace
		if (reserve.size() < total) {
			System.out.println("appending " + (total - reserve.size()) + " test cases.");
			// collect cases
			Set<Input> candidates = new HashSet<Input>();
			for (PriorityQueue<Chromosome> q : testcases.values()) {
				for (Chromosome c : q) {
					if (!reserve.contains(c.input) && !profile.get(c.input).exception) {
						// we do not collect exceptional cases
						candidates.add(c.input);
					}
				}
			}
			// pick some
			for (int i = reserve.size(); i < total; i++) {
				if (candidates.size() == 0)
					break;
				// pick the next input with:
				// 1. the maximal minimum Jaccard distance (of blocks)
				// 2. the maximal Length
				// 3. the far-est reachability
				// 4. fitness
				Map<Input, InputScore> score = new HashMap<Input, InputScore>();
				for (Input input : candidates) {
					double min = 1e10;
					for (Input x : reserve) {
						double d = jaccard(profile.get(input).trace, profile.get(x).trace);
						if (d < min) {
							min = d;
						}
					}
					InputProfile ip = profile.get(input);
					InputScore s = new InputScore();
					s.jaccard = min;
					s.length = ip.trace.size();
					s.far = Collections.max(ip.trace);
					s.fitness = ip.fitness;
					score.put(input, s);
				}
				// pick the maximal
				Input maxEntry = null;
				for (Input e : candidates) {
					if (maxEntry == null || 
							ASCENDING_INPUT_SCORE_COMPARATOR.compare(score.get(maxEntry), score.get(e)) < 0) {
						maxEntry = e;
					}
				}
				reserve.add(maxEntry);
				candidates.remove(maxEntry);
			}
		}
		// phase 3: return
		Map<Input, InputProfile> ret = new HashMap<Input, InputProfile>();
		for (Input input : reserve) {
			ret.put(input, profile.get(input));
		}
		return ret;
	}

	/**
	 * jaccard distance of two sets: s1, s2
	 * by definition, it is (|s1-s2|+|s2-s1|)/|s1+s2|
	 * however, we add 1 on the divider to avoid division by 0
	 * @param s1
	 * @param s2
	 * @return
	 */
	private double jaccard(List<Integer> s1, List<Integer> s2) {
		Set<Integer> s1_s2 = new HashSet<Integer>();
		s1_s2.addAll(s1);
		s1_s2.removeAll(s2);
		Set<Integer> s2_s1 = new HashSet<Integer>();
		s2_s1.addAll(s2);
		s2_s1.removeAll(s1);
		Set<Integer> s1ps2 = new HashSet<Integer>();
		s1ps2.addAll(s1);
		s1ps2.addAll(s2);
		return 1.0 * (s1_s2.size() + s2_s1.size()) / (s1ps2.size() + 1);
	}

	/**
	 * 将目标按照远近排序
	 * nearestFirst:
	 *   true : 近 -> 远
	 *   false: 远 -> 近
	 * @param targets
	 * @return
	 */
	private List<TestTarget> sortTargets(Set<TestTarget> targets, boolean nearestFirst) {
		// sort targets
		List<TestTarget> ret = new ArrayList<TestTarget>(targets);
		// sort
		if (nearestFirst) {
			Collections.sort(ret, new Comparator<TestTarget>() {
				@Override
				public int compare(TestTarget a, TestTarget b) {
					return (a.getRank() - b.getRank());
				}
			});
		} else {
			Collections.sort(ret, new Comparator<TestTarget>() {
				@Override
				public int compare(TestTarget a, TestTarget b) {
					return -(a.getRank() - b.getRank());
				}
			});
		}
		return ret;
	}

	/**
	 * replace from end to the beginning
	 * NOTE: to avoid infinite replacement:
	 * 1. find all occurrencies
	 * 2. replace from back to the beginning
	 * 
	 * @param s
	 * @param p
	 * @param r
	 * @return
	 */
	private String replaceAll(String s, String p, String r) {
		Stack<Integer> positions = new Stack<Integer>();
		int i = 0;
		while ((i = s.indexOf(p, i)) >= 0) {
			positions.push(i);
			i = i + p.length();	// I assume no overlapping
		}
		while (!positions.isEmpty()) {
			int pos = positions.pop();
			s = s.substring(0, pos) + r + s.substring(pos + p.length());
		}
		return s;
	}

	private void ensureFile(String filename) throws IOException {
		File file = new File(filename);
		File dir = file.getParentFile();
		if (!dir.exists()) {
			dir.mkdirs();
		}
		file.createNewFile();
	}

	private List<String> readFile(String template) throws IOException {
		List<String> contents = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(template));
		String line;
		while ((line = br.readLine()) != null) {
			contents.add(line);
		}
		br.close();
		return contents;
	}

	public static void handleOneProblem(Class<? extends ProblemWrapper> clazz, String template, int numOfCases) 
			throws InstantiationException, IllegalAccessException, IOException {
		ProblemWrapper wrapper = clazz.newInstance();
		handleOneProblem(wrapper, template, numOfCases);
	}
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, IOException {
		OptimizeParameter.setCategory(Category.BRANCH);
		OptimizeParameter.setStrategy(Strategy.NODE_PLUS_DIST);
//		handleOneProblem(IntBarrierProblemWrapper.class,
//				"./data/testsuite/template/test/IntBarrierTest.java",
//				2);
//		handleOneProblem(DoubleBarrierProblemWrapper.class,
//				"./data/testsuite/template/test/DoubleBarrierTest.java",
//				2);
		//-------------------------------------------------------------------
		// 4
		handleOneProblem(AlphabetCheckerProblemWrapper.class,
				"./data/testsuite/template/AlphabetCheckerTest.java",
				4);
		// 5
		handleOneProblem(ArrayIsMonotonicProblemWrapper.class, 
				"./data/testsuite/template/ArrayIsMonotonicTest.java", 
				5);
		// 3
		handleOneProblem(BinarySearchProblemWrapper.class,
				"./data/testsuite/template/BinarySearchTest.java",
				3);
		// 1
		handleOneProblem(BubbleSortProblemWrapper.class,
				"./data/testsuite/template/BubbleSortTest.java",
				1);
		// 3
		handleOneProblem(ColdBranchTestProblemWrapper.class,
				"./data/testsuite/template/ColdBranchTestTest.java",
				3);
		// 4
		handleOneProblem(DateUtilProblemWrapper.class,
				"./data/testsuite/template/DateUtilTest.java",
				4);
		// 1
		handleOneProblem(FindMaxProblemWrapper.class,
				"./data/testsuite/template/FindMaxTest.java",
				1);
		// 4
		handleOneProblem(GreatestCommonDividerProblemWrapper.class,
				"./data/testsuite/template/GreatestCommonDividerTest.java",
				4);
		// 2
		handleOneProblem(HeapSortProblemWrapper.class,
				"./data/testsuite/template/HeapSortTest.java",
				2);
		// 5
		handleOneProblem(InvHyperbolicSineProblemWrapper.class,
				"./data/testsuite/template/InvHyperbolicSineTest.java",
				5);
		// 3
		handleOneProblem(IsPowerOfTwoProblemWrapper.class,
				"./data/testsuite/template/IsPowerOfTwoTest.java",
				3);
		// 2
		handleOneProblem(Max3ProblemWrapper.class,
				"./data/testsuite/template/Max3Test.java",
				2);
		// 2
		handleOneProblem(NewtonProblemWrapper.class,
				"./data/testsuite/template/NewtonTest.java",
				2);
		// 2
		handleOneProblem(PalindromicProblemWrapper.class,
				"./data/testsuite/template/PalindromicTest.java",
				2);
		// 6
		handleOneProblem(PerpendicularProblemWrapper.class,
				"./data/testsuite/template/PerpendicularTest.java",
				6);
		// 4
		handleOneProblem(PrimeCheckerProblemWrapper.class,
				"./data/testsuite/template/PrimeCheckerTest.java",
				4);
		// 14
		handleOneProblem(QuadraticFormProblemWrapper.class,
				"./data/testsuite/template/QuadraticFormTest.java",
				14);
		// 7
		handleOneProblem(SecondOrderEquationSolverProblemWrapper.class,
				"./data/testsuite/template/SecondOrderEquationSolverTest.java",
				7);
		// 19
		handleOneProblem(StringIsNumberProblemWrapper.class, 
				"./data/testsuite/template/StringIsNumberTest.java",
				19);
		// 6
		handleOneProblem(TriangleClassifierProblemWrapper.class, 
				"./data/testsuite/template/TriangleClassifierTest.java",
				6);
		// 7
		handleOneProblem(TaxCalcProblemWrapper.class,
				"./data/testsuite/template/TaxCalcTest.java",
				7);
	}
}
