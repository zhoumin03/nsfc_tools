package cov.exp.model;

import cov.exp.model.maybe.Maybe;

public class CoverageEstimation {
	// for case 1: the probability that the bug is detected
	public Maybe<Double> r1;
	public long timeR1 = 0;
	// for case 2: the probability that the bug is detected under the condition that
	// at least one of the bin is covered.
	public Maybe<Double> r2;
	public long timeR2 = 0;
	// for case 2: the probability that the bug is detected under the condition that
	// all bins are covered
	public Maybe<Double> r3;
	public long timeR3 = 0;
}
