package cn.edu.tsinghua.thss.randtest.cases;

public class ColdBranchTest {
	public static double run(double x) {
		final double error = 1e-6;
		if (100 - error < x * x && x * x < 100 + error) {
			return x;
		} else {
			return 0;
		}
	}
}
