package cn.edu.tsinghua.thss.randtest.cases;

public class TaxCalc {
	public static double tax(double incomming) {
		double x = incomming - 3500;
		if (x <= 0)
			return 0;
		else if (x <= 1500)
			return x * 0.03;
		else if (x <= 4500)
			return x * 0.1 - 105;
		else if (x <= 9000)
			return x * 0.2 - 555;
		else if (x <= 35000)
			return x * 0.25 - 1005;
		else if (x <= 55000)
			return x * 0.3 - 2755;
		else if (x <= 80000)
			return x * 0.35 - 5505;
		else {
			return x * 0.45 - 13505;
		}
	}
}
