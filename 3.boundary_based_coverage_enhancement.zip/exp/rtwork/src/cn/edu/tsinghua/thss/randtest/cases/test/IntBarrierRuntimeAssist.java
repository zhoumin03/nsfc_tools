package cn.edu.tsinghua.thss.randtest.cases.test;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
public class IntBarrierRuntimeAssist extends RuntimeAssist {
	@Override
	public void setup() {
		RT.beginSetup();
		RT.setInvocationSerialNumber(4269051919714895872L);
		RT.notifyCyclomaticComplexity(2);
		RT.notifyStatementCount(3);
		RT.bind(0, "0");
		RT.addTarget(TestTarget.Category.STATEMENT, 2);
		RT.addTarget(TestTarget.Category.STATEMENT, 3);
		RT.addTarget(TestTarget.Category.BRANCH, 1, 2);
		RT.addTarget(TestTarget.Category.BRANCH, 1, 3);
		RT.setDistance(0, 0, 0.0);
		RT.setDistance(0, 1, RT.MAX_DISTANCE);
		RT.setDistance(0, 2, RT.MAX_DISTANCE);
		RT.setDistance(0, 3, RT.MAX_DISTANCE);
		RT.setDistance(0, 4, RT.MAX_DISTANCE);
		RT.setDistance(1, 0, 0.0);
		RT.setDistance(1, 1, 0.0);
		RT.setDistance(1, 2, RT.MAX_DISTANCE);
		RT.setDistance(1, 3, RT.MAX_DISTANCE);
		RT.setDistance(1, 4, RT.MAX_DISTANCE);
		RT.setDistance(2, 0, 1.0);
		RT.setDistance(2, 1, 1.0);
		RT.setDistance(2, 2, 0.0);
		RT.setDistance(2, 3, RT.MAX_DISTANCE);
		RT.setDistance(2, 4, RT.MAX_DISTANCE);
		RT.setDistance(3, 0, 1.0);
		RT.setDistance(3, 1, 1.0);
		RT.setDistance(3, 2, RT.MAX_DISTANCE);
		RT.setDistance(3, 3, 0.0);
		RT.setDistance(3, 4, RT.MAX_DISTANCE);
		RT.setDistance(4, 0, 0.0);
		RT.setDistance(4, 1, 0.0);
		RT.setDistance(4, 2, 0.0);
		RT.setDistance(4, 3, 0.0);
		RT.setDistance(4, 4, 0.0);
		RT.endSetup();
	}
}
