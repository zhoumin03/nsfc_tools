package cn.edu.tsinghua.thss.randtest.rt.variation;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;

public abstract class AbstractGenerator<T> implements Generator<T> {
	private static final int MAX_POOL_SIZE = 50;
	
	// 可以给子类使用的Random
	protected Random rand;
	// 内部存储
	private boolean specialElementRegistered;
	private List<T> specials;
	private List<T> pool;
	
	public AbstractGenerator() {
		rand = RandomFactory.newInstance();
		specialElementRegistered = false;
		specials = new ArrayList<T>();
		pool = new ArrayList<T>();
	}
	
	/**
	 * 返回一个从[0, bound]之间的整数
	 * 
	 * @param bound
	 * @return
	 */
	protected long logBiasedLong(long bound) {
		if (bound < 0) {
			throw new IllegalArgumentException("bound should be positive (" + bound + ")");
		} else {
			// let e^max - 1 == bound
			double max = Math.log((double)bound + 1);
			double candidate = Math.round(Math.exp(rand.nextDouble() * max)) - 1;
			candidate = candidate > bound ? bound : candidate;
			return (long) candidate;
		}
	}
	
	/**
	 * 返回一个从[0, bound]之间的double
	 * 
	 * @param bound
	 * @return
	 */
	protected double logBiasedDouble(double bound) {
		if (bound < 0) {
			throw new IllegalArgumentException("bound should be positive (" + bound + ")");
		} else {
			double max = Math.log((double)bound + 1);
			return Math.exp(rand.nextDouble() * max) - 1;
		}
	}
	
	protected void registerSpecial(T e) {
		specials.add(e);
	}
	
	/**
	 * 这个函数在所有依赖的Generator都已经准备好之后才调用
	 * 由GeneratorFactory负责调用
	 */
	protected abstract void registerSpecials();
	
	@Override
	public void checkRegisterSpecial() {
		if (!specialElementRegistered) {
			registerSpecials();
			specialElementRegistered = true;
		}
	}
	
	@Override
	public T nextSpecial() {
		if (specials.size() == 0) {
			throw new NoSuchElementException("no special value registered");
		} else {
			return specials.get(rand.nextInt(specials.size()));
		}
	}

	/**
	 * NOTE: we don't guarantee that e is in the pool after this procedure
	 * @param e
	 * @return e
	 */
	private T addToAndMaintainPool(T e) {
		pool.add(e);
		if (pool.size() > MAX_POOL_SIZE) {
			int size = pool.size();
			int removeIdx = rand.nextInt(size);
			pool.set(removeIdx, pool.get(size - 1));
			pool.remove(size - 1);
		}
		return e;
	}
	
	protected T nextInPool() {
		if (pool.size() == 0) {
			throw new NoSuchElementException("no value in the pool");
		} else {
			return pool.get(rand.nextInt(pool.size()));
		}
	}
	
	protected int poolSize() {
		return pool.size();
	}
	
	/**
	 * 1/2 - biased value
	 * 1/4 - special value
	 * 1/4 - from pool
	 */
	@Override
	public T nextByPolicy() {
		if (rand.nextBoolean()) {
			return addToAndMaintainPool(nextBiasedRandom());
		} else {
			if (poolSize() == 0 || rand.nextBoolean()) {
				return addToAndMaintainPool(nextSpecial());
			} else {
				return nextInPool();
			}
		}
	}
}
