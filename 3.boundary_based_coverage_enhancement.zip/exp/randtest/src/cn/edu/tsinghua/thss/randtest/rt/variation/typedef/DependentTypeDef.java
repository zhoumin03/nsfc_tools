package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;


/**
 * 依赖类型，比如List<Integer>, Integer[] (认为是 Array<Integer>)等等
 * 依赖类型的生成器是“通用”的，比如List<Integer>和List<String>使用统一个生成器
 * 
 * @author aleck
 *
 */
public class DependentTypeDef extends WrappedTypeDef {
	private static final int BIG_BASE = Integer.MAX_VALUE >> 2;
	
	private int hash;
	
	@SuppressWarnings("rawtypes")
	public DependentTypeDef(Class top, TypeDef ...deps) {
		this.top = top;
		for (TypeDef td : deps) {
			this.deps.add(td);
		}
		calcHashCode();
	}

	private void calcHashCode() {
		hash = top.hashCode() + 1;
		for (TypeDef td : deps) {
			hash = (hash * 3 + td.hashCode()) % BIG_BASE;
		}
	}
	
	@Override
	public int hashCode() {
		return hash;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof DependentTypeDef)) {
			return false;
		}
		DependentTypeDef that = (DependentTypeDef) o;
		if (!this.top.equals(that.top)) {
			return false;
		}
		if (this.deps.size() != that.deps.size()) {
			return false;
		}
		for (int i = 0; i < this.deps.size(); i++) {
			if (!this.deps.get(i).equals(that.deps.get(i))) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(top.toString());
		boolean first = true;
		sb.append('<');
		for (TypeDef td : deps) {
			if (first) {
				first = false;
			} else {
				sb.append(',');
			}
			sb.append(td.toString());
		}
		sb.append('>');
		return sb.toString();
	}

	@Override
	protected String shortName() {
		return toString();
	}
}
