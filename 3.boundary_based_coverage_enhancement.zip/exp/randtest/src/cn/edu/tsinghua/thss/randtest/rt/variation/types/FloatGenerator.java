package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;


public class FloatGenerator extends AbstractGenerator<Float> {
//	private static final double BIASED_FLOAT_STD = 10000.0;

	public void registerSpecials() {
		registerSpecial((float) 0);
		registerSpecial((float) 1);
		registerSpecial((float) -1);
		registerSpecial((float) 0.1);
		registerSpecial((float) -0.1);
	}
	
	@Override
	public Float nextRandom() {
		return rand.nextFloat();
	}

	@Override
	public Float nextBiasedRandom() {
		return (float) ((rand.nextDouble() - 0.5) * 2 * 
				Math.pow(10, logBiasedDouble(Float.MAX_EXPONENT)));
	}

	@Override
	public Float nextNeighbour(Float current, double scale) {
		float maxDelta, delta;
		if (rand.nextBoolean()) {
			// scale, 10 percent difference
			maxDelta = (float) (current * 0.1 * scale);
		} else {
			// offset
			maxDelta = (float) (1 * scale);
		}
		delta = (float) (maxDelta * (rand.nextFloat() - 0.5) / 0.5);
		return (float) (current + delta);
	}

	@Override
	public Float copy(Float origin) {
		return Float.valueOf(origin.floatValue());
	}

	@Override
	public Float[] allNeighbours(Float current, double scale) {
		float maxDelta, delta;
		if (rand.nextBoolean()) {
			// scale, 10 percent difference
			maxDelta = (float) (current * 0.1 * scale);
		} else {
			// offset
			maxDelta = (float) (1 * scale);
		}
		double length = rand.nextFloat();
		delta = (float) (maxDelta * length);
		return new Float[] { current - delta, current + delta, round(current - delta), round(current + delta)};
	}

	private float round(double x) {
		boolean negative = (x < 0);
		x = Math.abs(x);
		// 指数部分
		double exponent = Math.pow(10, Math.floor(Math.log10(x)));
		// 去除指数部分
		x = x / exponent;
		// 对科学计数法的常数项进行四舍五入，选取5到8位有效数字
		double shift = Math.pow(8, rand.nextInt(8 - 5) + 5);
		x = Math.round(x * shift) / shift;
		// 恢复指数部分
		x = x * exponent;
		return (float) (negative ? -x : x);
	}
	
}
