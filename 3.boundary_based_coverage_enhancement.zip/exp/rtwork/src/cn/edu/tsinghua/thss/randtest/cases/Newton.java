package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class Newton {
	public static double sqrt(double x) {
		RT.startInvocation(7846558047594734592L);
		RT.track(1);
		if (((RT.b(0)) && (RT.lt(0, x, 1e-9))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			return 0;
		} else {
			RT.nd(0);
			RT.track(2);
			if (((RT.b(1)) && (RT.gt(0, x, 1e40))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(5);
				return 0;
			} else {
				RT.nd(1);
				RT.track(4);
				double k = 1.0; // 可任取
				RT.track(7);
				while (((RT.b(2)) && (RT.gt(0, Math.abs(k * k - x), 1e-8 * x)))
						&& (RT.e(2))) {
					RT.pd(2);
					RT.track(8);
					k = (k + x / k) / 2;
				}
				RT.nd(2);
				RT.track(9);
				return k;
			}
		}
	}
}
