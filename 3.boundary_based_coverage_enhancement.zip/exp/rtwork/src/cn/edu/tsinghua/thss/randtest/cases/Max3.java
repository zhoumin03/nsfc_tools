package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class Max3 {
	public static int max(int x, int y, int z) {
		RT.startInvocation(8846226945584166912L);
		RT.track(1);
		int m = x;
		RT.track(2);
		if (((RT.b(0)) && (RT.gt(0, y, m))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			m = x;
		}
		RT.nd(0);
		RT.track(4);
		if (((RT.b(1)) && (RT.gt(0, z, m))) && (RT.e(1))) {
			RT.pd(1);
			RT.track(5);
			m = z;
		}
		RT.nd(1);
		RT.track(6);
		return m;
	}
}
