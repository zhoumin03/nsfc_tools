package cn.edu.tsinghua.thss.randtest.rt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.ComposedFormula;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropAtom;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropFormula;
import cn.edu.tsinghua.thss.randtest.alg.core.target.BinaryTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.alg.core.target.UnaryTarget;

import com.google.common.base.Preconditions;

/**
 * RT is short for: Random Testing RunTime
 */
public class RT {
	public static final double MAX_DISTANCE = 10000;
//	private static final double DIFF_THRESHOLD_BYTE	= 64;
//	private static final double DIFF_THRESHOLD_INT	= 1000;
//	private static final double DIFF_THRESHOLD_REAL	= 1000;
	
	private static final double IMPOSSIBLE_DISTANCE = -1;
	private static final double BOOLEAN_TRUE_DISTANCE = 0.5;
	private static final double BOOLEAN_FALSE_DISTANCE = -BOOLEAN_TRUE_DISTANCE;
	
	private static final int NO_SUCH_FORMULA = -1;
	private static final long INVOCATION_SERIAL_NUMBER_NOT_SET = -1;
	
	private static class EvalResult {
		public boolean bool = false;
		public double dist = 0;
	}
	
	// invocation serial number, 用于区分调用的哪个方法
	private static long invocationSerialNumber = INVOCATION_SERIAL_NUMBER_NOT_SET;
	// current cyclomatic complexity
	private static int currentCyclomaticComplexity = 0;
	// current statement count
	private static int currentStatementCount = 0;
	// formulas
	private static Map<Integer, PropFormula> formulas = new HashMap<Integer, PropFormula>();
	// distance evaluation of atoms
	private static Map<Integer, Double> dists = new HashMap<Integer, Double>();
	// boolean evaluation of atoms
	private static Map<Integer, Boolean> bools = new HashMap<Integer, Boolean>();
	// targets
	private static Map<Category, List<TestTarget>> targets = new HashMap<Category, List<TestTarget>>();
	// distance
	private static Map<Pair<Integer>, Double> distance = new HashMap<Pair<Integer>, Double>();
	// last evaluated conditional Formula
	private static int lastEvalFormula = NO_SUCH_FORMULA;
	private static double lastIsolationDist = IMPOSSIBLE_DISTANCE;
	// trace and its distance
	// AG: |trace| = |traceDist|
	// traceDist_i is the distance to the other branch 
	//     at the decision point after trace_i
	//
	// block0 block1 block2    ...
	//     dist0  dist1  dist2 ...
	// 表示
	// block0 -> dist0 -> block1 -> dist1
	// 其中，dist表示实际路径离另外一条路径的距离
	private static List<Double> traceDist = new ArrayList<Double>();
	private static List<Integer> trace = new ArrayList<Integer>();
	
	////////////////////////////////////////////////////////////////////////////
	// 用于Setup的函数
	////////////////////////////////////////////////////////////////////////////

	/**
	 * 开始Setup
	 */
	public static void beginSetup() {
		formulas.clear();
		targets.clear();
		distance.clear();
	}

	/**
	 * 设定一个编号，防止RT_ASSIST和实际调用函数不匹配导致错误而耽误时间
	 */
	public static void setInvocationSerialNumber(long serial) {
		invocationSerialNumber = serial;
	}
	
	public static void checkInvocationSerialNumber(long serial) {
		if (invocationSerialNumber == INVOCATION_SERIAL_NUMBER_NOT_SET) {
			throw new RuntimeException("call RT_ASSIST first to set invocation serial number.");
		} else {
			if (serial != invocationSerialNumber) {
				throw new RuntimeException("invalid invocation serial number: " + 
						serial + "(expected=" + invocationSerialNumber + ")");
			}
		}
	}
	
	/**
	 * 标记目前程序的圈复杂度
	 * @param cc
	 */
	public static void notifyCyclomaticComplexity(int cc) {
		currentCyclomaticComplexity = cc;
	}

	public static int getCyclomaticComplexity() {
		return currentCyclomaticComplexity;
	}

	/**
	 * 标记当前程序的大小
	 * @param sc
	 */
	public static void notifyStatementCount(int sc) {
		currentStatementCount = sc;
	}
	
	public static int getStatementCount() {
		return currentStatementCount;
	}
	
	/**
	 * 结束Setup
	 */
	public static void endSetup() {
		// do nothing
	}

	/**
	 * 被插装函数开始时调用
	 */
	public static void startInvocation(long serial) {
		checkInvocationSerialNumber(serial);
		clearTrace();
		lastEvalFormula = NO_SUCH_FORMULA;
		lastIsolationDist = IMPOSSIBLE_DISTANCE;
	}
	
	/**
	 * 被插装函数结束调用，用于处理递归函数调用时的问题
	 */
	public static void finishInvocation() {
		// NOTE: 目前不处理
	}
	
	/**
	 * 绑定公式Skeleton
	 * @param formulaId
	 * @param strRepr
	 */
	public static void bind(int formulaId, String strRepr) {
		PropFormula formula = PropFormula.parse(strRepr);
		formulas.put(formulaId, formula);
	}

	/**
	 * 添加Unary目标
	 * @param blockId
	 */
	public static void addTarget(Category category, int block) {
		addTarget(category, new UnaryTarget(block));
	}

	/**
	 * 添加Binary目标
	 * @param blockId
	 */
	public static void addTarget(Category category, int first, int second) {
		addTarget(category, new BinaryTarget(first, second));
	}

	/**
	 * 添加目标
	 * @param blockId
	 */
	private static void addTarget(Category category, TestTarget target) {
		if (!targets.containsKey(category)) {
			targets.put(category, new ArrayList<TestTarget>());
		}
		targets.get(category).add(target);
	}

	/**
	 * 获得所有目标
	 * @return
	 */
	public static List<TestTarget> getTargets(Category category) {
		if (!targets.containsKey(category)) {
			targets.put(category, new ArrayList<TestTarget>());
		}
		return targets.get(category);
	}
	
	/**
	 * 定义距离
	 * @param targetId
	 * @param blockId
	 * @param dist
	 */
	public static void setDistance(int targetId, int blockId, double dist) {
		Pair<Integer> key = new Pair<Integer>(targetId, blockId);
		distance.put(key, dist);
	}
	
	/**
	 * 返回从current到target的isolation distance
	 * @param target
	 * @param current
	 * @return
	 */
	public static double queryIsolationDistance(int target, int current) {
		// NOTE: reusable key is preferred
		Pair<Integer> key = new Pair<Integer>(target, current);
		return distance.get(key);
	}

	////////////////////////////////////////////////////////////////////////////
	// 用于跟踪和条件判断的函数
	////////////////////////////////////////////////////////////////////////////
	
	/**
	 * 清楚已有路径
	 */
	public static void clearTrace() {
		trace.clear();
		traceDist.clear();
	}

	/**
	 * 跟踪BasicBlock
	 * @param blockId
	 */
	public static void track(int blockId) {
		trace.add(blockId);
		traceDist.add(fetchLastIsolationDistance());
	}

	/**
	 * 取出最后的IsolationDistance，重置变量lastIsolationDist <- IMPOSSIBLE_DISTANCE
	 * @return
	 */
	private static double fetchLastIsolationDistance() {
		double ret = lastIsolationDist;
		lastIsolationDist = IMPOSSIBLE_DISTANCE;
		return ret;
	}

	/**
	 * 返回当前trace
	 */
	public static List<Integer> currentTrace() {
		return new ArrayList<Integer>(trace);
	}

	/**
	 * 返回当前trace
	 */
	public static List<Double> currentTraceDist() {
		return new ArrayList<Double>(traceDist);
	}

	////////////////////////////////////////////////////////////////////////////
	// 用于计算条件满足程度的函数
	////////////////////////////////////////////////////////////////////////////
	
	/**
	 * 条件计算开始
	 * @param id
	 * @return
	 */
	public static boolean b(int formulaId) {
		dists.clear();
		bools.clear();
		lastEvalFormula = formulaId;
		// always return TRUE
		return true;
	}
	
	/**
	 * 条件计算结束
	 * @param id
	 * @return
	 */
	public static boolean e(int formulaId) {
		// always return TRUE
		return true;
	}

	/**
	 * 公式的正形式成立时，计算其不成立（负形式不成立）的距离
	 * @param formulaId
	 */
	public static void pd(int formulaId) {
		if (lastEvalFormula == formulaId) {
			PropFormula pf = formulas.get(formulaId);
			EvalResult er = new EvalResult();
			evalFalseFormula(pf, true, er);
			Preconditions.checkState(!er.bool && er.dist <= 0);
			lastEvalFormula = -1;
			lastIsolationDist = er.dist;
		} else {
			// ignore:
			// System.out.println("ignore pd check for: " + formulaId);
		}
	}
	
	/**
	 * 公式的负形式成立时，计算其不成立（正形式不成立）的距离
	 * @param formulaId
	 */
	public static void nd(int formulaId) {
		if (lastEvalFormula == formulaId) {
			PropFormula pf = formulas.get(formulaId);
			EvalResult er = new EvalResult();
			evalFalseFormula(pf, false, er);
			Preconditions.checkState(!er.bool && er.dist <= 0);
			lastEvalFormula = -1;
			lastIsolationDist = er.dist;
		} else {
			// ignore:
			// System.out.println("ignore nd check for: " + formulaId);
		}
	}

	/**
	 * 计算公式formula（在inverseForm==true时表示公式的负形式）在
	 * 不成立时的距离
	 * @param formula
	 * @param inverseForm 是否为公式的负形式
	 * @return 本子公式是否成立
	 */
	private static boolean evalFalseFormula(
			PropFormula formula, boolean inverseForm, EvalResult result) {
		
		Preconditions.checkNotNull(result);
		
		if (formula instanceof PropAtom) {
			PropAtom pa = (PropAtom) formula;
			// bypass==false 标识需要反转
			boolean bypass = (pa.positive && !inverseForm || !pa.positive && inverseForm);
			if (bypass) {
				result.dist = dists.get(pa.stub);
				result.bool = bools.get(pa.stub);
			} else {
				result.dist = -dists.get(pa.stub);
				result.bool = !bools.get(pa.stub);
			}
			return result.bool;
		} else if (formula instanceof ComposedFormula) {
			ComposedFormula cf = (ComposedFormula) formula;
			// cf.isConjunction() && !isNegative || cf.isDisjunction() && isNegative
			boolean conjunction = (cf.isConjunction() && !inverseForm || cf.isDisjunction() && inverseForm);

			boolean shortcircuit = false;
			double maxDist = -Double.MAX_VALUE;
			double minDist = Double.MAX_VALUE;
			EvalResult er = new EvalResult();
			Iterator<PropFormula> iter = cf.getSubFormulas().iterator();
			// support 表示在 conjunction 中真值为 True 的子公式前缀长度，或者 disjunction 中 False 的子公式前缀长度。
			// support 在 shortcircuit==false 的时候有效
			double support = 1;
			while (iter.hasNext()) {
				PropFormula sub = iter.next();
				evalFalseFormula(sub, inverseForm, er);
				maxDist = (er.dist > maxDist) ? er.dist : maxDist;
				minDist = (er.dist < minDist) ? er.dist : minDist;
				if (!er.bool && conjunction) {
					// /\ FALSE
					shortcircuit = true;
					result.bool = false;
					result.dist = er.dist;	// which should be the current minDist
					Preconditions.checkState(Math.abs(result.dist - minDist) < 1e-6);
					break;
				} else if (er.bool && !conjunction) {
					// \/ TRUE
					shortcircuit = true;
					result.bool = true;
					result.dist = er.dist;	// which should be the current maxDist
					Preconditions.checkState(Math.abs(result.dist - maxDist) < 1e-6);
					break;
				}
				support /= 2;
			}

			if (shortcircuit) {
				return result.bool;
			} else {
				// no shortcut: 
				// conjunction -> true
				// disjunction -> false
				result.bool = conjunction;
				// hold -> minDist >= 0
				Preconditions.checkState(!result.bool || minDist >= 0);
				// not hold -> maxDist <= 0
				Preconditions.checkState(result.bool || maxDist <= 0);
				// 用 support 作为系数，例如 c1 /\ c2 /\ c3 /\ c4 在
				// e(c1) = e(c2) = True, e(c3) = False 时 support 对应 1/4
				result.dist = support * (conjunction ? minDist : maxDist);
				return result.bool;
			}
		} else {
			throw new IllegalArgumentException("unknown PropFormula type.");
		}
	}

	/**
	 * 记录一个原子命题离成立的距离
	 * @param atomId
	 * @param dist
	 */
	private static void registerAtomDistance(int atomId, double dist) {
		if (Double.isNaN(dist)) {
			dists.put(atomId, IMPOSSIBLE_DISTANCE);
		} else {
			dists.put(atomId, dist);
		}
	}
	
	/**
	 * 记录一个原子命题的成立状况
	 * @param atomId
	 * @param bool
	 * @return
	 */
	private static boolean registerAtomBoolean(int atomId, boolean bool) {
		bools.put(atomId, bool);
		return bool;
	}

	/**
	 * barrier(x)是将x稍稍推离边界的函数
	 * 有的时候完全卡在边界上并不能很好的kill mutation，例如：
	 * 若x=0，当x <= 0的条件被修改成x == 0时无法区分，因此我们倾向于稍稍将边界推离。
	 * 具体方法是设置一个barrier
	 * (1) 对于 int,		0 --> 1, 1 --> 0, else remain unchanged
	 * 					negative is symmetric
	 * (2) 对于 double, 	complex as in the code
	 * @param i
	 * @return
	 */
	private static double barrier(double x, double base) {
		// make sure base >= 0
		base = Math.abs(base);
		if (base < 0.01) {
			// cases such as: a <= b where a and b are both very small
			// we should raise x
			// assert that
			int sign = (int) Math.signum(x);
			if (sign == 0) {
				return 1;
			} else {
				return Math.signum(x) * 0.01 - x;
			}
		} else {
			double boundary = base * 0.01;	// boundary >= 1e4
			if (x < -boundary) {
				return x;
			} else if (x < boundary) {
				int sign = (int) Math.signum(x);
				if (sign == 0) {
					return 1;
				} else {
					return Math.signum(x) * boundary - x;
				}
			} else {
				return x;
			}
		}
	}

	/**
	 * this barrier is for integer
	 * @param x
	 * @return
	 */
	private static double barrier(double x) {
		if (x > 1e-6) {
			if (Math.abs(x - 1) < 1e-6)
				return 0;
			else 
				return x;
		} else if (x < -1e-6) {
			if (Math.abs(x + 1) < 1e-6)
				return 0;
			else
				return x;
		} else {
			// 保证在不成立的条件上一定是负数
			// x == 0 时条件可能成立，因此取正数
			return 1;
		}
	}
	
	/**
	 * mu(x)是一个从 R -> [-1, 1] 的函数
	 * 注意，此处返回大于0的部分是为了对称性，最终使用时需要截取。
	 * 实际上，如果用于条件估计，这个值在不成立的条件上一定是负数
	 * @param x
	 */
	private static double mu(double x) {
		// scale x by 50;
		double y = Math.atan(x / 50);
		// scale y to (-1, 0]
		return y / (Math.PI / 2);
	}
	
	/**
	 * 计算等号满足程度
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean eq(int id, int lhs, int rhs) {
		// x != y 时，返回-值
		// x == y 时，返回0
		registerAtomDistance(id, mu(-Math.abs((double)lhs - rhs)));
		return registerAtomBoolean(id, lhs == rhs);
	}

	public static boolean eq(int id, double lhs, double rhs) {
		// x != y 时，返回-值
		// x == y 时，返回0
		registerAtomDistance(id, mu(-Math.abs(lhs - rhs)));
		return registerAtomBoolean(id, lhs == rhs);
	}

	public static boolean eq(int id, Object lhs, Object rhs) {
		// x == y 时，1
		// x != y 时，-1
		double dist = (lhs == rhs) ? 1 : -1;
		registerAtomDistance(id, dist);
		return registerAtomBoolean(id, lhs == rhs);
	}

	/**
	 * 计算不等号距离
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean ne(int id, int lhs, int rhs) {
		// x != y 时，返回+值
		// x == y 时，返回0
		registerAtomDistance(id, mu(Math.abs(lhs - rhs)));
		return registerAtomBoolean(id, lhs != rhs);
	}

	public static boolean ne(int id, double lhs, double rhs) {
		// x != y 时，返回+值
		// x == y 时，返回0
		registerAtomDistance(id, mu(Math.abs((double)lhs - rhs)));
		return registerAtomBoolean(id, lhs != rhs);
	}

	public static boolean ne(int id, Object lhs, Object rhs) {
		// x != y 时，1
		// x == y 时，-1
		double dist = (lhs != rhs) ? 1 : -1;
		registerAtomDistance(id, dist);
		return registerAtomBoolean(id, lhs != rhs);
	}

	/**
	 * 计算大于号距离
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean gt(int id, int lhs, int rhs) {
		// lhs > rhs <=> lhs >= rhs + 1
		registerAtomDistance(id, mu(barrier((double)lhs - rhs - 1)));
		return registerAtomBoolean(id, lhs > rhs);
	}

	public static boolean gt(int id, double lhs, double rhs) {
		registerAtomDistance(id, mu(barrier((double)lhs - rhs, (double)Math.abs(lhs) + Math.abs(rhs))));
		return registerAtomBoolean(id, lhs > rhs);
	}

	/**
	 * 计算小于号距离
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean lt(int id, int lhs, int rhs) {
		// lhs < rhs <=> lhs + 1 <= rhs
		registerAtomDistance(id, mu(barrier((double)rhs - lhs - 1)));
		return registerAtomBoolean(id, lhs < rhs);
	}

	public static boolean lt(int id, double lhs, double rhs) {
		registerAtomDistance(id, mu(barrier((double)rhs - lhs, (double)Math.abs(lhs) + Math.abs(rhs))));
		return registerAtomBoolean(id, lhs < rhs);
	}

	/**
	 * 计算小于等于的距离
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean le(int id, int lhs, int rhs) {
		registerAtomDistance(id, mu(barrier((double)rhs - lhs)));
		return registerAtomBoolean(id, lhs <= rhs);
	}

	public static boolean le(int id, double lhs, double rhs) {
		registerAtomDistance(id, mu(barrier((double)rhs - lhs, (double)Math.abs(lhs) + Math.abs(rhs))));
		return registerAtomBoolean(id, lhs <= rhs);
	}

	/**
	 * 计算大于等于的距离
	 * @param id
	 * @param lhs
	 * @param rhs
	 * @return
	 */
	public static boolean ge(int id, int lhs, int rhs) {
		registerAtomDistance(id, mu(barrier((double)lhs - rhs)));
		return registerAtomBoolean(id, lhs >= rhs);
	}

	public static boolean ge(int id, double lhs, double rhs) {
		registerAtomDistance(id, mu(barrier((double)lhs - rhs, (double)Math.abs(lhs) + Math.abs(rhs))));
		return registerAtomBoolean(id, lhs >= rhs);
	}

	/**
	 * 计算一个Boolean类型的Atom的距离
	 * @param i
	 * @param isPrime
	 * @return
	 */
	public static boolean so(int id, boolean boolValue) {
		registerAtomDistance(id, boolValue ? BOOLEAN_TRUE_DISTANCE : BOOLEAN_FALSE_DISTANCE);
		return registerAtomBoolean(id, boolValue);
	}
}
