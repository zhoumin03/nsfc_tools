package randtest;

import java.util.List;

public interface ITracker {
	public void reset();
	
	public void track(Object trackPoint);
	
	public List<Object> getTrace();
}
