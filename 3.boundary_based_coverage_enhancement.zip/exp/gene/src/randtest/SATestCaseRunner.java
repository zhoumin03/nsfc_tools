package randtest;

import gene.FixedSizeSolutionSet;
import gene.ISolution;
import gene.ISolutionUpdater;
import gene.SolEntry;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import sut.CtrlDepGraph;
import sut.TriangleClassifier;

public class SATestCaseRunner {

	/**
	 * 初始化所有解
	 * @author aleck
	 *
	 */
	public static class InitSolUpdater implements ISolutionUpdater {

		@Override
		public SolEntry update(SolEntry old) {
			return getEntryFromSol(newRandTestCase());
		}

	}
	
	/**
	 * 初始化所有解
	 * @author aleck
	 *
	 */
	public static class NeighbourSolUpdater implements ISolutionUpdater {
		private double temperature;
		private Random rand;

		public NeighbourSolUpdater(double temperature, int seed) {
			this.temperature = temperature;
			this.rand = new Random();
			rand.setSeed(seed);
		}

		@Override
		public SolEntry update(SolEntry old) {
			if (old == null) {
				return getEntryFromSol(newRandTestCase());
			} else {
				List<ISolution> ret = variation.evolve(old.solution, temperature);
				SolEntry entry = getEntryFromSol(ret.get(0));
				if (entry.compareTo(old) < 0) {
					// more fit
					return entry;
				} else {
					if (rand.nextDouble() <= Math.exp(- temperature / 2)) {
						// do not substitute
						return null;
					} else {
						return entry;
					}
				}
			}
		}
		
	}
	
	private static final int 	MAX_INPUT_INT 				= 10000;
	private static final int 	PARALLEL_SOLUTION_COUNT 	= 1;
	private static final int 	SATURATION_ITERATION		= 100;
	
	private static Random rand = new Random();
	private static TriangleClassifier tc = new TriangleClassifier();
	private static TestInputVariation variation = new TestInputVariation(rand.nextInt());
	
	private static PathFitness fitness;
	private static Queue<String> targets = new LinkedList<String>();
	
	public static void main(String[] args) {
		int rounds = 0;
		int iterations = 0;
		
		rand.setSeed(0);
		targets.addAll(CtrlDepGraph.targets);
		
		while (!completelyCovered()) {
			String target = targets.peek();
			System.out.println("*** target is: " + targets.peek());
			
			fitness = new PathFitness(tc, targets.peek());
			FixedSizeSolutionSet solSet = genInitSolutions(fitness);
			
			double initTemperature = calcInitTemperature(solSet);
			int singleTargetRound = 0;
			int singleTargetIteration = 0;
			
			// Outter Loop
			while (true) {
				if (currentTargetCovered(solSet, target)) {
					System.out.println("*** rounds=" + rounds + " (single=" + singleTargetRound + ")");
					targets.poll();
					break;
				} else {
					rounds ++;
					singleTargetRound ++;
					singleTargetIteration += simulatedAnneallingOutterLoopStep(
							solSet, 
							currentTemperature(singleTargetRound, initTemperature),
							target
							);
					iterations += singleTargetIteration;
				}
			}
		}
		
		System.out.println("Achived after " + rounds + " rounds, " + iterations + " iterations.");
	}

	private static SolEntry getEntryFromSol(ISolution sol) {
		SolEntry entry = new SolEntry();
		entry.solution = sol;
	
		System.out.println("evaluating solution: " + sol.toString());
		
		entry.fitness = fitness.eval(sol);
		return entry;
	}
	
	/**
	 * 初始温度
	 * @param solSet
	 * @return
	 */
	private static double calcInitTemperature(FixedSizeSolutionSet solSet) {
		// 初始返回1.0，温度逐渐降低到接近于0
		return 1.0;
//		if (solSet.getSize() == 0) {
//			// ERROR
//			return 0;
//		} else if (solSet.getSize() < 1) {
//			SolEntry entry = solSet.listEntries().get(0);
//			PathFitnessValue pfv = (PathFitnessValue) entry.fitness;
//			return Math.sqrt(pfv.getDoubleValue());
//		} else {
//			double average = 0;
//			for (SolEntry entry : solSet.listEntries()) {
//				PathFitnessValue pfv = (PathFitnessValue) entry.fitness;
//				average = pfv.getDoubleValue();
//			}
//			average = average / (solSet.getSize());
//			
//			double ssd = 0;
//			for (SolEntry entry : solSet.listEntries()) {
//				PathFitnessValue pfv = (PathFitnessValue) entry.fitness;
//				double value = pfv.getDoubleValue();
//				ssd += (value - average) * (value - average);
//			}
//			ssd = Math.sqrt(ssd / (solSet.getSize() - 1));
//			if (ssd < MIN_INIT_TEMPERATURE) {
//				return MIN_INIT_TEMPERATURE;
//			} else {
//				return ssd;
//			}
//		}
	}

	private static double currentTemperature(int singleTargetRound, double initTemperature) {
		return initTemperature / (1 + singleTargetRound);
	}

	private static boolean currentTargetCovered(FixedSizeSolutionSet solutions, String target) {
		for (SolEntry entry : solutions.listEntries()) {
			PathFitnessValue pfv = (PathFitnessValue) entry.fitness;
			if (pfv.path.contains(target)) {
				return true;
			}
		}
		return false;
	}

	private static boolean completelyCovered() {
		return targets.isEmpty();
	}

	private static int simulatedAnneallingOutterLoopStep(
			FixedSizeSolutionSet solSet, 
			double temperature,
			String target
			) {
		// Inner Loop
		SolEntry best = solSet.getBestFitEntry();
		
		int iterations = 0;
		int bestNoChange = 0;
		while (true) {
			iterations++;
			simulatedAnneallingInnerLoopStep(solSet, temperature);
			SolEntry entry = solSet.getBestFitEntry();
			if (best.fitness.compareTo(entry.fitness) > 0) {
				best = entry;
				if (currentTargetCovered(solSet, target)) {
					break;
				}
			} else {
				bestNoChange++;
			}
			if (bestNoChange >= SATURATION_ITERATION) {
				System.out.println("best fit entry no change after " + SATURATION_ITERATION + " iterations, decreasing temperature.");
				break;
			}
		}
		
		return iterations;
	}

	/**
	 * 对于每一个解，根据温度产生某个领域之内的变化，然后进行更新
	 * @param solSet
	 * @param temperature
	 */
	private static void simulatedAnneallingInnerLoopStep(FixedSizeSolutionSet solSet, double temperature) {
		solSet.traverse(new NeighbourSolUpdater(temperature, rand.nextInt()), fitness);
	}

	private static FixedSizeSolutionSet genInitSolutions(PathFitness fitness) {
		FixedSizeSolutionSet solutions = new FixedSizeSolutionSet(PARALLEL_SOLUTION_COUNT);
		solutions.traverse(new InitSolUpdater(), fitness);
		return solutions;
	}

	private static TestInput newRandTestCase() {
		TestInput ti = new TestInput();
		ti.a = rand.nextInt() % MAX_INPUT_INT;
		ti.b = rand.nextInt() % MAX_INPUT_INT;
		ti.c = rand.nextInt() % MAX_INPUT_INT;
		return ti;
	}
}
