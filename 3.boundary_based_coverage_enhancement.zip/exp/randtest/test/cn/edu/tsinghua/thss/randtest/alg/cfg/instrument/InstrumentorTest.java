package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument;

import java.io.IOException;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.exporter.GraphvizExporter;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor.CfgExtractor;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgSimplifier;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.ModificationListener;
import cn.edu.tsinghua.thss.randtest.alg.core.ProblemDescription;


public class InstrumentorTest {
	private static final String OUTPUT_DIR_BASE = "./data/exported/instrumented";
	
	public static void main(String[] args) throws IOException {
		final String packagename = "sample";
		final String filename = "./data/sample/SampleJavaProgram.java";
		final String typename = "SampleJavaProgram";
		final String[] methodnames = new String[] {
				"testIf",
				// "testWhile",
				// "complexMethod",
				// "testCondition",
				};
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(FileUtils.readStringFromFile(filename).toCharArray());
		//parser.setSource("/*abc*/".toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
 
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		final ModificationListener ml = new ModificationListener();

		// search for the class
		cu.accept(new ASTVisitor() {
			public boolean visit(TypeDeclaration td) {
				String name = td.getName().getIdentifier();
				if (name.equals(typename)) {
					for (MethodDeclaration md : td.getMethods()) {
						String methodname = md.getName().getIdentifier();
						boolean found = false;
						for (String s : methodnames) {
							if (s.equals(methodname)) {
								found = true;
								break;
							}
						}
						if (found) {
							System.out.println("Found method: " + typename + "." + methodname);
							ControlFlowGraph cfg = CfgExtractor.extractFromMethodDeclaration(
									md.getAST(), md);
							// simplify and reduce
							CfgSimplifier.removeUnreachableBlocks(cfg);
							CfgSimplifier.removeEmptyBlocks(md.getAST(), cfg);
							ProblemDescription pd = new ProblemDescription(
									packagename, typename, 
									methodname, md, cfg
									);
							Instrumentor instrumentor = new Instrumentor();
							instrumentor.instrument(md.getAST(), pd);
							
							ml.notifyModified();
							
							GraphvizExporter ge = new GraphvizExporter();
							try {
								ge.export(cfg, pd, 
										OUTPUT_DIR_BASE + "/" + methodname + ".dot", 
										typename + "." + methodname, 
										true
										);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				return true;
			}
		});
		
		if (ml.isModified()) {
			String outputFilename = OUTPUT_DIR_BASE + "/" + typename + ".java";
			System.out.println("Exporting to: " + outputFilename);
			JavaExporter.exportToFile(outputFilename, cu);
			JavaExporter.format(outputFilename);
		} else {
			System.out.println("The code is not modified!");
		}
	}

}
