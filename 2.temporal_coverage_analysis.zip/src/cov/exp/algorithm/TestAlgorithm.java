package cov.exp.algorithm;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class TestAlgorithm {
	public static void main(String[] args) {
		AbstractProblem ap = new AbstractProblem();
		ap.n = 2;
		ap.init = new double[] {1, 0};
		ap.p = new double[][] {
				{0.5, 0.5, }, 
				{0.5, 0.5, }
				};
		
		ap.q = new double[] {1, 0};
		
		Set<Integer> target = new HashSet<Integer>();
		target.add(1);
		boolean[] forbidden = new boolean[2];
		Arrays.fill(forbidden, false);
		for (int i : target) {
			forbidden[i] = true;
		}
		
		int M = 10;
		
		AlgorithmBase alg = new AlgorithmBase();
		System.out.println("trigger = " + alg.triggerProb(M, ap, forbidden));
		System.out.println("noreach = " + (1 - alg.reachProb(M, ap, target)));
	}
}
