package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton;

public class PropAtom extends PropFormula {
	public final boolean positive;
	public final int stub;
	
	public PropAtom(boolean positive, int stub) {
		this.positive = positive;
		this.stub = stub;
	}
	
	public boolean isPositive() {
		return positive;
	}
	
	public boolean isNegative() {
		return !positive;
	}
}
