package algorithm;

import java.util.Random;

public class BallUtils {
	private int dimension;
	private Random rand;
	
	private double surfaceAreaCoefficient;
	private double volumeCoefficient;
	
	public BallUtils(int dim) {
		if (dim < 1)
			throw new RuntimeException("wrong dimension: " + dim);
		this.dimension = dim;
		prepare();
		rand = new Random();
	}

	public int getDimension() {
		return this.dimension;
	}
	
	private void prepare() {
		volumeCoefficient = calculateVolumeCoeffiency(dimension);
		surfaceAreaCoefficient = dimension * volumeCoefficient;
	}

	private double calculateVolumeCoeffiency(int dim) {
		double k = 1.0;
		while (dim > 2) {
			k = k * 2 * Math.PI / dim;
			dim = dim - 2;
		}
		return (dim == 1) ? k * 2 : k * Math.PI;
	}
	
	/**
	 * Volume = k * radius^n
	 * @param radius
	 * @return
	 */
	public double volume(double radius) {
		return volumeCoefficient * Math.pow(radius, dimension);
	}
	
	/**
	 * SurfaceArea = k * radius^{n-1}
	 * @param radius
	 * @return
	 */
	public double surfaceArea(double radius) {
		return surfaceAreaCoefficient * Math.pow(radius, dimension - 1);
	}

	/**
	 * Follow these steps:
	 * 1. generate a point in the unit ball
	 *   1.a choose a radius according to surface area function
	 *     the probability of choosing $r$ is $p(r)=A_n(r)$
	 *     $F(r)$ is the integration of $p(r)$
	 *     generate a value $z$ in $[0,1]$ and return $F^{-1}(z)$
	 *   1.b generate $n$ normal distributed variables x=(x_1, ..., x_n)
	 *   1.c let $y$ be $x / |x|$. (there is paper proves that $y$ is uniformly distributed.
	 * 2. scale $y$ and return
	 * @return
	 */
	public double[] randomPoint(double radius) {
		// let p(r) = A_n(r) / volumeCoeffiency
		// p(r) = surfaceAreaCoe * r^{n-1} / volumeCoeffiency
		// F(r) = integrate_{0}^{r}{p(x) dx} = r^n
		// F^{-1}(z) = (z)^{1/n}
		double z = rand.nextDouble();
		double r = Math.pow(z, 1.0 / dimension);
		double[] point = new double[dimension];
		
		double s = 0;
		for (int i = 0; i < dimension; i++) {
			point[i] = rand.nextGaussian();
			s += point[i] * point[i];
		}
		s = Math.sqrt(s);
		for (int i = 0; i < dimension; i++) {
			point[i] = point[i] / s * r;
		}
		
		return point;
	}
	
	private static double norm(double[] point) {
		double ret = 0;
		for (int i = 0; i < point.length; i++) {
			ret = ret + point[i] * point[i];
		}
		return Math.sqrt(ret);
	}
	
	private static void printPoint(double[] p) {
		System.out.print("(");
		for (int i = 0; i < p.length - 1; i++) {
			System.out.print(String.format("%+06f, ", p[i]));
		}
		System.out.print(String.format("%+06f)", p[p.length - 1]));
	}
	
	/**
	 * Generate several random point in the ball and calculate 
	 * @param utils
	 */
	private static void checkRandomness(BallUtils utils) {
		final double radius = 1.0;
		final double sample_distance = 0.1;
		final int MAX_SAMPLE_REGION = 100;
		final int MAX_RAND_POINT = 1000000;
		
		int[] sampleCount = new int[MAX_SAMPLE_REGION];
		double[][] samplePoints = new double[MAX_SAMPLE_REGION][];
		for (int i = 0; i < MAX_SAMPLE_REGION; i++) {
			do {
				// samplePoints[i] = utils.randomPoint(radius);
				samplePoints[i] = randomPointByCube(utils.getDimension(), radius);
			} while (norm(samplePoints[i]) + sample_distance >= radius + 1e-8);
			sampleCount[i] = 0;
		}
		
		for (int i = 0; i < MAX_RAND_POINT; i++) {
			double[] point = utils.randomPoint(radius);
			// double[] point = randomPointByCube(utils.getDimension(), radius);
			
			for (int j = 0; j < MAX_SAMPLE_REGION; j++) {
				if (distance(point, samplePoints[j]) <= sample_distance) {
					sampleCount[j] ++;
				}
			}
		}
		
		System.out.println("Totally " + MAX_SAMPLE_REGION + " sample points.");
		for (int i = 0; i < MAX_SAMPLE_REGION; i++) {
			System.out.print(sampleCount[i] + " " + norm(samplePoints[i]) + " ");
			printPoint(samplePoints[i]);
			System.out.println();
		}
		System.out.println("Std Err: " + stdErr(sampleCount));
	}
	
	private static double[] randomPointByCube(int dim, double radius) {
		double[] point = new double[dim];
		do {
			for (int i = 0; i < dim; i++) {
				point[i] = (Math.random() - 0.5) * 2 * radius;
			}
		} while (norm(point) > 1);
		return point;
	}

	private static double stdErr(int[] array) {
		if (array.length < 2)
			throw new RuntimeException("Too few samples.");
		long sum = 0;
		long sumOfSquare = 0;
		for (int d : array) {
			sum += d;
			sumOfSquare += (long) d * (long) d;
		}
		return Math.sqrt(sumOfSquare / array.length - (sum / array.length) * (sum / array.length));
	}

	private static double distance(double[] p1, double[] p2) {
		if (p1.length != p2.length) {
			throw new RuntimeException("Mismatch points of different dimension.");
		}
		double dist = 0;
		for (int i = 0; i < p1.length; i++) {
			dist += (p1[i] - p2[i]) * (p1[i] - p2[i]);
		}
		return Math.sqrt(dist);
	}

	public static void main(String[] args) {
		BallUtils utils = new BallUtils(2);
//		for (int i = 0; i < 10; i++) {
//			double[] p = utils.randomPoint(1);
//			printPoint(p);
//			System.out.println();
//		}
		checkRandomness(utils);
	}

}
