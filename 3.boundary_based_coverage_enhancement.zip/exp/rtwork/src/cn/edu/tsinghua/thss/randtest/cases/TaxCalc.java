package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class TaxCalc {
	public static double tax(double incomming) {
		RT.startInvocation(5860042861911629824L);
		RT.track(1);
		double x = incomming - 3500;
		RT.track(2);
		if (((RT.b(0)) && (RT.le(0, x, 0))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			return 0;
		} else {
			RT.nd(0);
			RT.track(4);
			if (((RT.b(1)) && (RT.le(0, x, 1500))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(6);
				return x * 0.03;
			} else {
				RT.nd(1);
				RT.track(7);
				if (((RT.b(2)) && (RT.le(0, x, 4500))) && (RT.e(2))) {
					RT.pd(2);
					RT.track(8);
					return x * 0.1 - 105;
				} else {
					RT.nd(2);
					RT.track(9);
					if (((RT.b(3)) && (RT.le(0, x, 9000))) && (RT.e(3))) {
						RT.pd(3);
						RT.track(10);
						return x * 0.2 - 555;
					} else {
						RT.nd(3);
						RT.track(11);
						if (((RT.b(4)) && (RT.le(0, x, 35000))) && (RT.e(4))) {
							RT.pd(4);
							RT.track(12);
							return x * 0.25 - 1005;
						} else {
							RT.nd(4);
							RT.track(13);
							if (((RT.b(5)) && (RT.le(0, x, 55000))) && (RT.e(5))) {
								RT.pd(5);
								RT.track(14);
								return x * 0.3 - 2755;
							} else {
								RT.nd(5);
								RT.track(15);
								if (((RT.b(6)) && (RT.le(0, x, 80000))) && (RT.e(6))) {
									RT.pd(6);
									RT.track(16);
									return x * 0.35 - 5505;
								} else {
									RT.nd(6);
									RT.track(17);
									return x * 0.45 - 13505;
								}
							}
						}
					}
				}
			}
		}
	}
}
