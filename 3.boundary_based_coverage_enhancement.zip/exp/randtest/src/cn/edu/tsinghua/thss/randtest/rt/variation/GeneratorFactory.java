package cn.edu.tsinghua.thss.randtest.rt.variation;

import java.util.HashMap;
import java.util.Map;

import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.BasicTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.DependentTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.TypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.WrappedTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.BooleanGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.ByteGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.CharGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.DoubleGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.FloatGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.IntGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.LongGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.StringGenerator;

/**
 * 各种类型的变化方法
 * 基本的类型包括：
 * 
 * char, byte, int, long, float, double, String
 * 其余的类型需要实用
 * 
 * @author aleck
 *
 */
public class GeneratorFactory {
	@SuppressWarnings("rawtypes")
	public static Map<TypeDef, Generator> generators = new HashMap<TypeDef, Generator>();

	static {
		registerBasicInstance(new CharGenerator(), 		Character.class);
		registerBasicInstance(new BooleanGenerator(), 	Boolean.class);
		registerBasicInstance(new ByteGenerator(), 		Byte.class);
		registerBasicInstance(new IntGenerator(), 		Integer.class);
		registerBasicInstance(new LongGenerator(), 		Long.class);
		registerBasicInstance(new FloatGenerator(), 	Float.class);
		registerBasicInstance(new DoubleGenerator(), 	Double.class);
		registerBasicInstance(new StringGenerator(),	String.class);
	}
	
	/**
	 * 基本类型，比如Integer
	 * @param generator
	 * @param key
	 */
	@SuppressWarnings("rawtypes")
	public static<T> void registerBasicInstance(Generator<T> generator, Class key) {
		registerInstance(generator, new BasicTypeDef(key));
	}
	
	/**
	 * 依赖类型，比如Integer[] (认为是Array<Integer>), List<Integer>
	 * @param generator
	 * @param top
	 * @param deps
	 */
	@SuppressWarnings("rawtypes")
	public static<T> void registerDependentInstance(WrappedGenerator<T> generator, 
			Class top, TypeDef ...deps) {
		registerInstance(generator, new DependentTypeDef(top, deps));
	}

	/**
	 * 归纳类型，比如 Node ::= (int x; Node next);
	 * @param generator
	 * @param top
	 * @param deps
	 */
	@SuppressWarnings("rawtypes")
	public static<T> void registerInductiveInstance(WrappedGenerator<T> generator, 
			Class top, TypeDef ...deps) {
		registerInstance(generator, new BasicTypeDef(top));
	}
	
	/**
	 * Always replace without warning
	 * @param generator
	 * @param td
	 */
	private static<T> void registerInstance(Generator<T> generator, TypeDef td) {
		generators.put(td, generator);
	}

	@SuppressWarnings("rawtypes")
	public static Generator getInstance(TypeDef td) {
		Generator generator = generators.get(td);
		// refine dependent generators
		if (td.isDependentType() || td.isInductiveType()) {
			if (!(generator instanceof WrappedGenerator)) {
				throw new RuntimeException("a wrapped generator is expected for " + td + ", but it is not the case.");
			} else {
				WrappedGenerator wg = (WrappedGenerator) generator;
				wg.refineDependentGenerators((WrappedTypeDef) td);
			}
		}
		
		generator.checkRegisterSpecial();
		
		return generator;
	}

}
