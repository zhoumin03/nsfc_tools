package sut;

import randtest.ITracker;
import randtest.PathTracker;

public class TriangleClassifier {
	public static final int NOT_TRIANGLE = 0;
	public static final int ACUTE_ANGLE = 0;
	public static final int RIGHT_ANGLE = 0;
	public static final int OBTUSE_ANGLE = 0;
	
	private ITracker tracker = new PathTracker();
	
	public void setupTracker() {
		tracker.reset();
	}
	
	public ITracker getTracker() {
		return tracker;
	}
	
	public int classify(int a, int b, int c) {
		// ENTRY
		tracker.track("entry");
		int ret;
		// B0
		tracker.track("b0");
		tracker.track("#dist(d0): " + (-min(a, b, c)));
		tracker.track("#dist(b0p): " + (min(a, b, c)));
		if (a <= 0 || b <= 0 || c <= 0) {
			tracker.track("d0");
			ret = NOT_TRIANGLE;
		} else {
			tracker.track("b0p");
			int temp;
			// B1
			tracker.track("b1");
			tracker.track("#dist(s1): " + (b - c));
			if (b > c) {
				tracker.track("s1");
				temp = c;
				c = b;
				b = temp;
			}
			// B2
			tracker.track("b2");
			tracker.track("#dist(s2): " + (a - b));
			if (a > b) {
				tracker.track("s2");
				temp = b;
				b = a;
				a = temp;
			}
			// B3
			tracker.track("b3");
			tracker.track("#dist(s3): " + (b - c));
			if (b > c) {
				tracker.track("s3");
				temp = c;
				c = b;
				b = temp;
			}
			// it is true that a <= b <= c
			// B4
			tracker.track("b4");
			tracker.track("#dist(d1): " + (c - a - b));
			tracker.track("#dist(b4p): " + (a + b - c));
			if (a + b < c) {
				tracker.track("d1");
				ret = NOT_TRIANGLE;
			} else {
				tracker.track("b4p");
				int delta = a * a + b * b - c * c;
				tracker.track("b5");
				tracker.track("#dist(d2): " + (-delta));
				tracker.track("#dist(b5p): " + (delta));
				if (delta < 0) {
					tracker.track("d2");
					ret = OBTUSE_ANGLE;
				} else {
					tracker.track("b5p");
					tracker.track("b6");
					tracker.track("#dist(d3): " + (delta));
					tracker.track("#dist(d4): " + (-delta));
					if (delta > 0) {
						tracker.track("d3");
						ret = ACUTE_ANGLE;
					} else {
						tracker.track("d4");
						ret = RIGHT_ANGLE;
					}
				}
			}
		}
		tracker.track("exit");
		return ret;
	}

	private int min(int a, int b, int c) {
		int m = a;
		m = (m < b) ? m : b;
		m = (m < c) ? m : c;
		return m;
	}
}
