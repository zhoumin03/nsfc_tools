package cov.exp.plot;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DataExtractorRound3 extends AbstractDataExtractor {
	private static final String FILE_RAW_DATA	= "./data/results/20140622-215755-round3.txt";
	public static final String FILE_PATH_R1 	= "./data/gnuplot/precision/precision_r1.txt";
	public static final String FILE_PATH_R2 	= "./data/gnuplot/precision/precision_r2.txt";
	public static final String FILE_PATH_R3 	= "./data/gnuplot/precision/precision_r3.txt";
	public static final String FILE_PATH_ERROR_DIST 	= "./data/gnuplot/precision/error_dist.txt";
	
	private static final String STR_NOTHING = "[Nothing]";
	
	public static class DataItem {
		double sr1;
		double sr2;
		double sr3;
		double ar1;
		double ar2;
		double ar3;
	}
	
	public static void main(String[] args) throws IOException {
		List<DataItem> data = new ArrayList<>();
		try (FileInputStream fis = new FileInputStream(FILE_RAW_DATA); 
				Scanner scanner = new Scanner(fis)) {
			while (scanner.hasNext()) {
				DataItem t = new DataItem();
				// 4 16 6 64 1 1 2 1 50 0.641 0.641 0.641 0.8019396732313537 0.8019396732313537 0.8019396732313537
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				t = parse(scanner.nextLine());
				if (t != null)
					data.add(t);
			}
			ensureFile(FILE_PATH_R1);
			ensureFile(FILE_PATH_R2);
			ensureFile(FILE_PATH_R3);
			FileWriter fr1 = new FileWriter(FILE_PATH_R1);
			FileWriter fr2 = new FileWriter(FILE_PATH_R2);
			FileWriter fr3 = new FileWriter(FILE_PATH_R3);
			for (DataItem t : data) {
				fr1.append("" + t.sr1 + " " + t.ar1 + "\n");
				fr2.append("" + t.sr2 + " " + t.ar2 + "\n");
				fr3.append("" + t.sr3 + " " + t.ar3 + "\n");
			}
			fr1.close();
			fr2.close();
			fr3.close();
			genErrorDistributionData(data);
		}
		System.out.println("OK!");
	}

	private static void genErrorDistributionData(List<DataItem> data) {
		
	}

	private static DataItem parse(String line) {
		// sr1 sr2 sr1 ar1 ar2 ar3
		DataItem t = new DataItem();
		String[] parts = line.trim().split("\\s+");
		
		if (parts[0].equals(STR_NOTHING) || parts[1].equals(STR_NOTHING) || parts[2].equals(STR_NOTHING)) {
			return null;
		} else {
			t.sr1 = Double.parseDouble(parts[0]);
			t.sr2 = Double.parseDouble(parts[1]);
			t.sr3 = Double.parseDouble(parts[2]);
			t.ar1 = Double.parseDouble(parts[3]);
			t.ar2 = Double.parseDouble(parts[4]);
			t.ar3 = Double.parseDouble(parts[5]);
			return t;
		}
	}
}
