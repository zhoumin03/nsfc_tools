package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.util.List;

import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Invoker;

/**
 * 基础的Optimizer类
 * @author aleck
 *
 */
public abstract class AbstractOptimizer implements IOptimizer {
	protected TargetManager tm;
	protected ProblemWrapper wrapper;
	protected Evaluator evaluator;
	
	private long startTime;
	
	public AbstractOptimizer(Category category, Evaluator evaluator, ProblemWrapper wrapper) {
		this.tm = new TargetManager(category);
		this.evaluator = evaluator;
		this.wrapper = wrapper;
	}
	
	public TargetManager getTargetManager() {
		return tm;
	}
	
	@Override
	public void setUp() {
		tm.clear();
		tm.loadTargets();
	}

	@Override
	public void tearDown() {
		tm.printTestCases();
	}
	
	/**
	 * evaluate the fitness of an input
	 * @param input
	 * @return
	 */
	protected double evaluate(Input input) {
		boolean exception = !safeInvoke(wrapper.getInvoker(), input);
		double penalty = exception ? OptimizeParameter.EXCEPTION_PENALTY : 0;
		
		// idx:		0		1		2		3
		// block:	b1		b2		b3		b4
		// dist:	-1		b1->~b2	b2->~b3	b3->~b4
		//                      ^-- note, ~bx means not bx
		List<Integer> trace = RT.currentTrace();
		List<Double> traceDist = RT.currentTraceDist();
		// hit targets in the trace
		tm.hitTargetAlongTheTrace(input, trace);
		
		if (tm.currentTarget() == null) {
			// 纯随机覆盖阶段，直接退出
			return penalty + OptimizeParameter.DEFAULT_RANDOM_FITNESS;
		} else {
			return penalty + evaluator.evaluate(tm.currentTarget(), trace, traceDist);
		}
	}

	/**
	 * Block all exceptions
	 * @param input
	 * @return true if no exception, false otherwise.
	 */
	protected boolean safeInvoke(Invoker invoker, Input input) {
		try {
			invoker.invoke(input);
			return true;
		} catch (Exception e) {
			// System.out.println("Exception when invoking: " + e.getMessage());
			return false;
		}
	}

	protected void printTrace(List<Integer> trace) {
		boolean first = true;
		System.out.print("trace: ");
		for (Integer id : trace) {
			if (!first) 
				System.out.print("-");
			System.out.print(id);
			first = false;
		}
		System.out.println();
	}

	protected void clockStart() {
		startTime = System.currentTimeMillis();
	}
	
	protected long currentTimeConsumed() {
		return (System.currentTimeMillis() - startTime);
	}

}
