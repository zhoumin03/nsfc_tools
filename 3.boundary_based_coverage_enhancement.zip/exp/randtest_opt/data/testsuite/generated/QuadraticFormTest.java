package algorithm.test;

import junit.framework.TestCase;
import algorithm.QuadraticForm;

public class QuadraticFormTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T13_16, T1_3, T6_10, T10_13]
	public void test00() {
		assertEquals((9), QuadraticForm.getGeometryType((double)-0.990053839121802, 
														 (double)0.09999978963, 
														 (double)0.0, 
														 (double)-0.1, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T1_3, T15_21, T11_15, T21_24, T6_11]
	public void test01() {
		assertEquals((72), QuadraticForm.getGeometryType((double)-1.0, 
														 (double)-0.1, 
														 (double)1.0, 
														 (double)-1.1249828080888529E122, 
														 (double)1233539.2307765242, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T1_3, T19_23, T14_19, T11_14, T6_11]
	public void test02() {
		assertEquals((2), QuadraticForm.getGeometryType((double)-1.800972522E86, 
														 (double)-2.7860284000000004E-8, 
														 (double)-5.9269785280622602E18, 
														 (double)-1.2411460012702633E27, 
														 (double)-2284.097879529962, 
														 (double)5002.378069797155));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T1_3, T14_19, T19_22, T11_14, T6_11]
	public void test03() {
		assertEquals((34), QuadraticForm.getGeometryType((double)-1.0, 
														 (double)0.0, 
														 (double)-1.0, 
														 (double)-2.56023565477663E59, 
														 (double)6.877157087586186E33, 
														 (double)6.383619938848805E66));
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T1_2, T2_4, T4_7]
	public void test04() {
		assertEquals((-1), QuadraticForm.getGeometryType((double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T1_3, T11_14, T14_18, T6_11]
	public void test05() {
		assertEquals((0), QuadraticForm.getGeometryType((double)-0.1, 
														 (double)0.39537616000000003, 
														 (double)-1.2528093938945197, 
														 (double)0.0, 
														 (double)0.09886121559, 
														 (double)-0.0954334164));
	}
	//<<case-end>>
	//<<case-begin>>
	//#6, coverages: [T1_3, T21_25, T15_21, T11_15, T6_11]
	public void test06() {
		assertEquals((8), QuadraticForm.getGeometryType((double)-0.30007631746947067, 
														 (double)-2.8645113E67, 
														 (double)-1.3788305758727775E-6, 
														 (double)2.9277675289834154E-9, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#7, coverages: [T1_3, T21_25, T15_21, T11_15, T6_11]
	public void test07() {
		assertEquals((8), QuadraticForm.getGeometryType((double)-1.156425E-6, 
														 (double)-0.13591648440555282, 
														 (double)-1.000267282, 
														 (double)0.0, 
														 (double)-3.2411782818047364E-9, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#8, coverages: [T1_2, T2_5]
	public void test08() {
		assertEquals((17), QuadraticForm.getGeometryType((double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)3.7986201859693395E-7, 
														 (double)-1.453822471725298E16, 
														 (double)0.1));
	}
	//<<case-end>>
	//<<case-begin>>
	//#9, coverages: [T1_3, T21_25, T15_21, T11_15, T6_11]
	public void test09() {
		assertEquals((8), QuadraticForm.getGeometryType((double)1.1894969667585768E8, 
														 (double)2.795207425257216E28, 
														 (double)-1.7136389991476139E-7, 
														 (double)-8.512284047979223E-9, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#10, coverages: [T1_3, T10_12, T6_10]
	public void test10() {
		assertEquals((3), QuadraticForm.getGeometryType((double)-0.007916783072128036, 
														 (double)0.01698962854, 
														 (double)-0.324897886, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#11, coverages: [T1_3, T21_25, T15_21, T11_15, T6_11]
	public void test11() {
		assertEquals((8), QuadraticForm.getGeometryType((double)-4.6119353233833764E58, 
														 (double)-0.12081807902762848, 
														 (double)3.857616521E-6, 
														 (double)-1.5803020000000002E-9, 
														 (double)0.0, 
														 (double)0.0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#12, coverages: [T1_2, T2_4, T4_8]
	public void test12() {
		assertEquals((0), QuadraticForm.getGeometryType((double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)0.0, 
														 (double)1.7044922499999998E-16));
	}
	//<<case-end>>
	//<<case-begin>>
	//#13, coverages: [T1_3, T21_25, T15_21, T11_15, T6_11]
	public void test13() {
		assertEquals((8), QuadraticForm.getGeometryType((double)0.0, 
														 (double)-0.1, 
														 (double)-9.450874783252037E-10, 
														 (double)1.0, 
														 (double)0.1, 
														 (double)99422.32133340578));
	}
	//<<case-end>>
}
