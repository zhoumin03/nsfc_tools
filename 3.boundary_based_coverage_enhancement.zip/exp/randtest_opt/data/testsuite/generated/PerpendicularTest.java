package algorithm.test;

import algorithm.Perpendicular;
import junit.framework.TestCase;

public class PerpendicularTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T3_6, T6_8, T1_3]
	public void test00() {
		assertEquals((false), Perpendicular.isPerpendicular(11, 12, 2147483647, -1));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T3_6, T6_8, T1_3]
	public void test01() {
		assertEquals((false), Perpendicular.isPerpendicular(-6, -1, -27, 84368));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T3_5, T1_3]
	public void test02() {
		assertEquals((false), Perpendicular.isPerpendicular(-131291585, 10, 0, -2147483648));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T3_6, T1_3, T6_7]
	public void test03() {
		assertEquals((true), Perpendicular.isPerpendicular(1, -1, -1, 1));
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T1_2]
	public void test04() {
		assertEquals((false), Perpendicular.isPerpendicular(-9, 0, -268533, -1153997754));
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T3_6, T6_8, T1_3]
	public void test05() {
		assertEquals((false), Perpendicular.isPerpendicular(-1, 21495757, -120, -1936774841));
	}
	//<<case-end>>
}
