package cn.edu.tsinghua.thss.randtest.alg.core;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class RandTestToolTest {
	private static final String CONFIG_BASE = "./config/";
	
	private static final String[] CONFIG_FILE_LIST = new String[] {
		"test/int_barrier.txt",
		"test/double_barrier.txt",
//		"alphabet_checker.txt",
//		"array_is_monotonic.txt", 
//		"binary_search.txt",
//		"bubble_sort.txt",
//		"cold_branch_test.txt",
//		"date_util.txt",
//		"find_max.txt",
//		"greatest_common_divider.txt",
//		"heap_sort.txt",
//		"inv_hyperbolic_sine.txt",
//		"is_power_of_two.txt",
//		"max3.txt",
//		"newton.txt",
//		"palindromic.txt",
//		"perpendicular.txt",
//		"prime_checker.txt",
//		"quadratic_form.txt",
//		"second_order_equation_solver.txt",
//		"string_is_number.txt",
//		"tax_calc.txt",
//		"triangle_classifier.txt",
	};

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) {
		int total = CONFIG_FILE_LIST.length;
		int success = 0;
		int failed = 0;
		for (String cfn : CONFIG_FILE_LIST) {
			try {
				handleSingleConfigFile(CONFIG_BASE + cfn);
				success ++;
			} catch (FileNotFoundException e) {
				failed ++;
				System.err.println(e.getMessage());
			} catch (IOException e) {
				failed ++;
				System.err.println(e.getMessage());
			}
		}
		System.out.println(String.format("success=%d/%d, failed=%d.",
				success, total, failed));
	}

	private static void handleSingleConfigFile(String configFileName) throws FileNotFoundException, IOException {
		Properties props = new Properties();
		props.load(new FileInputStream(configFileName));
		RandTestTool rtt = new RandTestTool(props);
		rtt.execute();
	}

}
