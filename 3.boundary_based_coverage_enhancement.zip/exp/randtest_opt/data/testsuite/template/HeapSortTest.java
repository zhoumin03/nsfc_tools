package algorithm.test;

import java.util.Arrays;
import junit.framework.TestCase;
import algorithm.HeapSort;

public class HeapSortTest extends TestCase {
	//--lines starts with '//--' are ommited
		//--$c: comment
		//--$$: case id
		//--$_: the expected return value
		//--$n: the n-th parameter
		//--always use with brackets to avoid ambiguity
		//--contents between <<case-begin>> and <<case-end>> are a single case
		
		//<<case-begin>>
		//<$c>
	public void test$$() {
		Object[] data = (Object[]) ($0);
		int[] a = new int[data.length];
		int[] b = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
			b[i] = (Integer) data[i];
		}
		HeapSort.sort(a);
		Arrays.sort(b);
		assertEquals(a.length, b.length);
		for (int i = 0; i < a.length; i++) {
			assertEquals(a[i],  b[i]);
		}
	}
		//<<case-end>>
}
