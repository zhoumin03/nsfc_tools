package algorithm.test;

import java.util.Arrays;

import junit.framework.TestCase;
import algorithm.BubbleSort;

public class BubbleSortTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T6_9, T2_3, T6_8, T5_6, T5_7]
	public void test00() {
		Object[] data = (Object[]) (new java.lang.Object[]{10, 658765, 10, 2602068, 14405387, 10, -10, -35, -532747427});
		int[] a = new int[data.length];
		int[] b = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
			b[i] = (Integer) data[i];
		}
		BubbleSort.sort(a);
		Arrays.sort(b);
		assertEquals(a.length, b.length);
		for (int i = 0; i < a.length; i++) {
			assertEquals(a[i],  b[i]);
		}
	}
	//<<case-end>>
}
