package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.Evaluator.Strategy;

public class TexUtils {
	private static final int FULLY_RANDOM_OPTIMIZER = 0;
	private static final int MEMETIC_OPTIMIZER = 1;
	
	// list of problems
	private List<String> problems;
	// list of statements
	private List<String> statements;
	// list of cyclomatic
	private List<String> cyclomatic;
	// list of targets
	private List<String> targets;
	// Optimizer x Category x Strategy -> (Problem -> Content)
	private Map<String, Detail>[][][] content;

	private static class Detail {
		public String timestamp;
		public String statements;
		public String cyclomatic;
		public String category;
		public String strategy;
		public String optimizer;
		public String problem;
		public String repeat;
		public String targets;
		public String iteration;
		public String covered;
		public String coverage;
		public String maxcover;
		public String maxcovercnt;
		public String time;
	}
	
	@SuppressWarnings("unchecked")
	public TexUtils() {
		problems = new ArrayList<String>();
		statements = new ArrayList<String>();
		cyclomatic = new ArrayList<String>();
		targets = new ArrayList<String>();
		content = new Map[2][Category.values().length][Strategy.values().length];
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < Category.values().length; j++) {
				for (int k = 0; k < Strategy.values().length; k++) {
					content[i][j][k] = new HashMap<String, Detail>();
				}
			}
		}
	}

	/**
	 * 读取记录
	 * @param filename
	 * @throws IOException
	 */
	public void readData(String filename) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
		String line;
		/*
		>>>-------------------------------------
		timestamp=20121222_02:40:57
		statement=15
		cyclomatic=6
		category=BRANCH
		strategy=NODE_PLUS_DIST
		optimizer=cn.edu.tsinghua.thss.randtest.rt.algorithm.MemeticOptimizerTest
		problem=cn.edu.tsinghua.thss.randtest.cases.artificial.PrimeCheckerProblemWrapper
		repeat=1000
		targets=10
		iteration=(min=1.000000, max=47.000000, average=5.813000, stdev=5.522366)
		covered=(min=10.000000, max=10.000000, average=10.000000, stdev=0.000000)
		coverage=(min=1.000000, max=1.000000, average=1.000000, stdev=0.000000)
		max_cover=10
		max_cover_cnt=1000(100.0%)
		time=(min=0.000000, max=0.023000, average=0.001127, stdev=0.002225)
		<<<-------------------------------------
		*/
		while ((line = br.readLine()) != null) {
			if (line.startsWith(">>>")) {
				Detail detail = new Detail();
				try {
					detail.timestamp	= value(br.readLine());
					detail.statements	= value(br.readLine());
					detail.cyclomatic	= value(br.readLine());
					detail.category 	= value(br.readLine());
					detail.strategy 	= value(br.readLine());
					detail.optimizer 	= value(br.readLine());
					detail.problem 		= value(br.readLine());
					detail.repeat 		= value(br.readLine());
					detail.targets 		= value(br.readLine());
					detail.iteration 	= value(br.readLine());
					detail.covered 		= value(br.readLine());
					detail.coverage 	= value(br.readLine());
					detail.maxcover 	= value(br.readLine());
					detail.maxcovercnt 	= value(br.readLine());
					detail.time 		= value(br.readLine());
					line = br.readLine();
					if (line.startsWith("<<<")) {
						int optimizer;
						if (detail.optimizer.endsWith("FullyRandomOptimizerTest")) {
							optimizer = FULLY_RANDOM_OPTIMIZER;
						} else if (detail.optimizer.endsWith("MemeticOptimizerTest")) {
							optimizer = MEMETIC_OPTIMIZER;
						} else {
							throw new RuntimeException("unknown optimizer: " + detail.optimizer);
						}
						int category = Enum.valueOf(Category.class, detail.category).ordinal();
						int strategy = Enum.valueOf(Strategy.class, detail.strategy).ordinal();
						content[optimizer][category][strategy].put(detail.problem, detail);
						if (!problems.contains(detail.problem)) {
							problems.add(detail.problem);
							statements.add(detail.statements);
							cyclomatic.add(detail.cyclomatic);
							targets.add(detail.targets);
						}
					} else {
						throw new RuntimeException("end of detail expected, but: " + line);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		br.close();
	}
	
	private String value(String str) {
		int idx = str.indexOf('=');
		if (idx == -1) {
			throw new RuntimeException("string should contain '='");
		} else {
			return str.substring(idx + 1);
		}
	}

	public void exportToExcelTable(File file) {
        WritableWorkbook wwb = null;   
        try {   
            //首先要使用Workbook类的工厂方法创建一个可写入的工作薄(Workbook)对象   
            wwb = Workbook.createWorkbook(file);   
        } catch (IOException e) {   
            e.printStackTrace();   
        }
        if (wwb != null) {
        	int workSheetIndex = 0;
        	for (Category category : Category.values()) {
                //创建一个可写入的工作表   
                //Workbook的createSheet方法有两个参数，第一个是工作表的名称，第二个是工作表在工作薄中的位置   
                WritableSheet ws = wwb.createSheet(
                		category.toString(), 
                		workSheetIndex++);
                // Category
                //		Iteration	Time		Coverage	MaxCover	MaxCoverCnt	
                //      F	M1	M2	F	M1	M2	F	M1	M2	F	M1	M2	F	M1	M2
                // P1
                // P2
                // 写入第一行
                try {
                	// 第一行
					ws.addCell(new Label(0, 0, category.toString()));
					// 第二行
					ws.addCell(new Label(1, 1, "Iteration"));
					ws.addCell(new Label(4, 1, "Time"));
					ws.addCell(new Label(7, 1, "Coverage"));
					ws.addCell(new Label(10, 1, "MaxCover"));
					ws.addCell(new Label(13, 1, "MaxCoverCnt"));
					final String[] strategies = new String[] {"Random", "Node", "Node+Dist", };
					for (int j = 0; j < 15; j++) {
						ws.addCell(new Label(j + 1, 2, strategies[j % 3]));
					}
					
					int baseRow = 3;
					for (int i = 0; i < problems.size(); i++) {
						String problem = problems.get(i);
						String rowhead = problem;
						int liod = rowhead.lastIndexOf('.');
						if (liod != -1) {
							rowhead = rowhead.substring(liod + 1);
						}
						rowhead += "\n(stat=" + statements.get(i) + ")(cycl=" + cyclomatic.get(i) + ")(targ=" + targets.get(i) + ")";
						ws.addCell(new Label(0, baseRow + i, rowhead));
						// FullyRandomOptimizer 对应的 Strategy 可能是 STATEMENT 或者 BRANCH (没有用到)
						// 因此，检查 0 / 1
						Detail fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][0].get(problem);
						if (fd == null) {
							fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][1].get(problem);
						}
						if (fd != null) {
							int base = 1;
							int offset = 3;
							ws.addCell(new Label(base + 0 * offset, baseRow + i, formatStatisticResult(fd.iteration)));
							ws.addCell(new Label(base + 1 * offset, baseRow + i, formatStatisticResult(fd.time)));
							ws.addCell(new Label(base + 2 * offset, baseRow + i, formatStatisticResult(fd.coverage)));
							ws.addCell(new Label(base + 3 * offset, baseRow + i, formatStatisticResult(fd.maxcover)));
							ws.addCell(new Label(base + 4 * offset, baseRow + i, formatStatisticResult(fd.maxcovercnt)));
						}
						Detail md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_ONLY.ordinal()].get(problem);
						if (md != null) {
							int base = 2;
							int offset = 3;
							ws.addCell(new Label(base + 0 * offset, baseRow + i, formatStatisticResult(md.iteration)));
							ws.addCell(new Label(base + 1 * offset, baseRow + i, formatStatisticResult(md.time)));
							ws.addCell(new Label(base + 2 * offset, baseRow + i, formatStatisticResult(md.coverage)));
							ws.addCell(new Label(base + 3 * offset, baseRow + i, formatStatisticResult(md.maxcover)));
							ws.addCell(new Label(base + 4 * offset, baseRow + i, formatStatisticResult(md.maxcovercnt)));
						}
						md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_PLUS_DIST.ordinal()].get(problem);
						if (md != null) {
							int base = 3;
							int offset = 3;
							ws.addCell(new Label(base + 0 * offset, baseRow + i, formatStatisticResult(md.iteration)));
							ws.addCell(new Label(base + 1 * offset, baseRow + i, formatStatisticResult(md.time)));
							ws.addCell(new Label(base + 2 * offset, baseRow + i, formatStatisticResult(md.coverage)));
							ws.addCell(new Label(base + 3 * offset, baseRow + i, formatStatisticResult(md.maxcover)));
							ws.addCell(new Label(base + 4 * offset, baseRow + i, formatStatisticResult(md.maxcovercnt)));
						}
					}
					// 调整列宽
					final int headwidth = 30;
					final int columnwidth = 18;
					final int rowheight = 450;
					ws.setColumnView(0, headwidth);
					for (int i = 1; i <= 16; i++) {
						ws.setColumnView(i, columnwidth);
					}
					for (int i = 0; i < problems.size(); i++) {
						ws.setRowView(i + baseRow, rowheight, false);
					}
				} catch (RowsExceededException e1) {
					e1.printStackTrace();
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
        	}
  
            try {   
                //从内存中写入文件中   
                wwb.write();   
                //关闭资源，释放内存   
                wwb.close();   
            } catch (IOException e) {   
                e.printStackTrace();   
            } catch (WriteException e) {   
                e.printStackTrace();   
            }   
        }   
    }   

	public void exportToTexTable(File file) {
		try {
			// 打开文件
			PrintStream ps = new PrintStream(file);

			// 问题列表
			// Problem	LOC		#STAT	Cyclomatic	Note
			ps.println("[BEGIN:Problems]");
			for (int i = 0; i < problems.size(); i++) {
				String problem = problems.get(i);
				String shortname = shortProblemName(problem);
				ps.println(String.format("%s & 0 & %s & %s & [NOTE]\\\\", 
						shortname, statements.get(i), cyclomatic.get(i)));
			}
			ps.println("[END:Problems]");
			ps.println();
			
        	for (Category category : Category.values()) {
                //创建一个可写入的工作表   
        		ps.println("[BEGIN: Category=" + category + "]");
        		
        		// 分成两个表输出
        		
        		ps.println("[BEGIN: table: iteration+time]");
                // Category
                //		Iteration	Time			
                //      F	M1	M2	F	M1	M2	
                // P1
                // P2
        		final String t1format = "%10s & %10s & %10s & %10s & %10s & %10s & %10s & %10s \\\\";
        		ps.println(String.format(t1format,
        				"Problem", "$|T|$", "R", "ID", "ID+BD", "R", "ID", "ID+BD"
        				));
        		for (int i = 0; i < problems.size(); i++) {
        			String problem = problems.get(i);
					Object[] values = new Object[8];
					values[0] = "$P_{" + (i + 1) + "}$";
					values[1] = targets.get(i);
					Detail fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][0].get(problem);
					if (fd == null) {
						fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][1].get(problem);
					}
					if (fd != null) {
						int base = 2;
						int offset = 3;
						values[base + 0 * offset] = averageAsIntStr(fd.iteration);
						values[base + 1 * offset] = averageAsRealStr(fd.time, 2);
					}
					Detail md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_ONLY.ordinal()].get(problem);
					if (md != null) {
						int base = 3;
						int offset = 3;
						values[base + 0 * offset] = averageAsIntStr(md.iteration);
						values[base + 1 * offset] = averageAsRealStr(md.time, 2);
					}
					md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_PLUS_DIST.ordinal()].get(problem);
					if (md != null) {
						int base = 4;
						int offset = 3;
						values[base + 0 * offset] = averageAsIntStr(md.iteration);
						values[base + 1 * offset] = averageAsRealStr(md.time, 2);
					}
					ps.println(String.format(t1format, values));
        		}
        		ps.println("[END: table: iteration+time]");
        		ps.println();

        		ps.println("[BEGIN: table: coverage]");
                // Category
                //		Coverage	MaxCoverCnt	
                //      F	M1	M2	F	M1	M2	
                // P1
                // P2
        		final String t2format = "%10s & %10s & %10s & %10s & %10s & %10s & %10s & %10s \\\\";
        		ps.println(String.format(t1format,
        				"Problem", "$|T|$", "R", "ID", "ID+BD", "R", "ID", "ID+BD"
        				));
        		for (int i = 0; i < problems.size(); i++) {
        			String problem = problems.get(i);
					Object[] values = new Object[8];
					values[0] = "$P_{" + (i + 1) + "}$";
					values[1] = targets.get(i);
					Detail fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][0].get(problem);
					if (fd == null) {
						fd = content[FULLY_RANDOM_OPTIMIZER][category.ordinal()][1].get(problem);
					}
					if (fd != null) {
						int base = 2;
						int offset = 3;
						values[base + 0 * offset] = 
								averageAsRealStr(fd.coverage, 0, 100) + 
								"(" + formatDoubleAsString(100 * Double.parseDouble(fd.maxcover) / Double.parseDouble(fd.targets), 0) + ")";
						values[base + 1 * offset] =
								formatDoubleAsString(maxCountStr2Double(fd.maxcovercnt), 1);
					}
					Detail md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_ONLY.ordinal()].get(problem);
					if (md != null) {
						int base = 3;
						int offset = 3;
						values[base + 0 * offset] = 
								averageAsRealStr(md.coverage, 0, 100) + 
								"(" + formatDoubleAsString(100 * Double.parseDouble(md.maxcover) / Double.parseDouble(fd.targets), 0) + ")";
						values[base + 1 * offset] = 
								formatDoubleAsString(maxCountStr2Double(md.maxcovercnt), 1);
					}
					md = content[MEMETIC_OPTIMIZER][category.ordinal()][Strategy.NODE_PLUS_DIST.ordinal()].get(problem);
					if (md != null) {
						int base = 4;
						int offset = 3;
						values[base + 0 * offset] = 
								averageAsRealStr(md.coverage, 0, 100) + 
								"(" + formatDoubleAsString(100 * Double.parseDouble(md.maxcover) / Double.parseDouble(fd.targets), 0) + ")";
						values[base + 1 * offset] = 
								formatDoubleAsString(maxCountStr2Double(md.maxcovercnt), 1);
					}
					ps.println(String.format(t2format, values));
        		}
        		ps.println("[END: table: coverage]");
        		ps.println();
        		
        		ps.println("[END: category");
        		ps.println();

        	}

			// 关闭文件
			ps.close();
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		}
    }
	
	private double maxCountStr2Double(String maxcovercnt) {
		// 1000(100.0%)
		int i1 = maxcovercnt.indexOf('(');
		int i2 = maxcovercnt.indexOf(')');
		return Double.parseDouble(maxcovercnt.substring(i1 + 1, i2 - 1));
	}

	private String formatDoubleString(String str, int precision) {
		return formatDoubleAsString(Double.parseDouble(str), precision);
	}

	private String formatDoubleAsString(Double value, int precision) {
		boolean negative = false;
		if (value < 0) {
			negative = true;
			value = -value;
		}
		double shift = Math.pow(10, precision);
		value = Math.round(value * shift) / shift;
		double intpart = Math.floor(value);
		double fracpart = value - intpart;
		StringBuilder sb = new StringBuilder();
		if (negative) {
			sb.append('-');
		}
		sb.append((int)intpart);
		if (precision > 0) {
			sb.append('.');
			for (int i = 0; i < precision; i++) {
				fracpart = fracpart * 10;
				sb.append((int)Math.floor(fracpart));
				fracpart = fracpart - Math.floor(fracpart);
			}
		}
		return sb.toString();
	}

	private String escapeToTexStr(String original) {
		String ret = original.replace("%", "\\%");
		return ret;
	}

	private String shortProblemName(String problem) {
		int liod = problem.lastIndexOf('.');
		if (liod != -1) {
			problem = problem.substring(liod + 1);
		}
		if (problem.endsWith("ProblemWrapper")) {
			problem = problem.substring(0, problem.length() - 14);
		}
		return problem;
	}

	private String formatStatisticResult(String statline) {
		// (min=1.000000, max=7.000000, average=1.440000, stdev=0.868297)
		int i1 = statline.indexOf("average=");
		int i2 = statline.indexOf(',', i1);
		int i3 = statline.indexOf("stdev=");
		int i4 = statline.indexOf(")");
		if (i1 == -1 || i2 == -1 || i3 == -1 || i4 == -1) {
			return statline;
		} else {
			String ave = statline.substring(i1 + 8, i2);
			String dev = statline.substring(i3 + 6, i4);
			return ave + "\n(stdev=" + dev + ")";
		}
	}
	
	private String averageAsIntStr(String statline) {
		return averageAsIntStr(statline, 1);
	}
	
	private String averageAsIntStr(String statline, double multiple) {
		// (min=1.000000, max=7.000000, average=1.440000, stdev=0.868297)
		int i1 = statline.indexOf("average=");
		int i2 = statline.indexOf(',', i1);
		if (i1 == -1 || i2 == -1) {
			throw new RuntimeException("not a statistics line: " + statline);
		} else {
			String ave = statline.substring(i1 + 8, i2);
			double value = Double.parseDouble(ave) * multiple;
			return "" + ((int) value);
		}
	}
	
	private String averageAsRealStr(String statline, int precision) {
		return averageAsRealStr(statline, precision, 1);
	}
	
	private String averageAsRealStr(String statline, int precision, double multiple) {
		// (min=1.000000, max=7.000000, average=1.440000, stdev=0.868297)
		int i1 = statline.indexOf("average=");
		int i2 = statline.indexOf(',', i1);
		if (i1 == -1 || i2 == -1) {
			throw new RuntimeException("not a statistics line: " + statline);
		} else {
			String ave = statline.substring(i1 + 8, i2);
			double value = Double.parseDouble(ave) * multiple;
			return formatDoubleAsString(value, precision);
		}
	}

	public static void main(String[] args) throws IOException {
		File xlsFile = new File("./data/tex/table.xls");
		File texFile = new File("./data/tex/table.txt");
		if (xlsFile.exists())
			xlsFile.delete();
		if (texFile.exists())
			texFile.delete();
		FileUtils.ensureFile(xlsFile);
		FileUtils.ensureFile(texFile);
		
		TexUtils tu = new TexUtils();
		tu.readData(OptimizerTest.GLOBAL_LOG_FILE);
		tu.exportToExcelTable(xlsFile);
		tu.exportToTexTable(texFile);
		System.out.println("done");
	}
}
