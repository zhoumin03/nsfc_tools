package cov.exp.model;

public interface Transition {
	public double getProbability();
}
