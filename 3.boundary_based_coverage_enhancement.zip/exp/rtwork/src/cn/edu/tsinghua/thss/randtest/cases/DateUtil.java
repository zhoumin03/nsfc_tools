package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class DateUtil {
	public static boolean isLeapYear(int year) {
		RT.startInvocation(1556572476045739008L);
		RT.track(1);
		if (((RT.b(0)) && (RT.eq(0, year % 400, 0))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return true;
		}
		RT.nd(0);
		RT.track(3);
		if (((RT.b(1)) && (RT.eq(0, year % 4, 0))) && (RT.e(1))) {
			RT.pd(1);
			RT.track(5);
			if (((RT.b(2)) && (RT.eq(0, year % 100, 0))) && (RT.e(2))) {
				RT.pd(2);
				RT.track(7);
				return false;
			} else {
				RT.nd(2);
				RT.track(8);
				return true;
			}
		} else {
			RT.nd(1);
			RT.track(6);
			return false;
		}
	}
}
