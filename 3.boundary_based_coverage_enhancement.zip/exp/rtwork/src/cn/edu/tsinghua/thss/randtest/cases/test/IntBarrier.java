package cn.edu.tsinghua.thss.randtest.cases.test;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class IntBarrier {
	public static int f(int x) {
		RT.startInvocation(4269051919714895872L);
		RT.track(1);
		if (((RT.b(0)) && (RT.gt(0, x, 0))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return 1;
		} else {
			RT.nd(0);
			RT.track(3);
			return 0;
		}
	}
}
