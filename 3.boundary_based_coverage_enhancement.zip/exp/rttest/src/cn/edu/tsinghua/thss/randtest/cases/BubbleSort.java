package cn.edu.tsinghua.thss.randtest.cases;

import java.util.Arrays;

public class BubbleSort {
	public static void sort(int[] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 1; i + j < a.length; j++) {
				if (a[i] > a[i + j]) {
					int temp = a[i];
					a[i] = a[i + j];
					a[i + j] = temp;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		Integer[] b = new Integer[10];
		int[] a = new int[] {3, 2, 35, 6, 2, 5};
		// a = b;
		BubbleSort.sort(a);
		System.out.println(Arrays.toString(a));
	}
}
