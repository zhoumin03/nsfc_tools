package algorithm.test;

import junit.framework.TestCase;
import algorithm.PrimeChecker;

public class PrimeCheckerTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T8_9, T9_12, T10_13, T1_2, T2_5]
	public void test00() {
		PrimeChecker primeChecker0 = new PrimeChecker();
		assertEquals((true), primeChecker0.isPrime((int) 10230959));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_4, T1_2]
	public void test01() {
		PrimeChecker primeChecker0 = new PrimeChecker();
		assertEquals((false), primeChecker0.isPrime((int) 101808022));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T10_14, T8_9, T9_11, T1_2, T2_5]
	public void test02() {
		PrimeChecker primeChecker0 = new PrimeChecker();
		assertEquals((false), primeChecker0.isPrime((int) 2526));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T10_13, T8_10, T1_2, T2_5]
	public void test03() {
		PrimeChecker primeChecker0 = new PrimeChecker();
		assertEquals((true), primeChecker0.isPrime((int) 3));
	}
	//<<case-end>>
}
