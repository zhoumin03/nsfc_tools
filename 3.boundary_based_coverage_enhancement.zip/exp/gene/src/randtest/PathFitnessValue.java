package randtest;

import gene.IFitnessValue;

import java.util.List;

public class PathFitnessValue implements IFitnessValue {
	public List<String> path;
	public int depth;
	public int dist;

	/**
	 * Fitness的值越大，表示相应的元素越"小"
	 * 在Java中，容器都按照从小到大排序；而Gene算法中，我们要找Fitness尽量大的。
	 * 因此这么定义
	 */
	@Override
	public int compareTo(IFitnessValue o) {
		PathFitnessValue that = (PathFitnessValue) o;
		if (this.depth == that.depth) {
			// 距离越大越好，返回值越小
			return that.dist - this.dist;
		} else {
			// depth越大越好，返回值越小
			return that.depth - this.depth;
		}
	}
	
	@Override
	public String toString() {
		return "path=" + path.toString() + ", depth=" + depth + ", dist=" + dist + ", d_value=" + getDoubleValue();
	}

	@Override
	public double getDoubleValue() {
		return 1.0 * depth * Integer.MAX_VALUE + dist;
	}
}
