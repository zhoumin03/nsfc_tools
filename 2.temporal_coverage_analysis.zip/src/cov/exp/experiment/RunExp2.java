package cov.exp.experiment;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import cov.exp.algorithm.DataCollector;
import cov.exp.algorithm.DetectingProbInfer;
import cov.exp.algorithm.ExpParameter;
import cov.exp.algorithm.Simulator;
import cov.exp.algorithm.SystemGenerator;
import cov.exp.external.maple.MapleEngine;
import cov.exp.model.Bin;
import cov.exp.model.InferResult;
import cov.exp.model.State;
import cov.exp.model.SystemModel;

public class RunExp2 {
	private static final String OUTPUT_PATH = "./data/results/exp2";

	public static class ExpSetting {
		public ExpParameter params;
		public SystemModel system;
		public Set<Integer> targets;
		
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			sb.append("n=" + params.nInputPins + ", ");
			sb.append("m=" + params.nFlipflops + ", ");
			sb.append("b=" + params.nBins + ", ");
			sb.append("t=" + params.targetSize + ", ");
			sb.append("M=" + params.cycles + ", ");
			sb.append("R=" + params.simulationRepeats + ", ");
			sb.append("init=" + params.initialStateRatio + ", ");
			sb.append("#init=" + system.initials.size() + ", ");
			sb.append("bug=" + params.bugDetectStateRatio);
			sb.append("]");
			return sb.toString();
		}
	}

	public static void main(String[] args) throws IOException {
//		int seed = 0;
//		while (true) {
//			invokeWithSeed(seed);
//			seed ++;
//		}
		
		MapleEngine.start();
		
		invokeWithSeed(15);
		
		MapleEngine.stop();
		
		System.out.println("Finished at " + Calendar.getInstance().getTime());
		
		/*
		// manual test case 1
		ExpParameter params = new ExpParameter();
		params.nInputPins = 1;
		params.nFlipflops = 2;
		params.nBins = 2;
		params.bugDetectStateRatio = 0.25;
		params.cycles = 3;
		params.simulationRepeats = 10000;
		Set<Integer> subset = new HashSet<>();
		SystemModel system = new SystemModel();
		State s00 = new State();	s00.flipflops = 0;
		State s01 = new State();	s01.flipflops = 1;
		State s10 = new State();	s10.flipflops = 2;
		State s11 = new State();	s11.flipflops = 3;		s11.bug = true;
		system.states = new State[] {s00, s01, s10, s11};
		s00.transitions = new State[] {s10, s01};
		s01.transitions = new State[] {s00, s00};
		s10.transitions = new State[] {s11, s01};
		s11.transitions = new State[] {s01, s11};
		Bin b0 = new Bin(0);
		Bin b1 = new Bin(1);
		system.bins = new Bin[] {b0, b1};
		b0.attach(s00); b0.attach(s01);
		b1.attach(s10); b1.attach(s11);
		system.addInitial(s00);
		system.params = params;
		system.numOfBins = 2;
		system.numOfInputPatterns = 2;
		system.numOfStates = 4;
		system.display(System.out);
		subset.add(0);	// b0
		*/
		
		/*
		// randomly generated test case
		// set up parameters
		ExpParameter params = new ExpParameter();
		params.nInputPins = 1;
		params.nFlipflops = 4;
		params.nBins = 3;
		params.bugDetectStateRatio = 0.01;
		params.cycles = 100;
		params.simulationRepeats = 10000;
		Set<Integer> subset = params.subsetOfBins(3, rand);
		
		// setup components
		SystemGenerator gen = new SystemGenerator();
		SystemModel system = gen.generate(params, rand);
		system.display(System.out);
		System.out.println("targets = " + subset);
		*/
		
	}

	private static void invokeWithSeed(int seed) throws IOException {
		Calendar cal = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat("yyyyMMdd-HHmmss");
		File outputFile = new File(OUTPUT_PATH + "/" + df.format(cal.getTime()) + ".txt");
		outputFile.createNewFile();
		
		try (PrintStream ps = new PrintStream(outputFile)) {
			
			Random rand = new Random(seed);
			List<ExpSetting> settings = generateSettings(rand);
			
			displaySettings(settings);
			
			for (int i = 0; i < settings.size(); i++) {
				ExpSetting setting = settings.get(i);
				System.out.println((i + 1) + "/" + settings.size() + ", " + (100 * (i + 1) / settings.size()) + "%.");
				
				SystemModel system = setting.system;
				system.display(System.out);
				
				ExpParameter params = setting.params;
				InferResult ir = new InferResult();
				
				long timeStart = 0;
				
				Simulator simulator = new Simulator();
				
				timeStart = System.currentTimeMillis();
				List<DataCollector> dcs = simulator.simulateWithVariousCycles(system, params, rand);
				System.out.println("simulation: " + (System.currentTimeMillis() - timeStart) + "ms");
				
				DetectingProbInfer inferrer = new DetectingProbInfer();
				
				timeStart = System.currentTimeMillis();
				inferrer.infer(system, params, dcs, ir);
				System.out.println("prob_infer: " + (System.currentTimeMillis() - timeStart) + "ms");
				
				record(ps, setting, dcs, ir);
				
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private static void record(PrintStream ps, ExpSetting setting, List<DataCollector> dcs, InferResult result) {
		System.out.println("Traces:");
		for (DataCollector dc : dcs) {
			System.out.print(dc.isBugDetected() ? "+" : "-");
			List<State> trace = dc.getTrace();
			for (State s : trace) {
				System.out.print(" " + s.bin.id());
				if (s.bug)
					System.out.print("*");
			}
			System.out.println();
		}
		
		SystemModel system = setting.system;
		
		double[] qn = naiveMethod(system, dcs);
		
		System.out.println("bins = " + system.numOfBins);
		Set<Integer> reachedBins = new HashSet<>();
		int fsize = 0;
		for (DataCollector dc : dcs) {
			if (dc.isBugDetected())
				fsize ++;
			// collect reached bins
			for (Bin b : dc.summarizeReachedBins()) {
				reachedBins.add(b.id());
			}
		}
		System.out.println(String.format("#F=%d\t(%.2f%%)", fsize, fsize * 100.0 / dcs.size()));
		System.out.println(String.format("#P=%d\t(%.2f%%)", (dcs.size() - fsize), (dcs.size() - fsize) * 100.0 / dcs.size()));
		System.out.println(String.format("obj_ori=%f", result.objt));
		System.out.println(String.format("obj_inf=%f", result.obji));
		System.out.println(String.format("%s\t%s\t%s\t%s", "No.", "Ori", "Inf", "Naive"));
		for (int i = 0; i < system.numOfBins; i++) {
			System.out.println(String.format("[%c]%d\t%.4f\t%.4f\t%.4f", 
					(reachedBins.contains(i) ? 'O' : 'X'), 
					i, 
					result.qt[i], 
					result.qi[i], 
					qn[i]));
		}
		// ps.println(line);
	}

	private static double[] naiveMethod(SystemModel system, List<DataCollector> dcs) {
		int[] aef = new int[system.numOfBins];
		int[] aep = new int[system.numOfBins];
		Arrays.fill(aef, 0);
		Arrays.fill(aep, 0);
		for (DataCollector dc : dcs) {
			boolean detects = dc.isBugDetected();
			List<State> trace = dc.getTrace();
			for (State s : trace) {
				if (detects) {
					aef[s.bin.id()] ++;
				} else {
					aep[s.bin.id()] ++;
				}
			}
		}
		double[] q = new double[system.numOfBins];
		for (int i = 0; i < system.numOfBins; i++) {
			if (aef[i] + aep[i] > 0) {
				// Jacacard: aef / (aef + anf + aep) = aef / (totalFailed + aep)
				// q[i] = 1.0 * aef[i] / (totalFailed + aep[i]);
				q[i] = 1.0 * aef[i] / (aef[i] + aep[i]);
			} else {
				q[i] = 0;
			}
		}
		return q;
	}

	private static void displaySettings(List<ExpSetting> settings) {
		for (ExpSetting s : settings) {
			System.out.println(s);
		}
	}

	@SuppressWarnings("unused")
	@SafeVarargs
	private static<T> List<T> mergeList(List<T>... args) {
		List<T> ret = new ArrayList<>();
		for (List<T> a : args) {
			ret.addAll(a);
		}
		return ret;
	}
	
	private static SystemGenerator gen = new SystemGenerator();

	private static List<ExpSetting> buildSetting(
			Random rand,
			List<Integer> nInputPins, 
			List<Integer> nFlipflops, 
			List<Integer> nBins, 
			List<Integer> cycles,
			List<Integer> targetSize,
			List<Integer> simulationRepeats,
			List<Double> maxInitialStateRatio,
			List<Double> maxBugDetectStateRatio,
			int duplicates
			) {
		List<ExpSetting> ret = new ArrayList<>();
		for (int n1 : nInputPins) {
			for (int n2 : nFlipflops) {
				for (int n3 : nBins) {
					for (int n4 : cycles) {
						for (int n5 : targetSize) {
							for (int n6 : simulationRepeats) {
								for (double d1 : maxBugDetectStateRatio) {
									for (double d2 : maxInitialStateRatio) {
										ExpParameter params = new ExpParameter();
										params.nInputPins = n1;
										params.nFlipflops = n2;
										params.nBins = n3;
										params.cycles = n4;
										params.targetSize = n5;
										params.simulationRepeats = n6;
										// pick any in [0, d1)
										params.bugDetectStateRatio = rand.nextDouble() * d1;
										// pick any in [0, d2)
										params.initialStateRatio = rand.nextDouble() * d2;
										if (params.isValid()) {
											for (int i = 0; i < duplicates; i++) {
												SystemModel system = gen.generate(params, rand);
												ExpSetting setting = new ExpSetting();
												setting.params = params;
												setting.system = system;
												setting.targets = params.subsetOfBins(rand);
												ret.add(setting);
											}
										} else {
											System.err.println("Invalid parameter: " + params);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return ret;
	}
	
	private static List<Integer> S(int x) {
		return Collections.singletonList(x);
	}
	
	private static List<Double> S(double x) {
		return Collections.singletonList(x);
	}
	
	private static List<Integer> I(int start, int end, int step) {
		List<Integer> ret = new ArrayList<>();
		int x = start;
		while (x <= end) {
			ret.add(x);
			x += step;
		}
		return ret;
	}
	
	@SuppressWarnings("unused")
	private static List<Integer> I(int start, int end) {
		return I(start, end, 1);
	}
	
	@SuppressWarnings("unused")
	private static List<Double> I(double start, double end, double step) {
		List<Double> ret = new ArrayList<>();
		double x = start;
		while (x <= end) {
			ret.add(x);
			x += step;
		}
		return ret;
	}
	
	private static List<ExpSetting> generateSettings(Random rand) {
		// rand, pin, ff, bins, M, targets, repeats, initRatio, bugRatio
		
		// naive:
		// return buildSetting(rand, S(1), S(2), S(2), S(10), S(0), S(10), S(0.1), S(0.2), 1);
		return buildSetting(rand, S(1), S(3), S(4), S(10), S(0), S(100), S(0.1), S(0.2), 1);
		// return buildSetting(rand, S(2), S(4), S(4), S(10), S(0), S(100), S(0.1), S(0.2), 1);
		// return buildSetting(rand, S(2), S(6), S(12), S(10), S(0), S(800), S(0.1), S(0.1), 1);
		
//		return mergeList(
//				buildSetting(rand, S(1), S(2), S(4), S(3), S(2), S(1000), S(0.01), S(0.25), 1),
//				buildSetting(rand, I(1, 3), I(2, 4), I(4, 20), I(10, 100, 10), I(3, 9, 2), S(1000), S(0.01), S(0.10), 10),
//				buildSetting(rand, I(3, 4), I(6, 8), I(40, 200, 40), S(100), R(rand, 3, 20), S(1000), S(0.01), S(0.05), 10),
//				buildSetting(rand, S(2), S(8), S(80), S(100), S(6), S(1000), S(0.0001), S(0.01), 100),
//				buildSetting(rand, I(2, 3), I(5, 7), I(20, 100, 40), I(100, 200, 100), I(2, 10, 4), S(1000), S(0.01), S(0.01), 100),
//				buildSetting(rand, S(3), S(6), S(20), S(50), S(16), S(1000), S(0.01), S(0.05), 1)
//				);

		// round3: pure random instances
//		List<ExpSetting> ret = new ArrayList<ExpSetting>();
//		for (int i = 0; i < 50000; i++) {
//			ret.addAll(buildSetting(rand, 
//					R(rand, 1, 3),		// pins 
//					R(rand, 2, 8),		// flip-flops 
//					R(rand, 2, 100),	// bins 
//					R(rand, 10, 100),	// M
//					R(rand, 2, 16), 	// targets
//					S(1000), 			// repeats
//					S(0.01), 			// init
//					S(0.25), 			// bug
//					1					// duplicates
//					));
//		}
//		return ret;
		
		// for testing the difference of r1 and r3
//		return mergeList(
//				buildSetting(rand, S(4), S(6), I(1, 16), S(50), I(1, 16), S(1000), I(0.01, 0.10, 0.01), I(0.05, 0.50, 0.05), 10)
//				);
	}

	protected static List<Integer> R(Random rand, int low, int high) {
		List<Integer> ret = new ArrayList<>();
		ret.add(low + rand.nextInt(high - low + 1));
		return ret;
	}

}
