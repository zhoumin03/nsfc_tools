package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Name;

public class ASTUtils {

	public static Name inlineQualifiedNameToName(AST ast, String qn) {
		String[] segs = qn.split("\\.");
		return makeQualifiedName(ast, segs);
	}

	public static Name makeQualifiedName(AST ast, String ...segs) {
		// check
		if (segs.length == 0) {
			throw new IllegalArgumentException("bad quantified name: " + segs);
		} else {
			for (int i = 0; i < segs.length; i++) {
				if (segs[i].length() == 0) {
					throw new IllegalArgumentException("bad quantified name: " + segs);
				}
			}
		}
		// segs.length >= 1
		if (segs.length == 1) {
			return ast.newSimpleName(segs[0]);
		} else {
			// segs.length >= 2
			Name prefix = ast.newSimpleName(segs[0]);
			for (int i = 1; i < segs.length; i++) {
				prefix = ast.newQualifiedName(prefix, ast.newSimpleName(segs[i]));
			}
			return prefix;
		}
	}

	public static String packageNameToPath(String s) {
		return s.replaceAll("\\.", "/");
	}
}
