package cn.edu.tsinghua.thss.randtest.alg.cfg.model;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.Statement;

public class DecisionBlock extends BasicBlock {
	private Expression condition;
	private Statement source;

	public DecisionBlock(Expression condition, Statement source) {
		this();
		setConditionAndItsSource(condition, source);
	}
	
	public DecisionBlock() {
		this.condition = null;
		this.source = null;
	}
	
	@Override
	public Statement sourceBackToASTNode() {
		return source;
	}
	
	public Expression getCondition() {
		return condition;
	}
	
	public Statement getConditionSource() {
		return source;
	}

	public void setConditionAndItsSource(Expression condition, 
			Statement source) {
		this.condition = condition;
		this.source = source;
	}

	@Override
	protected boolean acceptOutEdgeType(Edge edge) {
		return edge.isConditionalBranch();
	}

	/**
	 * 返回成立的分支
	 * @return
	 */
	public BasicBlock getBlockOnTrueBranch() {
		for (Edge edge : getOutEdges()) {
			if (edge.isTrueBranch()) {
				return edge.getDest();
			}
		}
		return null;
	}
	
	/**
	 * 返回不成立的分支
	 * @return
	 */
	public BasicBlock getBlockOnFalseBranch() {
		for (Edge edge : getOutEdges()) {
			if (edge.isFalseBranch()) {
				return edge.getDest();
			}
		}
		return null;
	}

	@Override
	protected String strRepr() {
		StringBuilder sb = new StringBuilder();
		sb.append("DEC: ");
		sb.append(condition.toString());
		return sb.toString();
	}
	
}
