package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;

import java.util.HashSet;
import java.util.Set;

/**
 * 归纳类型，比如 Node ::= (int x; Node next);
 * 归纳类型的 generator 只需要归纳类型本身的名字即可以查询，比如Node
 * 但是生成归纳类型的数据需要用到依赖的生成器，而且归纳类型的生成器是专用的
 * @author aleck
 *
 */
public class InductiveTypeDef extends WrappedTypeDef {
	
	@SuppressWarnings("rawtypes")
	public InductiveTypeDef(Class top, TypeDef ...deps) {
		this.top = top;
		for (TypeDef td : deps) {
			if (td == null) {
				// NULL means refer to my self
				this.deps.add(this);
			} else {
				this.deps.add(td);
			}
		}
	}
	
	@Override
	public int hashCode() {
		return top.hashCode();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof InductiveTypeDef)) {
			return false;
		}
		InductiveTypeDef that = (InductiveTypeDef) o;
		return this.top.equals(that.top);
	}
	
	@Override
	public String toString() {
		Set<TypeDef> covered = new HashSet<TypeDef>();
		covered.add(this);
		return inductiveToString(covered);
	}

	@Override
	protected String shortName() {
		return top.getCanonicalName();
	}
	
	private String inductiveToString(Set<TypeDef> covered) {
		StringBuilder sb = new StringBuilder();
		sb.append(top.getCanonicalName());
		boolean first = true;
		sb.append('(');
		for (TypeDef td : deps) {
			if (first) {
				first = false;
			} else {
				sb.append(',');
			}
			if (td instanceof InductiveTypeDef) {
				if (covered.contains(td)) {
					sb.append(((InductiveTypeDef)td).shortName());
				} else {
					sb.append(td.toString());
					covered.add(td);
				}
			} else {
				sb.append(td.toString());
			}
		}
		sb.append(')');
		return sb.toString();
	}

}
