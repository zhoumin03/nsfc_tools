package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class SecondOrderEquationSolver {
	private static final double LIMIT = 1e-6;
	
	public static class Result {
		public static final byte UNKNOWN		= 0;	// unknown
		public static final byte NONE 			= 1;	// no solution
		public static final byte ANY			= 2;	// any value is solution
		public static final byte ONE			= 3;	// one solution
		public static final byte TWO_IDENTICAL	= 4;	// two identical solution
		public static final byte TWO_DISTINCT	= 5;	// two distinct solution
		
		public final byte type;
		public final double x1;
		public final double x2;
		
		private Result(byte type, double x1, double x2) {
			this.type = type;
			this.x1 = x1;
			this.x2 = x2;
		}
		
		public static Result newUnknown() {
			return new Result(UNKNOWN, 0, 0);
		}
		
		public static Result newNone() {
			return new Result(NONE, 0, 0);
		}
		
		public static Result newAny() {
			return new Result(ANY, 0, 0);
		}
		
		public static Result newOne(double x) {
			return new Result(ONE, x, x);
		}
		
		public static Result newTwoIdentical(double x) {
			return new Result(TWO_DISTINCT, x, x);
		}
		
		public static Result newTwoDistinct(double x1, double x2) {
			return new Result(TWO_IDENTICAL, x1, x2);
		}
		
		/**
		 * relative error <= 1%
		 * @param x
		 * @param y
		 * @return
		 */
		public static boolean similar(double x, double y) {
			double diff = Math.abs(x - y);
			double max = Math.max(Math.abs(x), Math.abs(y));
			// 1. x .=. y .=. 0; 2. otherwise
			return (diff <= 2e-8 && max < 1e-8 || diff < max * 0.01);
		}
		
		public boolean equals(Object o) {
			if (o == null || !(o instanceof Result)) {
				return false;
			} else {
				Result that = (Result) o;
				return (this.type == that.type && similar(this.x1, that.x1) && similar(this.x2, that.x2));
			}
		}
		
		public String strRepr() {
			if (type == UNKNOWN) {
				return "Result.newUnknown()";
			} else if (type == NONE) {
				return "Result.newNone()";
			} else if (type == ANY) {
				return "Result.newAny()";
			} else if (type == ONE) {
				return "Result.newOne(" + x1 + ")";
			} else if (type == TWO_DISTINCT) {
				return "Result.newTwoDistinct(" + x1 + ", " + x2 + ")";
			} else if (type == TWO_IDENTICAL) {
				return "Result.newTwoIdentical(" + x1 + ")";
			} else {
				throw new RuntimeException("unknown result type: " + this);
			}
		}
	}

	public static Result solve(double a, double b, double c) {
		RT.startInvocation(8984220858827794432L);
		RT.track(1);
		if (((RT.b(0)) && (RT.lt(0, Math.abs(a), LIMIT))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			// a == 0
			if (((RT.b(1)) && (RT.lt(0, Math.abs(b), LIMIT))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(5);
				// b == 0;
				if (((RT.b(3)) && (RT.lt(0, Math.abs(c), LIMIT))) && (RT.e(3))) {
					RT.pd(3);
					RT.track(9);
					// c == 0;
					// any real value is a solution
					return Result.newAny();
				} else {
					RT.nd(3);
					RT.track(10);
					// impossible
					return Result.newNone();
				}
			} else {
				RT.nd(1);
				RT.track(6);
				return Result.newOne(c / b);
			}
		} else {
			RT.nd(0);
			RT.track(2);
			double delta = b * b - 4 * a * c;
			RT.track(4);
			if (((RT.b(2)) && (RT.gt(0, delta, LIMIT))) && (RT.e(2))) {
				RT.pd(2);
				RT.track(8);
				return Result.newTwoDistinct(
						(-b - Math.sqrt(delta)) / (2 * a), 
						(-b + Math.sqrt(delta)) / (2 * a));
			} else {
				RT.nd(2);
				RT.track(7);
				if (((RT.b(4)) && (RT.lt(0, delta, -LIMIT))) && (RT.e(4))) {
					RT.pd(4);
					RT.track(12);
					return Result.newNone();
				} else {
					RT.nd(4);
					RT.track(13);
					return Result.newTwoIdentical(-b / (2 * a));
				}
			}
		}
	}
}
