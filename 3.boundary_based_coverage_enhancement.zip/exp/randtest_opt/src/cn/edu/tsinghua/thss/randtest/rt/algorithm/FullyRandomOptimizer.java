package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;


public class FullyRandomOptimizer extends AbstractOptimizer {

	private OptimizerLogger logger;
	
	public FullyRandomOptimizer(Category category, Evaluator evaluator, ProblemWrapper wrapper, OptimizerLogger logger) {
		super(category, evaluator, wrapper);
		this.logger = logger;
	}
	
	@Override
	public void execute(OptimizeParameter parameter, ProblemWrapper wrapper) {
		int iteration = 0;
		// long timeToExit = System.currentTimeMillis() + maxRunTime;
		clockStart();
		
		while (tm.remainsToBeCovered()) {
			if (iteration >= parameter.maxIteration) {
				break;
			}
			
			Input input = InputModifier.generateByRandom(wrapper.getFormalParameter());

			// System.out.println("#" + iteration + " remaining " + numOfRemainingTargets());
			// System.out.println(input.toString());
			
			// invoke the program in a safe way
			iteration ++;
			evaluate(input);
		}
		
		logger.logPerformance(
				tm.numOfAllTargets(), 
				tm.numOfCoveredTargets(), 
				tm.numOfAbandonedTargets(), 
				iteration, 
				currentTimeConsumed()
				);
		
		if (tm.allTargetCovered()) {
			System.out.println("all target covered in " + iteration + " iterations.");
		} else {
			System.out.println("stop after " + iteration + " iterations.");
			System.out.println("covered=" + tm.numOfCoveredTargets() + ", abandon=" + tm.numOfAbandonedTargets());
		}
	}

}
