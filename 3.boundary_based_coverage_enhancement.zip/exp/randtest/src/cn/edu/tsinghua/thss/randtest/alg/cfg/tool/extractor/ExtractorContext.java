package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor;

import org.eclipse.jdt.core.dom.AST;

/**
 * Context used in Extracting CFG
 * @author aleck
 *
 */
public class ExtractorContext {
	private AST ast;
	private JumpContext jump;
	
	public ExtractorContext(AST ast, JumpContext jump) {
		this.ast = ast;
		this.jump = jump;
	}

	public AST getAst() {
		return ast;
	}
	
	public void setAst(AST ast) {
		this.ast = ast;
	}
	
	public JumpContext getJump() {
		return jump;
	}
	
	public void setJump(JumpContext jump) {
		this.jump = jump;
	}
	
}
