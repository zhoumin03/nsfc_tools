package cn.edu.tsinghua.thss.randtest.rt.variation;

import java.util.ArrayList;
import java.util.List;

import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.TypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.WrappedTypeDef;

/**
 * 用于给DependentType和InductiveType作为基础Generator的类
 * @author aleck
 *
 * @param <T>
 */
public abstract class AbstractWrappedGenerator<T> 
		extends AbstractGenerator<T> implements WrappedGenerator<T> {
	@SuppressWarnings("rawtypes")
	private List<Generator> depgens;
	
	@SuppressWarnings("rawtypes")
	public void setDepdentGenerators(Generator ...gens) {
		for (Generator g : gens) {
			depgens.add(g);
		}
	}
	
	@SuppressWarnings("rawtypes")
	public Generator getDependentGenerator(int idx) {
		return depgens.get(idx);
	}

	@SuppressWarnings("rawtypes")
	public void refineDependentGenerators(WrappedTypeDef wtd) {
		if (depgens == null) {
			depgens = new ArrayList<Generator>();
			for (TypeDef dtd : wtd.getDependencies()) {
				depgens.add(dtd.findGenerator());
			}
		}
	}

}
