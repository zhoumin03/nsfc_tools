package algorithm.test;

import junit.framework.TestCase;
import algorithm.Newton;

public class NewtonTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//<$c>
	public void test$$() {
		double x = Newton.sqrt($0D);
		double y = ($_);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
}