package algorithm.test;

import junit.framework.TestCase;
import algorithm.TaxCalc;

public class TaxCalcTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//<$c>
	public void test$$() {
		assertEquals(($_), TaxCalc.tax($0D));
	}
	//<<case-end>>
}