package cov.exp.experiment;

import java.io.IOException;

public class ScalabilityRunAll {

	public static void main(String[] args) throws IOException {
		Scalability1.main(args);
		Scalability2.main(args);
		Scalability3.main(args);
	}

}
