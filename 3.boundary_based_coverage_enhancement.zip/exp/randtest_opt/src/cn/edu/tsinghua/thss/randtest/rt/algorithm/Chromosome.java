package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.util.Comparator;

import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

/**
 * 一个染色体
 * @author aleck
 *
 */
public class Chromosome implements Comparable<Chromosome> {
	// Chromosome 的比较器
	public static final Comparator<Chromosome> ASCENDING_CHROMOSOME_COMPARATOR = new Comparator<Chromosome>() {
		@Override
		public int compare(Chromosome c1, Chromosome c2) {
			return Double.compare(c1.fitness, c2.fitness);
		}
	};
	public static final Comparator<Chromosome> DESCENDING_CHROMOSOME_COMPARATOR = new Comparator<Chromosome>() {
		@Override
		public int compare(Chromosome c1, Chromosome c2) {
			return Double.compare(c2.fitness, c1.fitness);
		}
	};

	public Input input;
	public Double fitness;

	public Chromosome() {
	}

	public Chromosome(Input input, double fitness) {
		this.input = input;
		this.fitness = fitness;
	}
	
	/**
	 * Deep copy
	 * @return
	 */
	public Chromosome copy() {
		Chromosome that = new Chromosome();
		that.fitness = this.fitness;
		that.input = InputModifier.copy(this.input);
		return that;
	}

	@Override
	public int compareTo(Chromosome that) {
		if (this.fitness > that.fitness) {
			return -1;
		} else if (this.fitness < that.fitness) {
			return 1;
		} else {
			return 0;
		}
	}
	
	@Override
	public String toString() {
		return "{(" + fitness + "), " + input.toString() + "}";
	}
	
}

