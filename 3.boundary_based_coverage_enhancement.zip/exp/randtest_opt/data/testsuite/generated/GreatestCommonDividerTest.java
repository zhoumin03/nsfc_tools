package algorithm.test;

import junit.framework.TestCase;
import algorithm.GreatestCommonDivider;

public class GreatestCommonDividerTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T8_11, T17_19, T19_20, T4_8, T14_16, T19_21, T23_17, T17_18, T12_13, T2_4]
	public void test00() {
		assertEquals((2L), GreatestCommonDivider.gcd(-10L, -60986833153869008L));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T8_11, T17_19, T19_20, T14_16, T19_21, T23_17, T17_18, T2_4, T4_7, T12_14]
	public void test01() {
		assertEquals((3L), GreatestCommonDivider.gcd(10721565L, -72576048L));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T8_11, T17_19, T19_20, T4_8, T14_16, T19_21, T23_17, T17_18, T12_13, T2_4]
	public void test02() {
		assertEquals((1048576L), GreatestCommonDivider.gcd(-9223372036854775808L, -1041709710969929728L));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T8_10, T17_19, T19_20, T14_16, T23_17, T17_18, T2_4, T4_7, T12_14]
	public void test03() {
		assertEquals((1L), GreatestCommonDivider.gcd(7111175661374L, 1L));
	}
	//<<case-end>>
}
