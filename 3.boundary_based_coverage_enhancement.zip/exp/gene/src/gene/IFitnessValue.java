package gene;

public interface IFitnessValue extends Comparable<IFitnessValue> {
	public double getDoubleValue();
}
