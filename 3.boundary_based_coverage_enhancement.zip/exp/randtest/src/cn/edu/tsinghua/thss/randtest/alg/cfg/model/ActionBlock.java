package cn.edu.tsinghua.thss.randtest.alg.cfg.model;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTNode;

public class ActionBlock extends BasicBlock {
	/**
	 * Actually, accepts only Statement and Expression
	 */
	private List<ASTNode> statements;
	
	public ActionBlock() {
		super();
		this.statements = new ArrayList<ASTNode>();
	}
	
	public void addStatement(ASTNode stat) {
		statements.add(stat);
	}
	
	public List<ASTNode> getStatements() {
		return statements;
	}

	public boolean isEmpty() {
		return statements.size() == 0;
	}

	@Override
	public ASTNode sourceBackToASTNode() {
		return statements.get(0);
	}

	@Override
	protected boolean acceptOutEdgeType(Edge edge) {
		return edge.isNonConditionalBranch();
	}

	@Override
	protected String strRepr() {
		StringBuilder sb = new StringBuilder();
		sb.append("ACT: ");
		for (ASTNode node : statements) {
			sb.append(node.toString());
		}
		return sb.toString();
	}
}
