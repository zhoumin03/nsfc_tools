package cn.edu.tsinghua.thss.randtest.cases;


public class ArrayIsMonotonic {
    private static final byte INCREASING = 1;
	private static final byte DECREASING = 2;

	/**
     * Check that an array is monotonically increasing or decreasing.
     *
     * @param val Values.
     * @param dir Ordering direction.
     * @param strict Whether the order should be strict.
     * @return {@code true} if sorted, {@code false} otherwise.
     */
    public static boolean isMonotonic(Comparable[] val,
                                      byte dir,
                                      boolean strict) {
        Comparable previous = val[0];
        final int max = val.length;
        for (int i = 1; i < max; i++) {
            final int comp;
            if (dir == INCREASING) {
                comp = previous.compareTo(val[i]);
                if (strict) {
                    if (comp >= 0) {
                        return false;
                    }
                } else {
                    if (comp > 0) {
                        return false;
                    }
                }
            } else if (dir == DECREASING) {
                comp = val[i].compareTo(previous);
                if (strict) {
                    if (comp >= 0) {
                        return false;
                    }
                } else {
                    if (comp > 0) {
                       return false;
                    }
                }
            } else {
            	throw new RuntimeException("impossible");
            }

            previous = val[i];
        }
        return true;
    }


}
