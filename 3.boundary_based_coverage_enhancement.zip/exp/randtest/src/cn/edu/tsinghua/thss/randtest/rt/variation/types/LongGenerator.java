package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;


public class LongGenerator extends AbstractGenerator<Long> {
	
	public void registerSpecials() {
		registerSpecial((long) 0);
		registerSpecial((long) 1);
		registerSpecial((long) -1);
		registerSpecial((long) 10);
		registerSpecial((long) -10);
		registerSpecial(Long.MAX_VALUE);
		registerSpecial(Long.MIN_VALUE);
	}
	
	@Override
	public Long nextRandom() {
		return rand.nextLong();
	}

	@Override
	public Long nextBiasedRandom() {
		if (rand.nextBoolean()) {
			return logBiasedLong(Long.MAX_VALUE);
		} else {
			// NOTE: use MAX_VALUE because -MAX_VALUE exceed long
			return -logBiasedLong(Long.MAX_VALUE);
		}
	}

	@Override
	public Long nextNeighbour(Long current, double scale) {
		if (current == Long.MIN_VALUE) {
			return (current + 1);
		} else if (current == Long.MAX_VALUE) {
			return (current - 1);
		} else {
			return (rand.nextBoolean() ? current + 1 : current - 1);
		}
	}

	@Override
	public Long copy(Long origin) {
		return Long.valueOf(origin.longValue());
	}

	@Override
	public Long[] allNeighbours(Long current, double scale) {
		if (current == Long.MIN_VALUE) {
			return new Long[] {(current + 1)};
		} else if (current == Long.MAX_VALUE) {
			return new Long[] {(current - 1)};
		} else {
			return new Long[] {current - 1, current + 1};
		}
	}
}
