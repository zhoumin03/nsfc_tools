package cov.exp.experiment;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;

import cov.exp.algorithm.CoverageAnalyzer;
import cov.exp.algorithm.ExpParameter;
import cov.exp.algorithm.SystemGenerator;
import cov.exp.model.CoverageEstimation;
import cov.exp.model.State;
import cov.exp.model.SystemModel;

/**
 * Ч�ʲ���
 * 
 * 1. �̶�n,m, ����b����֤2^m >> b��
 * 2. �̶�n,b, ����m����֤2^m >> b��
 * 
 * @author aleck
 *
 */
public abstract class ScalabilityAbstract {
	protected static final int ANALYSIS_REPEATITION	= 1;
	protected static final String BASE_OUTPUT_PATH 	= "./data/results/scalability";

	public static class ExpSetting {
		public ExpParameter params;
		public SystemModel system;
		public Set<Integer> targets;
		
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("[");
			sb.append("n=" + params.nInputPins + ", ");
			sb.append("m=" + params.nFlipflops + ", ");
			sb.append("b=" + params.nBins + ", ");
			sb.append("t=" + params.targetSize + ", ");
			sb.append("M=" + params.cycles + ", ");
			sb.append("R=" + params.simulationRepeats + ", ");
			sb.append("init=" + params.initialStateRatio + ", ");
			sb.append("#init=" + system.initials.size() + ", ");
			sb.append("bug=" + params.bugDetectStateRatio);
			sb.append("]");
			return sb.toString();
		}
	}

	/**
	 * ����������� 
	 * @param rand
	 * @return
	 */
	protected abstract List<ExpSetting> generateSettings(Random rand);
	
	protected abstract String getOutputPath();

	protected void invokeWithSeed(int seed) throws IOException {
		Calendar cal = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat("yyyyMMdd-HHmmss");
		File outputFile = new File(getOutputPath() + "/" + df.format(cal.getTime()) + ".txt");
		ensureFile(outputFile);
		
		try (PrintStream ps = new PrintStream(outputFile)) {
			
			Random rand = new Random(seed);
			List<ExpSetting> settings = generateSettings(rand);
			
//			List<ExpSetting> ns = new ArrayList<ExpSetting>();
//			ns.add(settings.get(29));
//			settings = ns;
			
			displaySettings(settings);
			System.out.println("free  =" + Runtime.getRuntime().freeMemory() / 1024 / 1024);
			System.out.println("total =" + Runtime.getRuntime().totalMemory() / 1024 / 1024);
			System.out.println("max   =" + Runtime.getRuntime().maxMemory() / 1024 / 1024);
			
			for (int i = 0; i < settings.size(); i++) {
				ExpSetting setting = settings.get(i);
				System.out.println((i + 1) + "/" + settings.size() + ", " + (100 * (i + 1) / settings.size()) + "%.");
				
				SystemModel system = setting.system;
				ExpParameter params = setting.params;
				Set<Integer> targets = setting.targets;
				
				// analyze
				long timeUsed = 0;
				for (int j = 0; j < ANALYSIS_REPEATITION; j++) {
					// trigger a garbage collection
					System.gc();
					
					CoverageAnalyzer analyzer = new CoverageAnalyzer(params, system);
					// ignore the result
					CoverageEstimation ce = analyzer.analyze(params.cycles, targets, CoverageAnalyzer.MODE_CASE_1);
					timeUsed += ce.timeR1;
				}
				
				record(ps, setting, timeUsed / ANALYSIS_REPEATITION);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private static void ensureFile(File file) throws IOException {
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		if (!file.exists())
			file.createNewFile();
	}

	private static void record(PrintStream ps, ExpSetting setting, long timeUsed) {
		ExpParameter params = setting.params;
		SystemModel system = setting.system;
		Set<Integer> targets = setting.targets;
		int bugStates = 0;
		for (State s : system.states) {
			if (s.bug)
				bugStates ++;
		}
		String line = 
				params.nInputPins + " " +
				system.numOfInputPatterns + " " + 
				params.nFlipflops + " " +
				system.numOfStates + " " +
				system.numOfBins + " " + 
				system.initials.size() + " " +
				bugStates + " " +
				targets.size() + " " +
				params.cycles + " " +
				timeUsed;
		System.out.println(line);
		ps.println(line);
	}

	private static void displaySettings(List<ExpSetting> settings) {
		for (ExpSetting s : settings) {
			System.out.println(s);
		}
	}

	@SuppressWarnings("unused")
	@SafeVarargs
	private static<T> List<T> mergeList(List<T>... args) {
		List<T> ret = new ArrayList<>();
		for (List<T> a : args) {
			ret.addAll(a);
		}
		return ret;
	}
	
	private static SystemGenerator gen = new SystemGenerator();

	protected static List<ExpSetting> buildSetting(
			Random rand,
			List<Integer> nInputPins, 
			List<Integer> nFlipflops, 
			List<Integer> nBins, 
			List<Integer> cycles,
			List<Integer> targetSize,
			List<Integer> simulationRepeats,
			List<Double> maxInitialStateRatio,
			List<Double> maxBugDetectStateRatio,
			int duplicates
			) {
		List<ExpSetting> ret = new ArrayList<>();
		for (int n1 : nInputPins) {
			for (int n2 : nFlipflops) {
				for (int n3 : nBins) {
					for (int n4 : cycles) {
						for (int n5 : targetSize) {
							for (int n6 : simulationRepeats) {
								for (double d1 : maxBugDetectStateRatio) {
									for (double d2 : maxInitialStateRatio) {
										ExpParameter params = new ExpParameter();
										params.nInputPins = n1;
										params.nFlipflops = n2;
										params.nBins = n3;
										params.cycles = n4;
										params.targetSize = n5;
										params.simulationRepeats = n6;
										// pick any in [0, d1)
										params.bugDetectStateRatio = rand.nextDouble() * d1;
										// pick any in [0, d2)
										params.initialStateRatio = rand.nextDouble() * d2;
										if (params.isValid()) {
											for (int i = 0; i < duplicates; i++) {
												SystemModel system = gen.generate(params, rand);
												ExpSetting setting = new ExpSetting();
												setting.params = params;
												setting.system = system;
												setting.targets = params.subsetOfBins(rand);
												ret.add(setting);
											}
										} else {
											System.err.println("Invalid parameter: " + params);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return ret;
	}
	
	protected static List<Integer> S(int x) {
		return Collections.singletonList(x);
	}
	
	protected static List<Double> S(double x) {
		return Collections.singletonList(x);
	}
	
	protected static List<Integer> I(int start, int end, int step) {
		List<Integer> ret = new ArrayList<>();
		int x = start;
		while (x <= end) {
			ret.add(x);
			x += step;
		}
		return ret;
	}
	
	protected static List<Integer> I(int start, int end) {
		return I(start, end, 1);
	}
	
	protected static List<Double> I(double start, double end, double step) {
		List<Double> ret = new ArrayList<>();
		double x = start;
		while (x <= end) {
			ret.add(x);
			x += step;
		}
		return ret;
	}
	
	protected static List<Integer> R(Random rand, int low, int high) {
		List<Integer> ret = new ArrayList<>();
		ret.add(low + rand.nextInt(high - low + 1));
		return ret;
	}

}
