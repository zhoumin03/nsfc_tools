package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jdt.core.dom.Expression;

/**
 * 用于解析条件表达式的时候，对公式ID和Expression做绑定。
 * @author aleck
 *
 */
public class FormulaBinding {
	private Map<Integer, Expression> binding = new HashMap<Integer, Expression>();
	private int id = 0;
	
	public int bindNext(Expression e) {
		int ret = id;
		binding.put(id, e);
		id++;
		return ret;
	}
	
	public Expression get(int id) {
		return binding.get(id);
	}
	
	public int size() {
		return id;
	}
}
