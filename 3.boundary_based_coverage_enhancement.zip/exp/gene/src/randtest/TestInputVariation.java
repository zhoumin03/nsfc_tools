package randtest;

import gene.ISolution;
import gene.IVariationFunction;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestInputVariation implements IVariationFunction {
	private static final int MAX_DELTA = 10000;
	private static final double LIMIT = 0.03;
	
	private Random rand;
	
	public TestInputVariation(int seed) {
		rand = new Random();
		rand.setSeed(seed);
	}

	@Override
	public List<ISolution> evolve(ISolution sol, double temperature) {
		TestInput ti = (TestInput) sol;
		TestInput nti = new TestInput();
		
//		nti.a = keep(temperature) ? ti.a : delta(ti.a, temperature);
//		nti.b = keep(temperature) ? ti.b : delta(ti.b, temperature);
//		nti.c = keep(temperature) ? ti.c : delta(ti.c, temperature);

//		nti.a = keep(temperature) ? ti.a : move(ti.a, temperature);
//		nti.b = keep(temperature) ? ti.b : move(ti.b, temperature);
//		nti.c = keep(temperature) ? ti.c : move(ti.c, temperature);
		
		
		int direction = rand.nextInt(2) == 0 ? 1 : -1;
		
		int d1 = (int) (MAX_DELTA * temperature * rand.nextDouble());
		int d2 = (int) (MAX_DELTA * temperature * rand.nextDouble());
		int d3 = (int) (MAX_DELTA * temperature * rand.nextDouble());

		d1 = max(d1, 1);
		d2 = max(d2, 1);
		d3 = max(d3, 1);

		nti.a = ti.a;
		nti.b = ti.b;
		nti.c = ti.c;
		
//		int choice = rand.nextInt(3);
//		if (choice == 0) {
//			nti.a = ti.a + d1 * direction;
//		} else if (choice == 1) {
//			nti.b = ti.b + d2 * direction;
//		} else {
//			nti.c = ti.c + d3 * direction;
//		}
		
		nti.a = keepIt(temperature) ? ti.a : ti.a + d1 * direction;
		nti.b = keepIt(temperature) ? ti.b : ti.b + d2 * direction;
		nti.c = keepIt(temperature) ? ti.c : ti.c + d3 * direction;
		
		List<ISolution> ret = new ArrayList<ISolution>();
		ret.add(nti);
		
		return ret;
	}

	private boolean keepIt(double temperature) {
		return false;
	}

	private int max(int a, int b) {
		return (a > b) ? a : b;
	}


}
