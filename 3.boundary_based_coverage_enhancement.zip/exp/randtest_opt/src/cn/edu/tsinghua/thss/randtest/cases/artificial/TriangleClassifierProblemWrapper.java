package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.TriangleClassifier;
import cn.edu.tsinghua.thss.randtest.cases.TriangleClassifierRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class TriangleClassifierProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Integer.class),
				BASIC(Integer.class),
				BASIC(Integer.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new TriangleClassifierRuntimeAssist();
	}

	@Override
	public Object invoke(Input input) {
		return TriangleClassifier.classify(
				(Integer) input.data[0], 
				(Integer) input.data[1], 
				(Integer) input.data[2]);
	}

}
