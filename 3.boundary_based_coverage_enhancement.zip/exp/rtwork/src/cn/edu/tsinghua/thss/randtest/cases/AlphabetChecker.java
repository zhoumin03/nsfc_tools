package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class AlphabetChecker {
	public static boolean isAlphabet(char c) {
		RT.startInvocation(5052623946371851264L);
		RT.track(1);
		boolean isLower;
		boolean isUpper;
		RT.track(2);
		if (((RT.b(0)) && (((RT.le(0, 'a', c)) && (RT.le(1, c, 'z')))))
				&& (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			isLower = true;
		} else {
			RT.nd(0);
			RT.track(4);
			isLower = false;
		}
		RT.track(5);
		if (((RT.b(1)) && (((RT.le(0, 'A', c)) && (RT.le(1, c, 'Z')))))
				&& (RT.e(1))) {
			RT.pd(1);
			RT.track(6);
			isUpper = true;
		} else {
			RT.nd(1);
			RT.track(7);
			isUpper = false;
		}
		RT.track(8);
		return isLower || isUpper;
	}
}
