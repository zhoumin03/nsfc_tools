package cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper;

import java.lang.reflect.Array;

import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.util.ClassUtils;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Invoker;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.BasicTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.DependentTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.InductiveTypeDef;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.TypeDef;

/**
 * 对问题的封装
 * @author aleck
 *
 */
public abstract class ProblemWrapper implements Invoker {
	
	protected static final TypeDef SELF = null;
	
	@SuppressWarnings("rawtypes")
	protected static TypeDef BASIC(Class klass) {
		return new BasicTypeDef(klass);
	}
	
	@SuppressWarnings("rawtypes")
	protected static TypeDef DEP(Class top, TypeDef ...deps) {
		return new DependentTypeDef(top, deps);
	}
	
	@SuppressWarnings("rawtypes")
	protected static TypeDef IND(Class top, TypeDef ...deps) {
		return new InductiveTypeDef(top, deps);
	}

	/**
	 * 用于将Object[]的数组转换成T[]，不做类型检查
	 * @param clazz
	 * @param array
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static<T> T[] toArray(Class<T> clazz, Object[] array) {
		T[] ret = (T[]) Array.newInstance(clazz, array.length);
		for (int i = 0; i < array.length; i++) {
			ret[i] = (T) array[i];
		}
		return ret;
	}
	
	public static int[] toIntArray(Integer[] array) {
		int[] ret = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			ret[i] = array[i];
		}
		return ret;
	}

	public static byte[] toByteArray(Byte[] array) {
		byte[] ret = new byte[array.length];
		for (int i = 0; i < array.length; i++) {
			ret[i] = array[i];
		}
		return ret;
	}
	
	public static long[] toLongArray(Integer[] array) {
		long[] ret = new long[array.length];
		for (int i = 0; i < array.length; i++) {
			ret[i] = array[i];
		}
		return ret;
	}

	private FormalParameter localFormalParameter = null;
	private RuntimeAssist localRuntimeAssist = null;
	
	/**
	 * 用于定义特定的类型生成器
	 */
	public abstract void registerTypeDefs();
	
	/**
	 * 调用
	 */
	@Override
	public abstract Object invoke(Input input);
	
	@Override
	public String invokeStr(Input input) {
		Object x = invoke(input);
		return ClassUtils.strRepr(x);
	}
	
	/**
	 * 得到形参
	 * @return
	 */
	protected abstract FormalParameter createFormalParameter();

	/**
	 * 保证不会重复构造
	 * @return
	 */
	public FormalParameter getFormalParameter() {
		if (localFormalParameter == null) {
			localFormalParameter = createFormalParameter();
		}
		return localFormalParameter;
	}
	
	/**
	 * 得到RuntimeAssist
	 * @return
	 */
	protected abstract RuntimeAssist createRuntimeAssist();

	/**
	 * 保证不会重复构造
	 * @return
	 */
	public RuntimeAssist getRuntimeAssist() {
		if (localRuntimeAssist == null) {
			localRuntimeAssist = createRuntimeAssist();
		}
		return localRuntimeAssist;
	}
	
	/**
	 * 得到Invoker
	 * @return
	 */
	public Invoker getInvoker() {
		return this;
	}
}
