package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.StringIsNumber;
import cn.edu.tsinghua.thss.randtest.cases.StringIsNumberRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class StringIsNumberProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(String.class)
				);
		return fp;
	}

	@Override
	public Object invoke(Input input) {
		return StringIsNumber.isNumber((String) input.data[0]);
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new StringIsNumberRuntimeAssist();
	}

}
