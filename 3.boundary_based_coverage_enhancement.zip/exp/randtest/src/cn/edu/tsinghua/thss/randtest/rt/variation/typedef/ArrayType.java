package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;

/**
 * 用于DependentType时使用
 * @author aleck
 *
 */
public final class ArrayType {
}
