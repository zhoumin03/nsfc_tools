package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class QuadraticForm {
    public static class QuadraticType {
        public int value;

        public QuadraticType() { }
        
        public QuadraticType(int value) { 
        	this.value = value;
        }

        public static final int Universe = -1;
        public static final int Empty = 0;
        public static final int Degenerate = 1;
        
        public static final int Ellipse = 2;
        public static final int Parabola = 4;
        public static final int Hyperbola = 8;
        
        public static final int PointEllipse = Ellipse | Degenerate;
        public static final int ParallelLines = Parabola | Degenerate;
        public static final int IntersectedLines = Hyperbola | Degenerate;

        public static final int Line = Degenerate | 16;
        
        public static final int Circle = Ellipse | 32;
        public static final int RectangularHyperbola = Hyperbola | 64;
    };

    public static int getGeometryType(double A, double B, double C, double D, double E, double F) {
        RT.startInvocation(3288252843821642752L);
		RT.track(1);
		//B/4(ED-BF)
        if (((RT.b(0)) && (((((RT.eq(0, A, 0)) && (RT.eq(1, B, 0)))) && (RT.eq(2,
				C, 0))))) && (RT.e(0)))
        {
            RT.pd(0);
			RT.track(2);
			if (((RT.b(1)) && (((RT.eq(0, D, 0)) && (RT.eq(1, E, 0)))))
					&& (RT.e(1))) {
				RT.pd(1);
				RT.track(4);
				if (((RT.b(2)) && (RT.eq(0, F, 0))) && (RT.e(2))) {
					RT.pd(2);
					RT.track(7);
					return QuadraticType.Universe;
				} else {
					RT.nd(2);
					RT.track(8);
					return QuadraticType.Empty;
				}
			} else {
				RT.nd(1);
				RT.track(5);
				return QuadraticType.Line;
			}
        }

        RT.nd(0);
		RT.track(3);
		// now, A != 0 || B != 0 || C != 0
        double delta = (A * C - B * B / (double)(4)) * F + B * E * D / (double)(4) 
                            - C * D * D / (double)(4) - A * E * E / (double)(4);
        double d = B * B - A * C * (double)(4);
        RT.track(6);
		if (((RT.b(3)) && (RT.eq(0, delta, 0))) && (RT.e(3)))
        {
            RT.pd(3);
			RT.track(10);
			// degenerate cases
            if (((RT.b(4)) && (RT.lt(0, d, 0))) && (RT.e(4))) {
				RT.pd(4);
				RT.track(12);
				return QuadraticType.PointEllipse;
			} else {
				RT.nd(4);
				RT.track(13);
				if (((RT.b(6)) && (RT.gt(0, d, 0))) && (RT.e(6))) {
					RT.pd(6);
					RT.track(16);
					return QuadraticType.IntersectedLines;
				} else {
					RT.nd(6);
					RT.track(17);
					return QuadraticType.ParallelLines;
				}
			}
        }

        RT.nd(3);
		RT.track(11);
		// non-degenerate cases
        if (((RT.b(5)) && (RT.lt(0, d, 0))) && (RT.e(5)))
        {
            RT.pd(5);
			RT.track(14);
			if (((RT.b(7)) && (RT.gt(0, C * delta, 0))) && (RT.e(7))) {
				RT.pd(7);
				RT.track(18);
				return QuadraticType.Empty;
			} else {
				RT.nd(7);
				RT.track(19);
				if (((RT.b(9)) && (((RT.eq(0, B, 0)) && (RT.eq(1, A - C, 0)))))
						&& (RT.e(9))) {
					RT.pd(9);
					RT.track(22);
					return QuadraticType.Circle;
				} else {
					RT.nd(9);
					RT.track(23);
					return QuadraticType.Ellipse;
				}
			}
        }
        RT.nd(5);
		RT.track(15);
		if (((RT.b(8)) && (RT.eq(0, d, 0))) && (RT.e(8)))
        {
            RT.pd(8);
			RT.track(20);
			return QuadraticType.Parabola;
        }
        RT.nd(8);
		RT.track(21);
		// d > 0
        if (((RT.b(10)) && (RT.eq(0, A + C, 0))) && (RT.e(10))) {
			RT.pd(10);
			RT.track(24);
			return QuadraticType.RectangularHyperbola;
		} else {
			RT.nd(10);
			RT.track(25);
			return QuadraticType.Hyperbola;
		}
    }
}

