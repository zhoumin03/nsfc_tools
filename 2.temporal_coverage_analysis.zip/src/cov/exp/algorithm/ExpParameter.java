package cov.exp.algorithm;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Parameters
 * @author aleck
 *
 */
public class ExpParameter {
	// the number of flip-flops
	public int nFlipflops;
	// the number of input pins;
	public int nInputPins;
	// the number of bins
	public int nBins;
	// cycles of testing
	public int cycles;
	// repetition times of the simulation
	public int simulationRepeats;
	// number of target bins
	public int targetSize;
	// the ratio of initial states
	public double initialStateRatio;
	// the ratio of bug-detect states
	public double bugDetectStateRatio;
	
	/**
	 * Randomly choose a subset of bins, used for case 2 and 3.
	 * @param size
	 * @param rand
	 * @return
	 */
	public Set<Integer> subsetOfBins(Random rand) {
		int size = targetSize;
		if (size < 0 || size > nBins) {
			throw new IllegalArgumentException("Invalid size: " + size);
		}
		int[] pending = new int[nBins];
		for (int i = 0; i < nBins; i++) {
			pending[i] = i;
		}
		Set<Integer> ret = new HashSet<Integer>();
		for (int i = 0; i < size; i++) {
			int idx = rand.nextInt(nBins - i);
			ret.add(pending[idx]);
			pending[idx] = pending[nBins - i - 1];
		}
		return ret;
	}

	/**
	 * Check if a parameter is valid
	 * @return
	 */
	public boolean isValid() {
		boolean valid = true;
		valid &= (0 <= nInputPins && nInputPins <= 20);
		valid &= (0 <= nFlipflops && nFlipflops <= 20);
		valid &= (nInputPins + nFlipflops <= 24);
		valid &= (0 <= nBins && nBins <= 20000);
		valid &= (Math.pow(2, nFlipflops) >= nBins);	// #states <= #bins
		valid &= (0 <= cycles && cycles <= 1000000);
		// valid &= (100 <= simulationRepeats);
		valid &= (0 <= targetSize && targetSize <= nBins);
		return valid;
	}
}
