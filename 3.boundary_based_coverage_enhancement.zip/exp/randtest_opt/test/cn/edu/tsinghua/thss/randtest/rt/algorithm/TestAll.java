package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TestAll {
	private static final DateFormat df = new SimpleDateFormat("yyyyMMdd_HH:mm:ss");
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		long start = System.currentTimeMillis();
		FullyRandomOptimizerTest.main(null);
		MemeticOptimizerTest.main(null);
		System.out.println("finished at " + df.format(Calendar.getInstance().getTime()));
		System.out.println("time consumed: " + ((System.currentTimeMillis() - start) / 1000) + "s");
	}
}
