package algorithm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Visulizer extends JFrame implements ActionListener {
	
	private JPanel content;
	private JButton btnDraw;
	private BallUtils ballUtils;
	
	public Visulizer() {
		btnDraw = new JButton("draw");
		content = new JPanel();
		
		btnDraw.addActionListener(this);
		
		Container container = this.getContentPane();
		container.setLayout(new BorderLayout());
		container.add(btnDraw, BorderLayout.SOUTH);
		container.add(content, BorderLayout.CENTER);
		
		this.setSize(800, 600);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		Visulizer visulizer = new Visulizer();
		visulizer.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (ballUtils == null) {
			ballUtils = new BallUtils(2);
		}
		clearScreen();
		drawAxis();
		drawRandomPoints();
	}

	private void drawRandomPoints() {
		Graphics graphics = content.getGraphics();
		graphics.setColor(Color.GREEN);
		int width = content.getWidth();
		int height = content.getHeight();
		int radius = (width > height) ? height : width;
		radius = (int) (radius * 0.35);
		
		final int MAX_RAND_POINT = 5000;
		for (int i = 0; i < MAX_RAND_POINT; i++) {
			double[] point = ballUtils.randomPoint(1);
			int x = (int) (width / 2 + point[0] * radius);
			int y = (int) (height / 2 + point[1] * radius);
			// System.out.println("p(" + point[0] + "," + point[1] + ")");
			graphics.drawLine(x, y, x, y);
		}
	}

	private void drawAxis() {
		Graphics graphics = content.getGraphics();
		graphics.setColor(Color.GRAY);
		int width = content.getWidth();
		int height = content.getHeight();
		graphics.drawLine(0, height / 2, width - 1, height / 2);
		graphics.drawLine(width / 2, 0, width / 2, height - 1);
		int radius = (width > height) ? height : width;
		radius = (int) (radius * 0.35);
		graphics.drawOval(width / 2 - radius, height / 2 - radius, 2 * radius + 1, 2 * radius + 1);
	}

	private void clearScreen() {
		Graphics graphics = content.getGraphics();
		graphics.setColor(Color.BLACK);
		graphics.fillRect(0, 0, content.getWidth(), content.getHeight());
	}
}
