package gene;

public interface ISolutionUpdater {
	// 如果返回null表示保持原状
	// 否则表示更新为对应的值
	public SolEntry update(SolEntry old);
}
