package algorithm.test;

import algorithm.DateUtil;
import junit.framework.TestCase;

public class DateUtilTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T3_5, T5_7, T1_3]
	public void test00() {
		assertEquals((false), DateUtil.isLeapYear((int) 62600));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T1_2]
	public void test01() {
		assertEquals((true), DateUtil.isLeapYear((int) 0));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T5_8, T3_5, T1_3]
	public void test02() {
		assertEquals((true), DateUtil.isLeapYear((int) -4));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T3_6, T1_3]
	public void test03() {
		assertEquals((false), DateUtil.isLeapYear((int) 125732233));
	}
	//<<case-end>>
}
