package algorithm.test;

import algorithm.AlphabetChecker;
import junit.framework.TestCase;

public class AlphabetCheckerTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//<$c>
	public void test$$() {
		assertEquals(($_), AlphabetChecker.isAlphabet($0));
	}
	//<<case-end>>
}