package cn.edu.tsinghua.thss.randtest.cases;

import java.util.Arrays;
import java.util.Random;

public class HeapSort {
	private static void swap(int[] a, int l, int r) {
		int temp = a[l];
		a[l] = a[r];
		a[r] = temp;
	}
	
	public static void sort(int[] a) {
		// put into a max-heap
		int i = (a.length - 1) / 2;
		while (i >= 0) {
			int j = i;
			// stack = a[0, ..., i), i is the bound
			while (j < a.length) {
				int lchild = (j << 1) + 1;
				int rchild = (j << 1) + 2;
				if (lchild < a.length && rchild < a.length) {
					int largerChild = (a[lchild] > a[rchild] ? lchild : rchild);
					if (a[j] < a[largerChild]) {
						swap(a, j, largerChild);
						j = largerChild;
					} else {
						break;
					}
				} else if (lchild < a.length) {
					// now, rchild >= bound
					if (a[j] < a[lchild]) {
						swap(a, j, lchild);
						j = lchild;
					} else {
						break;
					}
				} else {
					// both are out of bound
					break;
				}
			}
			i--;
		}
		// sort
		for (i = a.length - 1; i > 0; i--) {
			// 1. take out the current max
			int currentMax = a[0];
			// 2. put the last element into top and regulate
			a[0] = a[i];
			int j = 0;
			// stack = a[0, ..., i), i is the bound
			while (j < i) {
				int lchild = (j << 1) + 1;
				int rchild = (j << 1) + 2;
				if (lchild < i && rchild < i) {
					int largerChild = (a[lchild] > a[rchild] ? lchild : rchild);
					if (a[j] < a[largerChild]) {
						swap(a, j, largerChild);
						j = largerChild;
					} else {
						break;
					}
				} else if (lchild < i) {
					// now, rchild >= bound
					if (a[j] < a[lchild]) {
						swap(a, j, lchild);
						j = lchild;
					} else {
						break;
					}
				} else {
					// both are out of bound
					break;
				}
			}
			a[i] = currentMax;
		}
	}
	
	public static void main(String[] args) {
		final int len = 100;
		final int[] a = new int[len];
		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			a[i] = rand.nextInt(100);
		}
		System.out.println(Arrays.toString(a));
		sort(a);
		for (int i = 0; i + 1 < a.length; i++) {
			if (a[i] > a[i + 1]) {
				System.out.println("error at index=" + i);
			}
		}
		System.out.println(Arrays.toString(a));
	}
}
