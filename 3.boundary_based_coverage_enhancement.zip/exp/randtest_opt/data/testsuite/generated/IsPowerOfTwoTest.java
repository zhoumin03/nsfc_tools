package algorithm.test;

import junit.framework.TestCase;
import algorithm.IsPowerOfTwo;

public class IsPowerOfTwoTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T1_3]
	public void test00() {
		assertEquals((false), IsPowerOfTwo.isPowerOfTwo(-1L));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_4, T1_2]
	public void test01() {
		assertEquals((true), IsPowerOfTwo.isPowerOfTwo(1L));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T1_2, T2_5]
	public void test02() {
		assertEquals((false), IsPowerOfTwo.isPowerOfTwo(3L));
	}
	//<<case-end>>
}
