package cn.edu.tsinghua.thss.randtest.cases.test;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class DoubleBarrier {
	public static int f(double x) {
		RT.startInvocation(2307182451834963968L);
		RT.track(1);
		if (((RT.b(0)) && (RT.le(0, x, 1))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return 1;
		} else {
			RT.nd(0);
			RT.track(3);
			return 0;
		}
	}
}
