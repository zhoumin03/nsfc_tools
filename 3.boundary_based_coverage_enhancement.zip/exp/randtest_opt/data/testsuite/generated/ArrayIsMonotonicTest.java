package algorithm.test;

import java.lang.reflect.Array;

import junit.framework.TestCase;
import algorithm.ArrayIsMonotonic;

public class ArrayIsMonotonicTest extends TestCase {
	
	public static<T> T[] toArray(Class<T> clazz, Object[] array) {
		T[] ret = (T[]) Array.newInstance(clazz, array.length);
		for (int i = 0; i < array.length; i++) {
			ret[i] = (T) array[i];
		}
		return ret;
	}
	
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//#0, coverages: [T15_19, T6_9, T3_4, T9_11, T19_22]
	public void test00() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) (new java.lang.Object[]{-10, 2147483647, 2819, 440869, 1, 10})); 
		Byte dir = (byte) (2);
		Boolean strict = (Boolean) (true);
		assertEquals((false), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T3_4, T14_18, T14_16, T10_14, T6_8]
	public void test01() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) (new java.lang.Object[]{-554998923, 4867639, -99894516, 2147483647, -1, -39541, 1, -1340, 2147483647})); 
		Byte dir = (byte) (1);
		Boolean strict = (Boolean) (false);
		assertEquals((false), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T20_16, T6_9, T3_4, T9_11, T20_23, T15_20]
	public void test02() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) (new java.lang.Object[]{3416, 10, 10, -1907396, -25900, 85, -232716835, 2147483647, 1})); 
		Byte dir = (byte) (2);
		Boolean strict = (Boolean) (false);
		assertEquals((false), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T15_19, T6_9, T3_4, T9_11, T19_22, T19_16]
	public void test03() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) (new java.lang.Object[]{5162571, -16746, -441, -2147483648, -10, -26, -871560078})); 
		Byte dir = (byte) (2);
		Boolean strict = (Boolean) (true);
		assertEquals((false), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T10_13, T3_4, T13_17, T6_8]
	public void test04() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) (new java.lang.Object[]{2147483647, -10, -9931, 1563064487, 1, 51224720, 3585})); 
		Byte dir = (byte) (1);
		Boolean strict = (Boolean) (true);
		assertEquals((false), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
}
