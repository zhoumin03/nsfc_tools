package trymaple;

/* 
 * a simple cmaple like program written in Java.  This uses many of the
 * features of Java Open Maple.
 */

/* import the OpenMaple classes */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

/* import the MapleException class */
import com.maplesoft.externalcall.MapleException;
import com.maplesoft.openmaple.Algebraic;
import com.maplesoft.openmaple.Engine;

class TryMaple
{
    /* the Maple session object */
    static private Engine kernel;
    /* the EngineCallBacks object*/
    static private JCEngineCallBacks callbacks;
    /* the MHelpBackVector object*/
    static private JCHelpCallBack helpcallbacks;
    /* where to read input from */
    static private BufferedReader input;

    /* initialize input, the input source */
    private static void initInput( String file )
    {
	if ( file == null )
	{
	    input = new BufferedReader( new InputStreamReader( System.in ) );
	}
	else
	{
	    try
	    {
		input = new BufferedReader( new FileReader( file ) );
	    }
	    catch ( FileNotFoundException e )
	    {
		System.err.println( e.getMessage() );
		System.exit(1);
	    }
	}
    }

    /* initialize the kernel and callback objects */
    private static void initKernel( )
    {
	String args[];

	args = new String[1];
	args[0] = "java";

	/* create the callback objects */
	callbacks = new JCEngineCallBacks();
	helpcallbacks = new JCHelpCallBack();

	try
	{
	    /* start the kernel */
	    kernel = new Engine( args, callbacks, null, null );
	}
	catch ( MapleException e )
	{
	    System.err.println( e.getMessage()+"\n" );
	    System.err.println( "Error starting OpenMaple session\n" );
	    System.exit(1);
	}
    }

    public static void main( String args[] )
    {
	Algebraic ret;
	String expr;
	boolean done;

	/* initialize the input method */
	if ( args.length > 0 )
	{
	    initInput( args[0] );
	}
	else
	{
	    initInput( null );
	}

	/* start the kernel */
	initKernel( );

	expr = null;
	ret = null;

	System.out.println( "\nWelcome to jcmaple\n" );

	done = false;
	while ( !done )
	{
	    /* prompt */
	    System.out.print( "> " );

	    /* get the input */
	    try
	    {
		expr = input.readLine();
	    }
	    catch ( IOException ioE )
	    {
		System.err.println( ioE.getMessage() );
		System.exit(1);
	    }

	    /* check for some special conditions */
	    /* end of file */
	    if ( expr == null )
	    {
		done = true;
		continue;
	    }
	    /* empty expression */
	    if ( expr.equals( "" ) )
	    {
		continue;
	    }
	    /* help request */
	    if ( expr.charAt( 0 ) == '?' )
	    {
		/* look up the help page and display it */
		String topic = expr.substring( 1 );

		helpcallbacks.initHelp();
		try
		{
		    kernel.getHelp( topic, Engine.MAPLE_HELP_ALL, helpcallbacks, 78, null );
		}
		catch ( MapleException me )
		{
		    System.out.println( me );
		    continue;
		}

		System.out.println( "Help page for "+topic );
		helpcallbacks.display();
		System.out.println( "\n" );

		continue;
	    }

	    /* evaluate the expr */
	    try
	    {
		ret = kernel.evaluate( expr );

		if ( ret != null )
		{
		    /* check if we should terminate */
		    done = ret.isStop();
		    /* since we no longer need this object, dispose it */
		    ret.dispose();
		}
	    }
	    catch ( MapleException e )
	    {
		System.err.println( "Error evaluating Maple expression\n" );
		System.exit(1);
	    }

	    /* print out any generated input */
	    while ( callbacks.numOfLines() > 0 )
	    {
		System.out.println( callbacks.getLine() );
	    }
	}

	try
	{
	    kernel.stop();
	}
	catch ( MapleException me )
	{
	}
    }
}
