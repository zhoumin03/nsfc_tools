package cn.edu.tsinghua.thss.randtest.rt.variation;


/**
 * 对变量值进行微小变化
 * @author aleck
 *
 */
public interface Generator<T> {
	// 生成一个特殊值
	public T nextSpecial();
	// 生成一个随机值
	public T nextRandom();
	// 生成一个带偏的随机值
	public T nextBiasedRandom();
	// 在当前基础进行小改动
	// scale \in (0, 1]，当前邻居 \in 最大领域 * scale
	// 离散类型可以选择忽略scale这个参数
	public T nextNeighbour(T current, double scale);
	// 当前“所有”的邻居，在LocalSearch中使用，从效率角度出发，数量不应太多
	// scale \in (0, 1]，当前邻居 \in 最大领域 * scale
	// 离散类型可以选择忽略scale这个参数
	public T[] allNeighbours(T current, double scale);
	
	// 维护一个池子，池子里面的可以重复使用
	public T nextByPolicy();
	// 深拷贝
	public T copy(T origin);
	
	// 由外部提醒可以开始构造特殊值了
	public void checkRegisterSpecial();
}
