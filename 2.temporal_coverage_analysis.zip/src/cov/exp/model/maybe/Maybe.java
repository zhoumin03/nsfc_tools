package cov.exp.model.maybe;

public abstract class Maybe<T> {
	@Override
	abstract public String toString();
}
