package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;


public class IntGenerator extends AbstractGenerator<Integer> {
	
	public void registerSpecials() {
		registerSpecial(0);
		registerSpecial(1);
		registerSpecial(-1);
		registerSpecial(10);
		registerSpecial(-10);
		registerSpecial(Integer.MAX_VALUE);
		registerSpecial(Integer.MIN_VALUE);
	}
	
	@Override
	public Integer nextRandom() {
		return rand.nextInt();
	}

	@Override
	public Integer nextBiasedRandom() {
		if (rand.nextBoolean()) {
			return (int) logBiasedLong(Integer.MAX_VALUE);
		} else {
			return (int) -logBiasedLong(-(long)Integer.MIN_VALUE);
		}
	}

	@Override
	public Integer nextNeighbour(Integer current, double scale) {
		if (current == Integer.MIN_VALUE) {
			return (current + 1);
		} else if (current == Integer.MAX_VALUE) {
			return (current - 1);
		} else {
			return (rand.nextBoolean() ? current + 1 : current - 1);
		}
	}

	@Override
	public Integer copy(Integer origin) {
		return Integer.valueOf(origin.intValue());
	}

	@Override
	public Integer[] allNeighbours(Integer current, double scale) {
		if (current == Integer.MIN_VALUE) {
			return new Integer[] {(current + 1)};
		} else if (current == Integer.MAX_VALUE) {
			return new Integer[] {(current - 1)};
		} else {
			return new Integer[] {current - 1, current + 1};
		}
	}
}
