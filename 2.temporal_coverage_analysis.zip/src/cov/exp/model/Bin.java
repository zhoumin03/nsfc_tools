package cov.exp.model;

import java.util.LinkedList;
import java.util.List;

public class Bin {
	private int id;
	public final List<State> states;
	
	public Bin(int id) {
		this.states = new LinkedList<>();
		this.id = id;
	}

	/**
	 * Attach a state to this bin and return the itself
	 * @param s
	 * @return
	 */
	public void attach(State s) {
		if (s.bin != null) {
			s.bin.dettach(s);
		}
		s.bin = this;
		states.add(s);
	}
	
	public void dettach(State s) {
		states.remove(s);
	}
	
	/**
	 * the size of the bin (how many concrete state it contains)
	 * @return
	 */
	public int size() {
		return states.size();
	}
	
	public int id() {
		return id;
	}
	
	public String toString() {
		return "[" + id + "]";
	}
}
