package randtest;

import gene.ISolution;
import gene.SolEntry;
import gene.TopNSolutionSet;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import sut.CtrlDepGraph;
import sut.TriangleClassifier;

public class GeneTestCaseRunner {

	private static final int POP_SIZE 	= 2;
	private static final int MAX_INT 	= 10000;
	private static final int INIT_ROUND = 10;
	private static final int MAX_ROUND 	= 1000;
	
	private static Random rand = new Random();
	private static TriangleClassifier tc = new TriangleClassifier();
	private static TestInputVariation variation = new TestInputVariation(rand.nextInt());
	private static PathFitness fitness;
	private static Queue<String> targets = new LinkedList<String>();
	
	public static void main(String[] args) {
		int rounds = 0;
		
		rand.setSeed(0);
		targets.addAll(CtrlDepGraph.targets);
		
		TestInput instance = newRandTestCase();

		List<TestInput> selection = new ArrayList<TestInput>();
		
		System.out.println("*** target is: " + targets.peek());
		fitness = new PathFitness(tc, targets.peek());
		
		TopNSolutionSet population = genInitPopulation(fitness);

		int singleTargetRound = 0;
		
		while (true) {
			rounds ++;
			singleTargetRound ++;
			
			// pick the top n chromosom and check for contribution
			if (hasContribution(population)) {
				selection.add(instance);
				targets.poll();
				
				System.out.println("*** current rounds=" + rounds);
				
				if (completelyCovered()) {
					break;
				}
				
				System.out.println("*** target is: " + targets.peek());
				fitness = new PathFitness(tc, targets.peek());
				population = genInitPopulation(fitness);
				
				singleTargetRound = 0;
			} else {
				geneticEvolution(population, calcTemperature(singleTargetRound));
			}
		}
		
		System.out.println("Achived after " + rounds + " rounds.");
	}

	private static double calcTemperature(int singleTargetRound) {
		if (singleTargetRound < INIT_ROUND) {
			return 1.0;
		} else if (singleTargetRound > MAX_ROUND) {
			return 0.0;
		} else {
			return 1.0 * (singleTargetRound - INIT_ROUND) / (MAX_ROUND - INIT_ROUND);
		}
	}

	private static boolean hasContribution(TopNSolutionSet population) {
		String target = targets.peek();
		for (SolEntry entry : population.listEntries()) {
			PathFitnessValue pfv = (PathFitnessValue) entry.fitness;
			if (pfv.path.contains(target)) {
				return true;
			}
		}
		return false;
	}

	private static boolean completelyCovered() {
		return targets.isEmpty();
	}

	private static void geneticEvolution(TopNSolutionSet population, double temperature) {
		List<ISolution> newPop = new ArrayList<ISolution>();
		
		for (ISolution chromosome : population.getSolutions()) {
			newPop.addAll(variation.evolve(chromosome, temperature));
		}
		
		for (ISolution sol : newPop) {
			population.addSolution(sol, fitness);
		}
	}

	private static TopNSolutionSet genInitPopulation(PathFitness fitness) {
		TopNSolutionSet pop = new TopNSolutionSet(POP_SIZE, fitness);
		pop.addSolution(newRandTestCase(), fitness);
		return pop;
	}

	private static TestInput newRandTestCase() {
		TestInput ti = new TestInput();
		ti.a = rand.nextInt() % MAX_INT;
		ti.b = rand.nextInt() % MAX_INT;
		ti.c = rand.nextInt() % MAX_INT;
		return ti;
	}
}
