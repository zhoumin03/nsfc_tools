package gene;

/**
 * 记录Solution和Fitness函数对应关系的类
 * @author aleck
 *
 */
public class SolEntry implements Comparable<SolEntry> {
	public ISolution solution;
	public IFitnessValue fitness;

	@Override
	public int compareTo(SolEntry that) {
		return (this.fitness.compareTo(that.fitness));
	}
	
	@Override
	public String toString() {
		return fitness.toString();
	}
}
