package cn.edu.tsinghua.thss.randtest.rt;

public class Pair<T extends Comparable<T>> {
	private T first;
	private T second;
	
	public Pair() {
		first = second = null;
	}

	public Pair(T first, T second) {
		set(first, second);
	}
	
	public T first() {
		return first;
	}
	
	public T second() {
		return second;
	}
	
	public void setFirst(T first) {
		this.first = first;
	}
	
	public void setSecond(T second) {
		this.second = second;
	}
	
	public void set(T first, T second) {
		this.first = first;
		this.second = second;
	}
	
	@Override
	public int hashCode() {
		return first.hashCode() << 1 + second.hashCode();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof Pair<?>)) {
			return false;
		}
		try {
			Pair<T> that = (Pair<T>) o;
			return this.first.equals(that.first) && this.second.equals(that.second);
		} catch (Exception e) {
			return false;
		}
	}
}
