package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;

public class OptimizerLogger {
	private List<Integer> remains;
	private Map<TestTarget, List<Double>> fitnesses;
	private Map<TestTarget, Long> efforts;
	
	private int totalTargets;
	private int coveredTargets;
	private int abandonedTargets;
	private int iterationUsed;
	private long timeConsumed;
	
	public OptimizerLogger() {
		remains = new ArrayList<Integer>();
		fitnesses = new HashMap<TestTarget, List<Double>>();
		efforts = new HashMap<TestTarget, Long>();
	}

	public void init() {
		remains.clear();
		fitnesses.clear();
		efforts.clear();
	}
	
	public void logRemaining(int remaining) {
		remains.add(remaining);
	}
	
	public void logBestFitness(TestTarget target, double fitness) {
		if (!fitnesses.containsKey(target)) {
			fitnesses.put(target, new ArrayList<Double>());
		}
		fitnesses.get(target).add(fitness);
	}
	
	public void logEffort(TestTarget target, long iterations) {
		efforts.put(target, iterations);
	}
	
	public void logPerformance(int total, int covered, int abandoned, int iteration, long timeConsumed) {
		this.totalTargets = total;
		this.coveredTargets = covered;
		this.abandonedTargets = abandoned;
		this.iterationUsed = iteration;
		this.timeConsumed = timeConsumed;
	}

	public int getIterationUsed() {
		return iterationUsed;
	}
	
	public int getTotalTargets() {
		return totalTargets;
	}
	
	public int getCoveredTargets() {
		return coveredTargets;
	}
	
	public int getAbandonedTargets() {
		return abandonedTargets;
	}
	
	public long getTimeConsumed() {
		return timeConsumed;
	}
	
	public void printData(String filename) {
		try {
			File outfile = new File(filename);
			FileUtils.ensureFile(outfile);
			PrintStream ps = new PrintStream(outfile);
			
			ps.println("= overview =");
			ps.println("iter\t=" + iterationUsed);
			ps.println("total\t=" + totalTargets);
			ps.println("cover\t=" + coveredTargets);
			ps.println("aban\t=" + abandonedTargets);
			ps.println("time\t=" + timeConsumed + "ms");
			
			ps.println("= Remainings =");
			for (int i = 0; i < remains.size(); i++) {
				ps.println(remains.get(i));
			}
			
			ps.println("= Efforts =");
			for (Map.Entry<TestTarget, Long> entry : efforts.entrySet()) {
				ps.println(entry.getKey() + "\t" + entry.getValue());
			}
			
			ps.println("= BestFitness =");
			for (Map.Entry<TestTarget, List<Double>> entry : fitnesses.entrySet()) {
				ps.println("- target= " + entry.getKey());
				List<Double> fitness = entry.getValue();
				for (int i = 0; i < fitness.size(); i++) {
					ps.println(fitness.get(i));
				}
			}
			ps.close();
			
			System.out.println("data exported to " + outfile.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
