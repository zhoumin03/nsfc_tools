package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class IsPowerOfTwo {
	public static boolean isPowerOfTwo(long n) {
		RT.startInvocation(55060259435155456L);
		RT.track(1);
		if (((RT.b(0)) && (RT.gt(0, n, 0))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			if (((RT.b(1)) && (RT.eq(0, (n & (n - 1)), 0))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(4);
				return true;
			} else {
				RT.nd(1);
				RT.track(5);
				return false;
			}
		} else {
			RT.nd(0);
			RT.track(3);
			return false;
		}
		// return (n > 0) && ((n & (n - 1)) == 0);	
	}
}
