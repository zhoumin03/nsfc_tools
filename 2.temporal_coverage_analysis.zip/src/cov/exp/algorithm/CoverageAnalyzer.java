package cov.exp.algorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import cov.exp.model.CoverageEstimation;
import cov.exp.model.State;
import cov.exp.model.SystemModel;
import cov.exp.model.maybe.Just;
import cov.exp.model.maybe.Nothing;

public class CoverageAnalyzer {
	// analyze for case 1
	public static final byte MODE_CASE_1			= 1;
	// analyze for case 2
	public static final byte MODE_CASE_2			= 2;
	// analyze for case 3
	public static final byte MODE_CASE_3			= 4;
	// analyze for all cases
	public static final byte MODE_ALL_CASES			= MODE_CASE_1 | MODE_CASE_2 | MODE_CASE_3;

	// analysis type in Inclusion-Exclusion analysis
	private static final byte TRIGGER_PROB			= 1;
	private static final byte NOT_REACH_PROB 		= 2;
	
	private SystemModel system;
	private ExpParameter params;
	
	private AlgorithmBase alg;
	// private AlgorithmCase2 alg2;
	// private AlgorithmCase3 alg3;

	public CoverageAnalyzer(ExpParameter params, SystemModel system) {
		this.params = params;
		this.system = system;
		alg = new AlgorithmBase();
	}
	
	/**
	 * Restrict the problem to a subgraph, ** while re-distributing the probabilities **
	 * @param oap
	 * @param exclude
	 * @return
	 */
	public AbstractProblem restrict(AbstractProblem oap, Set<Integer> exclude) {
		AbstractProblem nap = new AbstractProblem();
		nap.n = oap.n - exclude.size();
		// new index -> old index
		int[] idxMap = new int[nap.n];
		int accIdx = 0;
		for (int i = 0; i < oap.n; i++) {
			if (!exclude.contains(i)) {
				idxMap[accIdx++] = i;
			}
		}
		double excProb;
		
		// redistribute initial distribution
		excProb = 0;
		for (int i = 0; i < oap.n; i++) {
			if (exclude.contains(i)) {
				excProb += nap.init[i];
			}
		}
		nap.init = new double[nap.n];
		for (int i = 0; i < nap.n; i++) {
			nap.init[i] = oap.init[idxMap[i]] / (1 - excProb);
		}
		// redistribute transition probability
		nap.p = new double[nap.n][nap.n];
		for (int i = 0; i < nap.n; i++) {
			excProb = 0;
			int src = idxMap[i];
			for (int j = 0; j < oap.n; j++) {
				if (exclude.contains(j)) {
					excProb += oap.p[src][j];
				}
			}
			for (int j = 0; j < nap.n; j++) {
				nap.p[src][j] = oap.p[src][idxMap[j]] / (1 - excProb);
			}
		}
		// shift the bug-detect probability
		nap.q = new double[nap.n];
		for (int i = 0; i < nap.n; i++) {
			nap.q[i] = oap.q[idxMap[i]];
		}
		return nap;
	}
	
	/**
	 * Exclude a subset of vertexes, while ** preserving the old transition probabilities **
	 * 
	 * @param oap
	 * @param exclude
	 * @return
	 */
	public AbstractProblem reduce(AbstractProblem oap, Set<Integer> exclude) {
		AbstractProblem nap = new AbstractProblem();
		nap.n = oap.n - exclude.size();
		// new index -> old index
		int[] idxMap = new int[nap.n];
		int accIdx = 0;
		for (int i = 0; i < oap.n; i++) {
			if (!exclude.contains(i)) {
				idxMap[accIdx++] = i;
			}
		}
		// initial distribution
		nap.init = new double[nap.n];
		for (int i = 0; i < nap.n; i++) {
			nap.init[i] = oap.init[idxMap[i]];
		}
		// transition probability
		nap.p = new double[nap.n][nap.n];
		for (int i = 0; i < nap.n; i++) {
			int src = idxMap[i];
			for (int j = 0; j < nap.n; j++) {
				nap.p[i][j] = oap.p[src][idxMap[j]];
			}
		}
		// bug-detect probability
		nap.q = new double[nap.n];
		for (int i = 0; i < nap.n; i++) {
			nap.q[i] = oap.q[idxMap[i]];
		}
		return nap;
	}
	
	public AbstractProblem abstraction(ExpParameter params, SystemModel system) {
		AbstractProblem ap = new AbstractProblem();
		ap.n = system.numOfBins;
		
		// initial distribution and bug detection probability
		ap.init = new double[system.numOfBins];
		ap.q = new double[system.numOfBins];
		
		int[] init = new int[system.numOfBins];
		int[] bug = new int[system.numOfBins];
		Arrays.fill(init, 0);
		Arrays.fill(bug, 0);
		
		for (int i = 0; i < system.numOfStates; i++) {
			State s = system.states[i];
			if (s.initial)
				init[s.bin.id()] ++;
			if (s.bug)
				bug[s.bin.id()] ++;
		}
		
		for (int i = 0; i < system.numOfBins; i++) {
			// # initial states in bin[i] / # initial states
			ap.init[i] = 1.0 * init[i] / system.initials.size();
			// # bug detect states in bin[i] / # states in bin[i]
			if (system.bins[i].size() == 0) {
				ap.q[i] = 0;
			} else {
				ap.q[i] = 1.0 * bug[i] / system.bins[i].size();
			}
		}
		
		// transition probability matrix
		ap.p = new double[system.numOfBins][system.numOfBins];
		for (int i = 0; i < system.numOfBins; i++) {
			if (system.bins[i].size() == 0) {
				// transition probability = 0;
				for (int j = 0; j < system.numOfBins; j++) {
					ap.p[i][j] = 0;
				}
			} else {
				int[] cnt = new int[system.numOfBins];
				Arrays.fill(cnt, 0);
				// distribution of out-going edges
				for (State src : system.bins[i].states) {
					for (State dst : src.transitions) {
						cnt[dst.bin.id()] ++;
					}
				}
				// transition probability
				for (int j = 0; j < system.numOfBins; j++) {
					ap.p[i][j] = 1.0 * cnt[j] / (system.bins[i].size() * system.numOfInputPatterns);
				}
			}
		}
		
		return ap;
	}

	public CoverageEstimation analyze(int M, Set<Integer> T, AbstractProblem oap) {
		return analyze(M, T, oap, MODE_ALL_CASES);
	}
	
	public CoverageEstimation analyze(int M, Set<Integer> T, AbstractProblem oap, byte mode) {
		CoverageEstimation ce = new CoverageEstimation();
		boolean[] forbidden = new boolean[oap.n];
		for (int i = 0; i < oap.n; i++) {
			forbidden[i] = T.contains(i);
		}
		
		long timeStart;
		
		// case 1
		if ((mode & MODE_CASE_1) != 0) {
			timeStart = System.currentTimeMillis();
			double pEd = alg.triggerProb(M, oap);
			ce.r1 = Just.create(pEd);
			ce.timeR1 = System.currentTimeMillis() - timeStart;
		} else {
			ce.r1 = Nothing.create();
		}
		
		// case 2
		if ((mode & MODE_CASE_2) != 0) {
			timeStart = System.currentTimeMillis();
			// re-calculate pEd, although it is calculated in case 1.
			double pEd = alg.triggerProb(M, oap);
			
			double pEd_nEut = alg.triggerProb(M, oap, forbidden);
			double pEut = alg.reachProb(M, oap, T);
			if (Math.abs(pEut) < 1e-8) {
				ce.r2 = Nothing.create();
			} else {
				ce.r2 = Just.create((pEd - pEd_nEut) / pEut);
			}
			ce.timeR2 = System.currentTimeMillis() - timeStart;
		} else {
			ce.r2 = Nothing.create();
		}
		
		// case 3
		if ((mode & MODE_CASE_3) != 0) {
			timeStart = System.currentTimeMillis();
			// re-calculate pEd, although it is calculated in case 1.
			double pEd = alg.triggerProb(M, oap);
			
			List<Integer> ts = new ArrayList<>(T);
			double pEd_nEat = applyIncExc(M, oap, 0, 0, ts, new boolean[oap.n], TRIGGER_PROB);
			double pnEat = applyIncExc(M, oap, 0, 0, ts, new boolean[oap.n], NOT_REACH_PROB);
			if (Math.abs(pnEat - 1) < 1e-8)
				ce.r3 = Nothing.create();
			else 
				ce.r3 = Just.create((pEd - pEd_nEat) / (1 - pnEat));
			ce.timeR3 = System.currentTimeMillis() - timeStart;
		} else {
			ce.r3 = Nothing.create();
		}
		
		return ce;
	}
	
	public CoverageEstimation analyze(int M, Set<Integer> T, byte mode) {
		AbstractProblem oap = abstraction(params, system);
		return analyze(M, T, oap, mode);
	}

	public CoverageEstimation analyze(int M, Set<Integer> T) {
		AbstractProblem oap = abstraction(params, system);
		return analyze(M, T, oap, MODE_ALL_CASES);
	}

	/**
	 * Apply Inclusion-Exclusion Principle
	 * @param M
	 * @param ap
	 * @param prefix
	 * @param level
	 * @param ts
	 * @param forbidden
	 * @param type
	 * @return
	 */
	private double applyIncExc(
			int M, 
			AbstractProblem ap, 
			int prefix, // prefix == 0 implies there is no element selected yet.
			int level,
			List<Integer> ts, 
			boolean[] forbidden, 
			byte type
			) {
		if (level >= ts.size()) {
			double result = 0;
			if (prefix != 0) {
				if (type == TRIGGER_PROB) {
					// detect bug while not reaching any node in 'forbidden'
					result = alg.triggerProb(M, ap, forbidden);
				} else if (type == NOT_REACH_PROB) {
					// not reaching any node in forbidden
					result = (1 - alg.reachProb(M, ap, forbidden));
				} else {
					throw new RuntimeException("This can not happen!");
				}
			}
			return prefix * result;
		} else {
			// no taking this one
			double idle = applyIncExc(M, ap, prefix, level + 1, ts, forbidden, type);
			// take this one
			forbidden[ts.get(level)] = true;
			double take = applyIncExc(M, ap, prefix == 0 ? 1 : (-prefix), level + 1, ts, forbidden, type);
			forbidden[ts.get(level)] = false;
			
			return idle + take;
		}
	}

}
