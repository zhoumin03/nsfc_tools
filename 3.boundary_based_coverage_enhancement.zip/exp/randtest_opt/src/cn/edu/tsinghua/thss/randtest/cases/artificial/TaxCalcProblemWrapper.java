package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.TaxCalc;
import cn.edu.tsinghua.thss.randtest.cases.TaxCalcRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class TaxCalcProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Double.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new TaxCalcRuntimeAssist();
	}

	@Override
	public Object invoke(Input input) {
		return TaxCalc.tax((Double) input.data[0]);
	}

}
