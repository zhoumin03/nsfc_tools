package cov.exp.algorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cov.exp.external.maple.MapleEngine;
import cov.exp.model.InferResult;
import cov.exp.model.State;
import cov.exp.model.SystemModel;

public class DetectingProbInfer {

	public void infer(SystemModel system, ExpParameter params, List<DataCollector> dcs, InferResult ir) {
		// convert to an optimization problem and parse the result
		
		ir.nBins = system.numOfBins;
		ir.qt = calcBugDetProb(system);
		calcObjValue(system, dcs, ir);
		
		MapleEngine.restart();
		
		// 1. formulate the problem
		// Maple accepts the following formulation
		// with(Optimization):
		// f(y1,y2):=xxxx:
		// Minimize(f(y1,y2),{y1<=0,y2<=0},initialpoint=[y1=-0.5,y2=-0.5])
		MapleEngine.evaluate("with(Optimization):");
		MapleEngine.evaluate(funDefStr(system, params, dcs));
		
		List<String> rcs = rankConds(system, dcs);
		MapleEngine.evaluate(minOptStr(system.numOfBins, rcs));
		
		// 2. parse the output
		// Maple output the following line
		// [1., [y1 = -.555111512312578e-16, y2 = -.555111512312578e-16]]
		String result = MapleEngine.getLastResult();
		parseInferredResult(result, ir);
	}

	private void calcObjValue(SystemModel system, List<DataCollector> dcs, InferResult ir) {
		// obj = z1 + z2 + ...
		// where z_i = log \prod(1-di) for z_i \in F
		// and   z_i = log \prod(di) for z_i \notin F
		// where x is the bin over the trace.
		double[] q= ir.qt;
		double obj = 0;
		for (DataCollector dc : dcs) {
			double d = 1;
			for (State s : dc.getTrace()) {
				double qx = q[s.bin.id()];
				if (qx < 1e-8) {
					qx = 1e-8;
				} else if (qx + 1e-8 > 1) {
					qx = 1 - 1e-8;
				}
				d *= qx;
			}
			if (dc.isBugDetected()) {
				obj += Math.log(1 - d);
			} else {
				obj += Math.log(d);
			}
		}
		ir.objt = -obj;
	}

	private void parseInferredResult(String s, InferResult ir) {
		s = s.trim();
		int p = s.indexOf('[', 1);	// the second [
		
		ir.obji = Double.parseDouble(s.substring(1, p - 2));
		
		s = s.substring(p, s.length() - 2);	// y1=..., yn=...
		String[] pairs = s.split(",");
		int n = pairs.length;
		double[] q = new double[n];
		for (int i = 0; i < n; i++) {
			int pp = pairs[i].indexOf('=');
			double y = Double.parseDouble(pairs[i].substring(pp + 1));
			// x = (1 - q)
			// y = ln (x)
			// thus, q = 1 - e^y
			q[i] = 1 - Math.exp(y);
		}
		ir.qi = q;
	}

	private String minOptStr(int n, List<String> rcs) {
		StringBuilder sb = new StringBuilder();
		sb.append("Minimize(" + funNameStr(n) + ",");
		
		sb.append("{");
		sb.append("y0<=0");
		for (int i = 1; i < n; i++) {
			sb.append(",y" + i + "<=0");
		}
//		for (int i = 0; i < 4 && i < rcs.size(); i++) {
//			sb.append(",");
//			sb.append(rcs.get(i));
//		}
		sb.append("},");
		
		sb.append("initialpoint=[");
		sb.append("y0=-0.5");
		for (int i = 1; i < n; i++) {
			sb.append(",y" + i + "=-0.5");
		}
		sb.append("]);");
		return sb.toString();
	}

	private List<String> rankConds(SystemModel system, List<DataCollector> dcs) {
		int[] aef = new int[system.numOfBins];
		int[] aep = new int[system.numOfBins];
		Arrays.fill(aef, 0);
		Arrays.fill(aep, 0);
		for (DataCollector dc : dcs) {
			boolean detects = dc.isBugDetected();
			List<State> trace = dc.getTrace();
			for (State s : trace) {
				if (detects) {
					aef[s.bin.id()] ++;
				} else {
					aep[s.bin.id()] ++;
				}
			}
		}
		double[] q = new double[system.numOfBins];
		for (int i = 0; i < system.numOfBins; i++) {
			if (aef[i] + aep[i] > 0) {
				// Jacacard: aef / (aef + anf + aep) = aef / (totalFailed + aep)
				// q[i] = 1.0 * aef[i] / (totalFailed + aep[i]);
				q[i] = 1.0 * aef[i] / (aef[i] + aep[i]);
			} else {
				q[i] = 0;
			}
		}
		// q1 >= q2 >= ...
		int[] idx = new int[system.numOfBins];
		for (int i = 0; i < idx.length; i++) {
			idx[i] = i;
		}
		for (int i = 0; i < system.numOfBins; i++) {
			for (int j = i + 1; j < system.numOfBins; j++) {
				if (q[i] < q[j]) {
					double tq = q[i]; q[i] = q[j]; q[j] = tq;
					int ti = idx[i]; idx[i] = idx[j]; idx[j] = ti;
				}
			}
		}
		// x1 <= x2 <= ...
		// y1 <= y2 <= ...
		List<String> ret = new ArrayList<String>();
		for (int i = 1; i < system.numOfBins; i++) {
			ret.add("y" + idx[i - 1] + "<=" + "y" + idx[i]);
		}
		return ret;
	}

	private String funDefStr(SystemModel system, ExpParameter params, List<DataCollector> dcs) {
		StringBuilder sb = new StringBuilder();
		
		sb.append(funNameStr(system.numOfBins));
		sb.append(":=");
		
		List<String> items = new ArrayList<>();
		for (DataCollector dc : dcs) {
			String lc = linearComb(system, dc);
			if (dc.isBugDetected()) {
				// \prod log(1-di)
				items.add("ln(1-exp(" + lc + "))");
			} else {
				// \prod log(di)
				items.add(lc);
			}
		}

		sb.append("-(");	// minimize -(f) == maximize f, put an inversion here
		sb.append(items.get(0));
		for (int i = 1; i < items.size(); i++) {
			sb.append('+');
			sb.append(items.get(i));
		}
		sb.append(")");
		
		sb.append(':');
		return sb.toString();
	}

	/**
	 * Precondition, trace length > 0
	 * @param system
	 * @param dc
	 * @return
	 */
	private String linearComb(SystemModel system, DataCollector dc) {
		int[] count = new int[system.numOfBins];
		Arrays.fill(count, 0);
		for (State s : dc.getTrace()) {
			count[s.bin.id()] ++;
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < system.numOfBins; i++) {
			if (count[i] != 0) {
				if (sb.length() > 0) {
					sb.append('+');
				}
				sb.append(count[i]);
				sb.append('*');
				sb.append('y');
				sb.append(i);
			}
		}
		return sb.toString();
	}

	private String funNameStr(int n) {
		StringBuilder sb = new StringBuilder();
		sb.append("f(");
		sb.append("y0");
		for (int i = 1; i < n; i++) {
			sb.append(",y");
			sb.append(i);
		}
		sb.append(")");
		return sb.toString();
	}

	private double[] calcBugDetProb(SystemModel system) {
		double[] q = new double[system.numOfBins];
		int[] bug = new int[system.numOfBins];
		Arrays.fill(bug, 0);
		
		for (int i = 0; i < system.numOfStates; i++) {
			State s = system.states[i];
			if (s.bug)
				bug[s.bin.id()] ++;
		}
		
		for (int i = 0; i < system.numOfBins; i++) {
			// # bug detect states in bin[i] / # states in bin[i]
			if (system.bins[i].size() == 0) {
				q[i] = 0;
			} else {
				q[i] = 1.0 * bug[i] / system.bins[i].size();
			}
		}
		
		return q;
	}

}
