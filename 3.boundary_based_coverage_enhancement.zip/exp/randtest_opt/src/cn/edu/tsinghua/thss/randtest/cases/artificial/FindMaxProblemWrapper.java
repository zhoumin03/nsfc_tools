package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.FindMax;
import cn.edu.tsinghua.thss.randtest.cases.FindMaxRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.ArrayType;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.ArrayGenerator;

public class FindMaxProblemWrapper extends ProblemWrapper {

	@Override
	public void registerTypeDefs() {
		GeneratorFactory.registerDependentInstance(new ArrayGenerator<Integer>(), 
				ArrayType.class, 
				BASIC(Integer.class)
				);
	}
	
	@Override
	public Object invoke(Input input) {
		return FindMax.max(
				toIntArray(toArray(Integer.class, (Object[]) input.data[0])));
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				DEP(ArrayType.class, BASIC(Integer.class))
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new FindMaxRuntimeAssist();
	}

}
