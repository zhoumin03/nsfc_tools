package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class TriangleClassifier {
	public static enum TriangleType {
		INVALID_TRIANGLE,
		ACUTE_TRIANGLE,
		RIGHT_TRIANGLE,
		OBTUSE_TRIANGLE,
	}
	
	public static TriangleType classify(int a, int b, int c) {
		RT.startInvocation(2614951802748150784L);
		RT.track(1);
		if (((RT.b(0)) && (((((RT.le(0, a, 0)) || (RT.le(1, b, 0)))) || (RT.le(2,
				c, 0))))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(2);
			return TriangleType.INVALID_TRIANGLE;
		} else {
			RT.nd(0);
			RT.track(3);
			if (((RT.b(1)) && (RT.gt(0, a, b))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(5);
				int t = a;
				a = b;
				b = t;
			}
			RT.nd(1);
			RT.track(6);
			if (((RT.b(2)) && (RT.gt(0, b, c))) && (RT.e(2))) {
				RT.pd(2);
				RT.track(7);
				int t = b;
				b = c;
				c = t;
			}
			RT.nd(2);
			RT.track(8);
			if (((RT.b(3)) && (RT.gt(0, a, b))) && (RT.e(3))) {
				RT.pd(3);
				RT.track(9);
				int t = a;
				a = b;
				b = t;
			}
			RT.nd(3);
			RT.track(10);
			if (((RT.b(4)) && (RT.le(0, a + b, c))) && (RT.e(4))) {
				RT.pd(4);
				RT.track(12);
				return TriangleType.INVALID_TRIANGLE;
			} else {
				RT.nd(4);
				RT.track(11);
				long delta = (long) a * a + b * b - c * c;
				RT.track(13);
				if (((RT.b(5)) && (RT.gt(0, delta, 0))) && (RT.e(5))) {
					RT.pd(5);
					RT.track(15);
					return TriangleType.ACUTE_TRIANGLE;
				} else {
					RT.nd(5);
					RT.track(14);
					if (((RT.b(6)) && (RT.lt(0, delta, 0))) && (RT.e(6))) {
						RT.pd(6);
						RT.track(16);
						return TriangleType.OBTUSE_TRIANGLE;
					} else {
						RT.nd(6);
						RT.track(17);
						return TriangleType.RIGHT_TRIANGLE;
					}
				}
			}
		}
	}
	
	public static void main(String[] args) {
		TriangleType type = classify(8856054, 8856054, 8856054);
		System.out.println(type);
	}
}
