package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class Palindromic {
	public static boolean isPalindromic(String s) {
		RT.startInvocation(4697884468079319040L);
		RT.track(1);
		RT.track(2);
		for (int i = 0; ((RT.b(0)) && (RT.lt(0, i, s.length()))) && (RT.e(0)); i++) {
			RT.pd(0);
			RT.track(3);
			if (((RT.b(1)) && (RT.ne(0, s.charAt(i), s.charAt(s.length() - i - 1))))
					&& (RT.e(1))) {
				RT.pd(1);
				RT.track(5);
				return false;
			}
			RT.nd(1);
			RT.track(6);
		}
		RT.nd(0);
		RT.track(4);
		return true;
	}
}
