package cn.edu.tsinghua.thss.randtest.cases.artificial.linked_list;

import java.lang.reflect.Array;
import java.util.List;

import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Invoker;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.ArrayGenerator;

public class LinkedListProblemWrapper extends ProblemWrapper {

	@Override
	public void registerTypeDefs() {
		GeneratorFactory.registerDependentInstance(new ArrayGenerator<Integer>(), 
				Array.class, 
				BASIC(Integer.class)
				);
		GeneratorFactory.registerInductiveInstance(new NodeGenerator(), 
				Node.class, 
				BASIC(Integer.class), 
				SELF
				);
	}

	@Override
	public FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Integer.class),
				DEP(List.class, BASIC(Integer.class)),
				DEP(List.class, BASIC(Integer.class)),
				IND(Node.class, BASIC(Integer.class), SELF),
				BASIC(Integer.class)
				);
		return fp;
	}

	@Override
	public RuntimeAssist createRuntimeAssist() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String invoke(Input input) {
		// TODO Auto-generated method stub
		return null;
	}

}
