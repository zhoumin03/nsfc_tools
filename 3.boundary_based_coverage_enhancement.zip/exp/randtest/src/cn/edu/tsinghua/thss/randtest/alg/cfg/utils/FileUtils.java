package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import com.google.common.io.Files;

public class FileUtils {
	/**
	 * Create a directory
	 * @param workProjectBase
	 * @return
	 */
	public static boolean createDirectory(String directoryName) {
		File dir = new File(directoryName);
		if (!dir.exists()) {
			dir.mkdirs();
			return true;
		} else {
			return true;
		}
	}
	
	/**
	 * Create a file
	 * @param filename
	 * @return
	 * @throws IOException 
	 */
	public static boolean createFile(String filename) throws IOException {
		File file = new File(filename);
		if (!file.exists()) {
			File parent = file.getParentFile();
			if (parent.exists()) {
				if (parent.isFile()) {
					return false;
				} // else do nothing
			} else {
				parent.mkdirs();
			}
			file.createNewFile();
			return true;
		} else {
			return true;
		}
	}

	/**
	 * 将文件内容读取成String
	 * @param filename
	 * @return
	 */
	public static String readStringFromFile(String filename) {
		try {
			StringBuilder sb = new StringBuilder();
			InputStreamReader isr = new InputStreamReader(new FileInputStream(filename));
			char[] buffer = new char[1024];
			int len;
			while ((len = isr.read(buffer)) != -1) {
				if (len > 0) {
					sb.append(buffer, 0, len);
				}
			}
			isr.close();
			return sb.toString();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 将String写入文件
	 * @param filename
	 * @return
	 */
	public static boolean writeStringToFile(String filename, String content) {
		try {
			OutputStream os = new FileOutputStream(filename);
			os.write(content.getBytes());
			os.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 文件拷贝
	 * @param srcFilename
	 * @param dstFilename
	 */
	public static boolean copy(String srcFilename, String dstFilename) {
		try {
			createFile(dstFilename);
			Files.copy(new File(srcFilename), new File(dstFilename));
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	/**
	 * 确保File存在
	 * @param outfile
	 */
	public static boolean ensureFile(File file) {
		if (!file.exists()) {
			try {
				FileUtils.createFile(file.getAbsolutePath());
			} catch (IOException e) {
				return false;
			}
		}
		return true;
	}

}
