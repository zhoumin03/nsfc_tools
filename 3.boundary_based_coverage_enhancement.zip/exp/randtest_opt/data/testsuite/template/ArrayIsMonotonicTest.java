package algorithm.test;

import java.lang.reflect.Array;

import junit.framework.TestCase;
import algorithm.ArrayIsMonotonic;

public class ArrayIsMonotonicTest extends TestCase {
	
	public static<T> T[] toArray(Class<T> clazz, Object[] array) {
		T[] ret = (T[]) Array.newInstance(clazz, array.length);
		for (int i = 0; i < array.length; i++) {
			ret[i] = (T) array[i];
		}
		return ret;
	}
	
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	//<<case-begin>>
	//<$c>
	public void test$$() {
		Comparable<?>[] val = toArray(Comparable.class, (Object[]) ($0)); 
		Byte dir = (byte) ($1);
		Boolean strict = (Boolean) ($2);
		assertEquals(($_), 
				ArrayIsMonotonic.isMonotonic(val, dir, strict)
				);
	}
	//<<case-end>>
}
