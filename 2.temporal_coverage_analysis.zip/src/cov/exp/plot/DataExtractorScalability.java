package cov.exp.plot;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DataExtractorScalability extends AbstractDataExtractor {
	private static final String FILE_RAW_DATA_1	= "./data/results/scalability/1/20150807-155745.txt";
	private static final String FILE_RAW_DATA_2	= "./data/results/scalability/2/20150806-115248.txt";
	private static final String FILE_RAW_DATA_3	= "./data/results/scalability/3/20150806-115307.txt";
	
	private static final String FILE_DATA_1		= "./data/gnuplot/scalability/1.txt";
	private static final String FILE_DATA_2		= "./data/gnuplot/scalability/2.txt";
	private static final String FILE_DATA_3		= "./data/gnuplot/scalability/3.txt";
	
	private static final byte FIG_1				= 1;	// bins ++
	private static final byte FIG_2				= 2;	// states ++
	private static final byte FIG_3				= 3;	// cycles ++
	
	public static void main(String[] args) throws IOException {
		extract(FILE_RAW_DATA_1, FILE_DATA_1, FIG_1);
		extract(FILE_RAW_DATA_2, FILE_DATA_2, FIG_2);
		extract(FILE_RAW_DATA_3, FILE_DATA_3, FIG_3);
		System.out.println("OK!");
	}
	
	private static class DataItem {
		int ff;
		int bin;
		int cycles;
		long time;
	}

	private static void extract(String fileRawData, String fileData, byte mode) throws IOException {
		// input
		List<DataItem> data = new ArrayList<DataItem>();
		try (FileInputStream fis = new FileInputStream(fileRawData); 
				Scanner scanner = new Scanner(fis)) {
			while (scanner.hasNext()) {
				DataItem t = new DataItem();
				// 2 4 16 65536 100 158 11976 1 100 4
				scanner.nextInt();
				scanner.nextInt();
				t.ff = scanner.nextInt();
				scanner.nextInt();
				t.bin = scanner.nextInt();
				scanner.nextInt();
				scanner.nextInt();
				scanner.nextInt();
				t.cycles = scanner.nextInt();
				t.time = scanner.nextInt();
				data.add(t);
			}
		}
		// output
		ensureFile(fileData);
		try (FileWriter output = new FileWriter(fileData)) {
			for (DataItem t : data) {
				output.append(generateLine(t, mode));
			}
		}
	}

	private static String generateLine(DataItem t, byte mode) {
		double time = t.time / 1000.0;
		if (mode == FIG_1) {
			// bins ++
			return t.bin + " " + time + "\n";
		} else if (mode == FIG_2) {
			// ff ++
			return t.ff + " " + time + "\n";
		} else if (mode == FIG_3) {
			// cycles ++
			return t.cycles + " " + time + "\n";
		} else {
			throw new RuntimeException("Unknown mode: " + mode);
		}
	}

}
