package cn.edu.tsinghua.thss.randtest.cases.test;

import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class IntBarrierProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Integer.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new IntBarrierRuntimeAssist();
	}

	@Override
	public Object invoke(Input input) {
		return IntBarrier.f((Integer) input.data[0]);
	}

}
