package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton;

import java.util.ArrayList;
import java.util.List;

/**
 * 公式结构
 * @author aleck
 *
 */
public abstract class PropFormula {
	public boolean isConjunctionFormula() {
		if (isComposedFormula()) {
			return ((ComposedFormula) this).isConjunction();
		} else {
			return false;
		}
	}
	
	public boolean isDisjunctionFormula() {
		if (isComposedFormula()) {
			return ((ComposedFormula) this).isDisjunction();
		} else {
			return false;
		}
	}
	
	public boolean isAtom() {
		return (this instanceof PropAtom);
	}
	
	public boolean isComposedFormula() {
		return (this instanceof ComposedFormula);
	}
	
	/**
	 * parse
	 * @param s
	 * @return
	 */
	public static PropFormula parse(String s) {
		if (s.length() == 0) {
			throw new IllegalArgumentException("empty formula encountered!");
		} else {
			if (s.charAt(0) == '(') {
				// composed formula
				byte connector = ComposedFormula.parseConnector(s.charAt(1));
				List<PropFormula> subs = new ArrayList<PropFormula>();
				// s == "(&,(...),...,(...))"
				//         ^start_here
				int start = 2;
				int i = start + 1;
				int level = 0;
				boolean finished = false;
				while (true) {
					while (i < s.length()) {
						char c = s.charAt(i);
						if (c == '(') {
							level ++;
						} else if (c == ')') {
							if (level == 0) {
								// (&,...,(...))
								//             ^ this one
								finished = true;
								break;
							} else {
								level --;
							}
						} else if (c == ',' && level == 0){
							break;
						}
						i++;
					}
					
					subs.add(parse(s.substring(start + 1, i)));

					start = i;
					i++;
					if (finished)
						break;
				}
				ComposedFormula cf = new ComposedFormula(connector);
				cf.addSubFormulas(subs);
				return cf;
			} else {
				// atomic
				if (s.charAt(0) == '!') {
					return new PropAtom(false, Integer.parseInt(s.substring(1)));
				} else {
					return new PropAtom(true, Integer.parseInt(s));
				}
			}
		}
	}

	/**
	 * to string representation
	 * @param f
	 * @return
	 */
	public static String strRepr(PropFormula f) {
		StringBuilder sb = new StringBuilder();
		if (f.isAtom()) {
			PropAtom pa = (PropAtom) f;
			if (pa.isNegative()) {
				sb.append('!');
			}
			sb.append(pa.stub);
		} else {
			ComposedFormula cf = (ComposedFormula) f;
			sb.append('(');
			sb.append(cf.isConjunction() ? '&' : '|');
			for (PropFormula pf : cf.getSubFormulas()) {
				sb.append(',');
				sb.append(strRepr(pf));
			}
			sb.append(')');
		}
		return sb.toString();
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (isAtom()) {
			PropAtom pa = (PropAtom) this;
			if (pa.isNegative()) {
				sb.append('!');
			}
			sb.append(pa.stub);
		} else {
			ComposedFormula cf = (ComposedFormula) this;
			char connector = cf.isConjunction() ? '&' : '|';
			sb.append('(');
			int i = 0;
			for (PropFormula pf : cf.getSubFormulas()) {
				if (i > 0) {
					sb.append(connector);
				}
				sb.append(pf.toString());
				i++;
			}
			sb.append(')');
		}
		return sb.toString();
	}
}
