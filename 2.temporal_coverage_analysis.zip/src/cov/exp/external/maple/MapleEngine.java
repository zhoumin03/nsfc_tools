package cov.exp.external.maple;

import com.maplesoft.externalcall.MapleException;
import com.maplesoft.openmaple.Algebraic;
import com.maplesoft.openmaple.Engine;
import com.maplesoft.openmaple.EngineCallBacksDefault;

public class MapleEngine {
	private static MyEngineCallBacks callbacks;
	private static Engine engine = null;
	private static Algebraic lastResult = null;
	
	static {
		callbacks = new MyEngineCallBacks();
	}
	
	public static boolean start() {
		if (engine != null) {
			throw new RuntimeException("The engine is not started.");
		} else {
			try {
				engine = new Engine(new String[] {"java"}, new EngineCallBacksDefault(), null, null);
				return true;
			} catch (MapleException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	public static boolean stop() {
		if (engine == null) {
			throw new RuntimeException("The engine is already stopped.");
		} else {
			try {
				engine.stop();
				engine = null;
				return true;
			} catch (MapleException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	public static boolean evaluate(String expr) {
		if (engine == null) {
			throw new RuntimeException("The engine is not started.");
		} else {
			try {
				System.out.println("evaluating: " + expr);
				lastResult = engine.evaluate(expr);
				return true;
			} catch (MapleException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	public static String getLastResult() {
		if (lastResult == null) {
			return "NULL";
		} else {
			return lastResult.toString();
		}
	}
	
	public static boolean restart() {
		if (engine == null) {
			throw new RuntimeException("The engine is not started.");
		} else {
			try {
				engine.restart();
				return true;
			} catch (MapleException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
}
