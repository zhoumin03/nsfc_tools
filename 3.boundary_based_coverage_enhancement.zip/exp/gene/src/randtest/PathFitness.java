package randtest;

import gene.ISolution;
import gene.IFitnessFunc;
import gene.IFitnessValue;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sut.CtrlDepGraph;
import sut.TriangleClassifier;

public class PathFitness implements IFitnessFunc {
	private static final Pattern VAL_PATTERN = 
			Pattern.compile("#dist\\((.+)\\): (-?\\d+)");

	private TriangleClassifier tc;
	private String target;
	
	public PathFitness(TriangleClassifier tc, String target) {
		this.tc = tc;
		this.target = target;
	}

	@Override
	public IFitnessValue eval(ISolution sol) {
		TestInput ti = (TestInput) sol;
		
		tc.setupTracker();
		tc.classify(ti.a, ti.b, ti.c);
		
		List<String> p = CtrlDepGraph.path.get(target);
		
		// p.size >= 1
		
		int depth = 0;
		int curDepth = 0;
		int dist = 0;
		String current = null;
		String next = null;
		for (Object o : tc.getTracker().getTrace()) {
			String line = (String) o;
			if (line.startsWith("#")) {
				if (curDepth == depth) {
					Matcher m = VAL_PATTERN.matcher(line);
					if (m.matches()) {
						next = m.group(1);
						if (p.contains(next) && CtrlDepGraph.depth.get(next) > curDepth) {
							int d = Integer.parseInt(m.group(2));
							dist = (d > dist ? d : dist);
						}
					} else {
						System.out.println("Invalid: " + line);
					}
				}
			} else {
				current = line;
				if (p.contains(current)) {
					curDepth = CtrlDepGraph.depth.get(current);
					if (curDepth > depth) {
						depth = curDepth;
						dist = Integer.MIN_VALUE;
					}
				}
			}
		}
		
		// depth < p.size()
		PathFitnessValue pfv = new PathFitnessValue();
		pfv.path = new ArrayList<String>();
		for (int i = 0; i <= depth; i++) {
			pfv.path.add(CtrlDepGraph.path.get(target).get(i));
		}
		pfv.depth = depth;
		pfv.dist = dist;
		
		return pfv;
	}
}
