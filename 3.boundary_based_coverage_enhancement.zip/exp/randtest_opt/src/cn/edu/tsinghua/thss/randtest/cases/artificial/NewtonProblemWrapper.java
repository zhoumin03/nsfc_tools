package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.Newton;
import cn.edu.tsinghua.thss.randtest.cases.NewtonRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class NewtonProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Double.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new NewtonRuntimeAssist();
	}

	@Override
	public Object invoke(Input input) {
		return Newton.sqrt((Double) input.data[0]);
	}

}
