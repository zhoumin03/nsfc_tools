package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.Set;

import cn.edu.tsinghua.thss.randtest.alg.core.target.BinaryTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.alg.core.target.UnaryTarget;
import cn.edu.tsinghua.thss.randtest.rt.Pair;
import cn.edu.tsinghua.thss.randtest.rt.RT;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

/**
 * Manage test targets
 * @author aleck
 *
 */
public class TargetManager {
	// 每一个target保存多少个命中
	private static final int RESERVED_INPUT_PER_TARGET 		= 2;
	// 每一个target保存多少个TestCase
	private static final int RESERVED_TEST_CASE_PER_TARGET 	= 2;
	
	private Category category;
	
	// 当前目标
	private TestTarget currentTarget 			= null;
	// 全部目标
	private Set<TestTarget> allTargets 			= new HashSet<TestTarget>();
	// 已经覆盖到的目标（可能是碰巧覆盖到的）
	private Set<TestTarget> coveredTargets 		= new HashSet<TestTarget>();
	// 尚未覆盖到的目标
	private Set<TestTarget> remainingTargets 	= new HashSet<TestTarget>();
	// 训练之后无法覆盖到的目标
	private Set<TestTarget> abandonedTargets 	= new HashSet<TestTarget>();
//	// 等待训练的目标
//	private Set<TestTarget> trainedTargets 		= new HashSet<TestTarget>();
	
	private Map<Integer, TestTarget> unaryTarget = new HashMap<Integer, TestTarget>();
	private Map<Pair<Integer>, TestTarget> binaryTarget = new HashMap<Pair<Integer>, TestTarget>();
	
	// the difference between hitset and testcase is:
	// 1. hitset does not consider fitness
	// 2. testcase is sorted by fitness
	private Map<TestTarget, List<Input>> hitsets = new HashMap<TestTarget, List<Input>>();
	private Map<TestTarget, PriorityQueue<Chromosome>> testcases = new HashMap<TestTarget, PriorityQueue<Chromosome>>();

	public TargetManager(Category category) {
		this.category = category;
	}
	
	public Category getCategory() {
		return category;
	}
	
	/**
	 * 加载
	 */
	public void loadTargets() {
		// targets are reused over runs
		allTargets.addAll(RT.getTargets(category));
		remainingTargets.addAll(allTargets);
		abandonedTargets.clear();
		coveredTargets.clear();
		buildIndex();
	}

	private void buildIndex() {
		for (TestTarget target : allTargets) {
			if (target.isUnaryTarget()) {
				UnaryTarget ut = (UnaryTarget) target;
				unaryTarget.put(ut.block, ut);
			} else if (target.isBinaryTarget()) {
				BinaryTarget bt = (BinaryTarget) target;
				binaryTarget.put(new Pair<Integer>(bt.first, bt.second), bt);
			} else {
				throw new RuntimeException("invalid test target.");
			}
		}
	}

	/**
	 * 清空
	 */
	public void clear() {
		// 清除Hit记录
		hitsets.clear();
		testcases.clear();
		// 清除当前目标
		currentTarget = null;
		// 清除内部变量
		allTargets.clear();
		remainingTargets.clear();
		abandonedTargets.clear();
		coveredTargets.clear();
		// 清除对目标的索引
		clearIndex();
	}

	private void clearIndex() {
		unaryTarget.clear();
		binaryTarget.clear();
	}
	
	/// Numbers
	
	protected int numOfAllTargets() {
		return allTargets.size();
	}
	
	protected int numOfRemainingTargets() {
		return remainingTargets.size();
	}

	protected int numOfCoveredTargets() {
		return coveredTargets.size();
	}

	protected int numOfAbandonedTargets() {
		return abandonedTargets.size();
	}

	public void coverTarget(TestTarget target) {
		// only one will have effect
		if (remainingTargets.contains(target) || abandonedTargets.contains(target)) {
			remainingTargets.remove(target);
			abandonedTargets.remove(target);
			coveredTargets.add(target);
		}
	}

	public void abandonTarget(TestTarget target) {
		if (!remainingTargets.contains(target)) {
			throw new RuntimeException("target " + target + " is not in REMAINING.");
		} else {
			remainingTargets.remove(target);
			abandonedTargets.add(target);
		}
	}

	public boolean remainsToBeCovered() {
		return remainingTargets.size() > 0;
	}

	public boolean allTargetCovered() {
		return remainingTargets.size() == 0 && abandonedTargets.size() == 0;
	}

	/**
	 * Not in remaining and not in abandoned
	 * @param bid
	 * @return
	 */
	public boolean targetCovered(TestTarget target) {
		return !remainingTargets.contains(target) && !abandonedTargets.contains(target);
	}
	
	public void pickAnyRemainingTarget() {
		if (remainingTargets.isEmpty()) {
			throw new NoSuchElementException("all targets has been covered, no element to pick.");
		} else {
			currentTarget = remainingTargets.iterator().next();
		}
	}

	/**
	 * 1. 记录target被覆盖时的输入
	 * 2. 维护remainingTarget
	 * @param input
	 * @param trace
	 */
	public void hitTargetAlongTheTrace(Input input, List<Integer> trace) {
		Input copyInput = InputModifier.copy(input);
		Pair<Integer> reuse = new Pair<Integer>();
		int last = -1;
		for (Integer block : trace) {
			if (block <= 0) {
				throw new RuntimeException("unexpected block is: " + block);
			}
			// unary target
			TestTarget ut = unaryTarget.get(block);
			if (ut != null) {
				// 是一个目标
				hitTarget(ut, copyInput);
			}
			// binary target
			if (last != -1) {
				reuse.setFirst(last);
				reuse.setSecond(block);
				TestTarget bt = binaryTarget.get(reuse);
				if (bt != null) {
					// 是一个目标
					hitTarget(bt, copyInput);
				}
			} 
			last = block;
		}
	}
	
	/**
	 * 1. cover the target
	 * 2. record the input
	 * @param target
	 * @param refOfInput
	 */
	private void hitTarget(TestTarget target, Input refOfInput) {
		coverTarget(target);
		if (!hitsets.containsKey(target)) {
			hitsets.put(target, new ArrayList<Input>());
		}
		List<Input> hs = hitsets.get(target);
		if (hs.size() < RESERVED_INPUT_PER_TARGET) {
			hs.add(refOfInput);
		}
	}

	public TestTarget currentTarget() {
		return currentTarget;
	}

	/**
	 * 当前Target被覆盖了
	 * @return
	 */
	public boolean currentTargetCovered() {
		return (currentTarget != null) && targetCovered(currentTarget);
	}
	
	public void registerTestCase(List<Chromosome> population) {
		TestTarget target = currentTarget;
		for (int i = 0; i < population.size() && i < RESERVED_TEST_CASE_PER_TARGET; i++) {
			registerTestCase(target, population.get(i));
		}
	}

	private void registerTestCase(TestTarget target, Chromosome c) {
		if (!testcases.containsKey(target)) {
			PriorityQueue<Chromosome> queue = new PriorityQueue<Chromosome>(
					Chromosome.ASCENDING_CHROMOSOME_COMPARATOR);
			testcases.put(target, queue);
		}
		PriorityQueue<Chromosome> queue = testcases.get(target);
		queue.add(c);
		while (queue.size() > RESERVED_TEST_CASE_PER_TARGET) {
			queue.poll();
		}
	}

	/**
	 * 将收集到的用例展示出来
	 */
	public void printHitSet() {
		System.out.println("-- Hit Set --");
		for (Map.Entry<TestTarget, List<Input>> entry : hitsets.entrySet()) {
			System.out.println("- for target: " + entry.getKey());
			for (Input input : entry.getValue()) {
				System.out.println(input.toString());
			}
		}
		System.out.println("------ END -----");
	}

	/**
	 * 将收集到的用例展示出来
	 * 1. if the target is covered by testcases, return the case.
	 * 2. otherwise, the target is covered randomly, return the hit.
	 */
	public void printTestCases() {
		System.out.println("-- Test Cases --");
		for (TestTarget target : allTargets) {
			System.out.print("- target: " + target + ", ");
			if (testcases.containsKey(target)) {
				System.out.println("testcase:");
				for (Chromosome c : testcases.get(target)) {
					System.out.println(c.toString());
				}
			} else if (hitsets.containsKey(target)) {
				System.out.println("hitset:");
				for (Input input : hitsets.get(target)) {
					System.out.println(input.toString());
				}
			} else {
				System.out.println("not covered!");
			}
		}
		System.out.println("------ END -----");
	}

	/**
	 * testcases + hitsets
	 * @return
	 */
	public Map<TestTarget, PriorityQueue<Chromosome>> collectTestCases() {
		Map<TestTarget, PriorityQueue<Chromosome>> ret = new HashMap<TestTarget, PriorityQueue<Chromosome>>(testcases);
		for (Map.Entry<TestTarget, List<Input>> e : hitsets.entrySet()) {
			if (!ret.containsKey(e.getKey())) {
				ret.put(e.getKey(), new PriorityQueue<Chromosome>(
						Chromosome.ASCENDING_CHROMOSOME_COMPARATOR));
			}
			PriorityQueue<Chromosome> queue = ret.get(e.getKey());
			for (Input i : e.getValue()) {
				Chromosome c = new Chromosome(i, OptimizeParameter.DEFAULT_RANDOM_FITNESS);
				queue.add(c);
			}
			while (queue.size() > RESERVED_TEST_CASE_PER_TARGET) {
				queue.poll();
			}
		}
		return ret;
	}

	public Set<TestTarget> getAllTargets() {
		return allTargets;
	}

	/**
	 * 返回某个路径上覆盖的所有target
	 * @param trace
	 * @return
	 */
	public Set<TestTarget> collectTargetsAlongTrace(List<Integer> trace) {
		Set<TestTarget> ret = new HashSet<TestTarget>();
		Pair<Integer> reuse = new Pair<Integer>();
		int last = -1;
		for (Integer block : trace) {
			if (block <= 0) {
				throw new RuntimeException("unexpected block is: " + block);
			}
			// unary target
			TestTarget ut = unaryTarget.get(block);
			if (ut != null) {
				// 是一个目标
				ret.add(ut);
			}
			// binary target
			if (last != -1) {
				reuse.setFirst(last);
				reuse.setSecond(block);
				TestTarget bt = binaryTarget.get(reuse);
				if (bt != null) {
					// 是一个目标
					ret.add(bt);
				}
			} 
			last = block;
		}
		return ret;
	}

	/**
	 * 是否被成功训练过
	 * @param target
	 * @return
	 */
	public boolean hasTrained(TestTarget target) {
		return testcases.containsKey(target);
	}

	/**
	 * 设置当前训练目标
	 * 一般不要使用这个方法，而是使用pickAnyRemainingTarget
	 * 该方法只在需要特殊训练某些特定目标时使用
	 * @param target
	 */
	public void setCurrentTarget(TestTarget target) {
		currentTarget = target;
	}
}
