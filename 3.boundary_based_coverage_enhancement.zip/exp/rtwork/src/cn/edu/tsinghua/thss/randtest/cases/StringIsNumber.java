package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;


public class StringIsNumber {
    /**
     * <p>Checks whether the String a valid Java number.</p>
     *
     * <p>Valid numbers include hexadecimal marked with the <code>0x</code>
     * qualifier, scientific notation and numbers marked with a type
     * qualifier (e.g. 123L).</p>
     *
     * <p><code>Null</code> and empty String will return
     * <code>false</code>.</p>
     *
     * @param str  the <code>String</code> to check
     * @return <code>true</code> if the string is a correctly formatted number
     */
    public static boolean isNumber(String str) {
        RT.startInvocation(933076831714977792L);
		RT.track(1);
		if (((RT.b(0)) && (((RT.eq(0, str, null)) || (RT.eq(1, str.length(), 0)))))
				&& (RT.e(0))) {
            RT.pd(0);
			RT.track(2);
			return false;
        }
        RT.nd(0);
		RT.track(3);
		char[] chars = str.toCharArray();
        int sz = chars.length;
        boolean hasExp = false;
        boolean hasDecPoint = false;
        boolean allowSigns = false;
        boolean foundDigit = false;
        // deal with any possible sign up front
        int start = (chars[0] == '-') ? 1 : 0;
        RT.track(5);
		if (((RT.b(1)) && (((((RT.gt(0, sz, start + 1)) && (RT.eq(1, chars[start],
				'0')))) && (RT.eq(2, chars[start + 1], 'x'))))) && (RT.e(1))) {
            RT.pd(1);
			RT.track(6);
			int i = start + 2;
            RT.track(8);
			if (((RT.b(2)) && (RT.eq(0, i, sz))) && (RT.e(2))) {
                RT.pd(2);
				RT.track(10);
				return false; // str == "0x"
            }
            RT.nd(2);
			RT.track(11);
			// checking hex (it can't be anything else)
            for (; ((RT.b(4)) && (RT.lt(0, i, chars.length))) && (RT.e(4)); i++) {
                RT.pd(4);
				RT.track(14);
				if (((RT.b(7)) && (((((((RT.lt(0, chars[i], '0')) || (RT.gt(1,
						chars[i], '9')))) && (((RT.lt(2, chars[i], 'a')) || (RT
						.gt(3, chars[i], 'f')))))) && (((RT
						.lt(4, chars[i], 'A')) || (RT.gt(5, chars[i], 'F')))))))
						&& (RT.e(7))) {
                    RT.pd(7);
						RT.track(20);
					return false;
                }
				RT.nd(7);
				RT.track(21);
            }
            RT.nd(4);
			RT.track(15);
			return true;
        }
        RT.nd(1);
		RT.track(7);
		sz--; // don't want to loop to the last char, check it afterwords
              // for type qualifiers
        int i = start;
        RT.track(9);
		// loop to the next to last char or to the last char if we need another digit to
        // make a valid number (e.g. chars[0..5] = "1234E")
        while (((RT.b(3)) && (((RT.lt(0, i, sz)) || (((((RT.lt(1, i, sz + 1)) && (RT
				.so(2, allowSigns)))) && (!RT.so(3, foundDigit)))))))
				&& (RT.e(3))) {
            RT.pd(3);
			RT.track(12);
			if (((RT.b(5)) && (((RT.ge(0, chars[i], '0')) && (RT.le(1, chars[i],
					'9'))))) && (RT.e(5))) {
                RT.pd(5);
				RT.track(16);
				foundDigit = true;
                allowSigns = false;

            } else {
				RT.nd(5);
				RT.track(17);
				if (((RT.b(8)) && (RT.eq(0, chars[i], '.'))) && (RT.e(8))) {
				    RT.pd(8);
					RT.track(24);
					if (((RT.b(11)) && (((RT.so(0, hasDecPoint)) || (RT.so(1, hasExp)))))
							&& (RT.e(11))) {
				        RT.pd(11);
						RT.track(29);
						// two decimal points or dec in exponent   
				        return false;
				    }
				    RT.nd(11);
					RT.track(30);
					hasDecPoint = true;
				} else {
					RT.nd(8);
					RT.track(23);
					if (((RT.b(10)) && (((RT.eq(0, chars[i], 'e')) || (RT.eq(1, chars[i],
							'E'))))) && (RT.e(10))) {
					    RT.pd(10);
						RT.track(28);
						// we've already taken care of hex.
					    if (((RT.b(14)) && (RT.so(0, hasExp))) && (RT.e(14))) {
					        RT.pd(14);
							RT.track(35);
							// two E's
					        return false;
					    }
					    RT.nd(14);
						RT.track(36);
						if (((RT.b(17)) && (!RT.so(0, foundDigit))) && (RT.e(17))) {
					        RT.pd(17);
							RT.track(41);
							return false;
					    }
					    RT.nd(17);
						RT.track(42);
						hasExp = true;
					    allowSigns = true;
					} else {
						RT.nd(10);
						RT.track(27);
						if (((RT.b(13)) && (((RT.eq(0, chars[i], '+')) || (RT.eq(1, chars[i],
								'-'))))) && (RT.e(13))) {
						    RT.pd(13);
							RT.track(33);
							if (((RT.b(16)) && (!RT.so(0, allowSigns))) && (RT.e(16))) {
						        RT.pd(16);
								RT.track(39);
								return false;
						    }
						    RT.nd(16);
							RT.track(40);
							allowSigns = false;
						    foundDigit = false; // we need a digit after the E
						} else {
						    RT.nd(13);
							RT.track(34);
							return false;
						}
					}
				}
			}
            RT.track(22);
			i++;
        }
        RT.nd(3);
		RT.track(13);
		if (((RT.b(6)) && (RT.lt(0, i, chars.length))) && (RT.e(6))) {
            RT.pd(6);
			RT.track(18);
			if (((RT.b(9)) && (((RT.ge(0, chars[i], '0')) && (RT.le(1, chars[i],
					'9'))))) && (RT.e(9))) {
                RT.pd(9);
				RT.track(25);
				// no type qualifier, OK
                return true;
            }
            RT.nd(9);
			RT.track(26);
			if (((RT.b(12)) && (((RT.eq(0, chars[i], 'e')) || (RT.eq(1, chars[i],
					'E'))))) && (RT.e(12))) {
                RT.pd(12);
				RT.track(31);
				// can't have an E at the last byte
                return false;
            }
            RT.nd(12);
			RT.track(32);
			if (((RT.b(15)) && (RT.eq(0, chars[i], '.'))) && (RT.e(15))) {
                RT.pd(15);
				RT.track(37);
				if (((RT.b(18)) && (((RT.so(0, hasDecPoint)) || (RT.so(1, hasExp)))))
						&& (RT.e(18))) {
                    RT.pd(18);
					RT.track(43);
					// two decimal points or dec in exponent
                    return false;
                }
                RT.nd(18);
				RT.track(44);
				// single trailing decimal point after non-exponent is ok
                return foundDigit;
            }
            RT.nd(15);
			RT.track(38);
			if (((RT.b(19)) && (((!RT.so(0, allowSigns)) && (((((((RT.eq(1,
					chars[i], 'd')) || (RT.eq(2, chars[i], 'D')))) || (RT.eq(3,
					chars[i], 'f')))) || (RT.eq(4, chars[i], 'F')))))))
					&& (RT.e(19))) {
                RT.pd(19);
						RT.track(45);
				return foundDigit;
            }
            RT.nd(19);
			RT.track(46);
			if (((RT.b(20)) && (((RT.eq(0, chars[i], 'l')) || (RT.eq(1, chars[i],
					'L'))))) && (RT.e(20))) {
                RT.pd(20);
					RT.track(47);
				// not allowing L with an exponent or decimal point
                return foundDigit && !hasExp && !hasDecPoint;
            }
            RT.nd(20);
			RT.track(48);
			// last character is illegal
            return false;
        }
        RT.nd(6);
		RT.track(19);
		// allowSigns is true iff the val ends in 'E'
        // found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
        return !allowSigns && foundDigit;
    }
}
