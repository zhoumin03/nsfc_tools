package gene;

import java.util.ArrayList;
import java.util.List;

public class FixedSizeSolutionSet {
	private int size;
	
	private List<SolEntry> entries;
	
	public FixedSizeSolutionSet(int size) {
		this.size = size;
		this.entries = new ArrayList<SolEntry>(size);
		// initial value
		for (int i = 0; i < size; i++) {
			entries.add(null);
		}
	}
	
	public int getSize() {
		return size;
	}

	public void traverse(ISolutionUpdater updater, IFitnessFunc ff) {
		for (int i = 0; i < entries.size(); i++) {
			SolEntry entry = updater.update(entries.get(i));
			if (entry != null) {
				entries.set(i, entry);
			}
		}
	}
	
	public List<ISolution> getSolutions() {
		List<ISolution> solutions = new ArrayList<ISolution>(entries.size());
		for (SolEntry entry : entries) {
			solutions.add(entry.solution);
		}
		return solutions;
	}

	public List<SolEntry> listEntries() {
		return entries;
	}

	public SolEntry getBestFitEntry() {
		if (entries.size() == 0) {
			return null;
		} else {
			SolEntry best = entries.get(0);
			for (int i = 1; i < entries.size(); i++) {
				SolEntry one = entries.get(i);
				if (best.fitness.compareTo(one.fitness) > 0) {
					best = one;
				}
			}
			return best;
		}
	}
}
