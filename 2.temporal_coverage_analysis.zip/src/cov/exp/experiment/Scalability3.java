package cov.exp.experiment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * �̶� pins, bins, ffs; ���� M 
 * ��֤ 2^ffs >> bins
 * @author aleck
 *
 */
public class Scalability3 extends ScalabilityAbstract {
	protected String getOutputPath() {
		return BASE_OUTPUT_PATH + "/3";
	}
	
	protected List<ExpSetting> generateSettings(Random rand) {
		// rand, pin, ff, bins, M, targets, repeats, initRatio, bugRatio

		// pure random instances
		List<ExpSetting> ret = new ArrayList<ExpSetting>();
		// change bins from 0 to 1000
		ret.addAll(buildSetting(rand, 
				S(2),				// pins 		<-- important
				S(10),				// flip-flops 	<-- important
				S(100),				// bins 		<-- important
				I(100, 10000, 100),	// M			<-- used
				S(1), 				// targets		not used
				S(0), 				// repeats, 	not used
				S(0.01), 			// init,		not used
				S(0.01), 			// bug,			not used, but significantly affects performance
				1					// duplicates	<-- used
				));
		return ret;
	}

	public static void main(String[] args) throws IOException {
		ScalabilityAbstract sa = new Scalability3();
		sa.invokeWithSeed(0);
		System.out.println("Finished at " + Calendar.getInstance().getTime());
	}


}
