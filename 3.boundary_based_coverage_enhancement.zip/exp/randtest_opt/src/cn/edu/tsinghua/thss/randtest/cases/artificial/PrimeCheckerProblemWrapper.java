package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.PrimeChecker;
import cn.edu.tsinghua.thss.randtest.cases.PrimeCheckerRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class PrimeCheckerProblemWrapper extends ProblemWrapper {
	
	private final PrimeChecker pc = new PrimeChecker();
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Integer.class)
				);
		return fp;
	}

	@Override
	public Object invoke(Input input) {
		return pc.isPrime((Integer) input.data[0]);
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new PrimeCheckerRuntimeAssist();
	}

}
