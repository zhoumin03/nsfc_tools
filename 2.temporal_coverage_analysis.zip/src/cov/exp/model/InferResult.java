package cov.exp.model;

public class InferResult {
	// number of bins
	public int nBins;
	// original q
	public double[] qt;
	public double objt;
	// inferred q
	public double[] qi;
	public double obji;
}
