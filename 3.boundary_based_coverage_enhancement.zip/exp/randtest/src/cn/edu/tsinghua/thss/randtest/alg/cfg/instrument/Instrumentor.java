package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.ImportDeclaration;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MarkerAnnotation;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.ComposedFormula;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.FormulaBinding;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropAtom;
import cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton.PropFormula;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ActionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.DecisionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.ASTUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CountStatementUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.ExpressionUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.ProblemDescription;
import cn.edu.tsinghua.thss.randtest.alg.core.target.BinaryTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget.Category;
import cn.edu.tsinghua.thss.randtest.alg.core.target.UnaryTarget;

public class Instrumentor {
	// Random Testing RunTime
	public static final String RT_NAME = "RT";
	public static final String RA_BASE_CLASS_NAME = "RuntimeAssist";
	public static final String RT_PACKAGE = "cn.edu.tsinghua.thss.randtest.rt";
	public static final String RT_BIND_ID_SKELETON = "bind";
	public static final String RT_TRACK_FUN = "track";
	public static final String RT_POSITIVE_DISTANCE_EVAL_FUN = "pd";
	public static final String RT_NEGATIVE_DISTANCE_EVAL_FUN = "nd";
	public static final String RT_EVAL_BEGIN_FUN = "b";
	public static final String RT_EVAL_END_FUN = "e";
	public static final String RT_SETUP_BEGIN_FUN = "beginSetup";
	public static final String RT_SETUP_END_FUN = "endSetup";
	public static final String RT_START_INVOCATION = "startInvocation";
	public static final String RT_SET_INVOCATION_SERIAL_NUMBER_FUN = "setInvocationSerialNumber";
	public static final String RT_NOTIFY_CYCLOMATIC_COMPLEXITY_FUN = "notifyCyclomaticComplexity";
	public static final String RT_NOTIFY_STATEMENT_COUNT_FUN = "notifyStatementCount";
	public static final String RT_CHECK_INVOCATION_SERIAL_NUMBER_FUN = "checkInvocation";
	// 以下4个函数跟skeleton中可能出现的predicate一一对应
	public static final String RT_PRED_EQ = "eq";	// equal
	public static final String RT_PRED_NE = "ne";	// not equal
	public static final String RT_PRED_GT = "gt";	// greater than
	public static final String RT_PRED_GE = "ge";	// greater equal
	public static final String RT_PRED_LT = "lt";	// less than
	public static final String RT_PRED_LE = "le";	// less equal
	public static final String RT_PRED_SO = "so";	// solo
	// used for runtime assist
	public static final String RT_ADD_TARGET_FUN = "addTarget";
	public static final String RT_SET_DISTANCE_FUN = "setDistance";
	public static final String RT_CONST_MAX_DISTANCE = "MAX_DISTANCE";
	
	// Runtime Assist
	public static final String RA_NAME_POST_FIX = "RuntimeAssist";
	public static final String RA_SETUP_FUN = "setup";
	public static final String RA_PACKAGE = "cn.edu.tsinghua.thss.randtest.rt";

	public static String getRuntimeAssistClassName(String originalName) {
		return originalName + RA_NAME_POST_FIX;
	}
	
	private List<PropFormula> skeletons = new ArrayList<PropFormula>();

	/**
	 * 插入跟踪代码，保证每一个block内部，track语句出现在pd或nd之后，例如：
	 * IF (xxx) {
	 *   pd(0);
	 *   track(3);
	 * } else {
	 *   pd(0);
	 *   track(4);
	 * }
	 * @param ast
	 * @param pd
	 */
	public void instrument(AST ast, ProblemDescription pd) {
		// 先记住语句数量
		pd.setOriginalStatementCount(CountStatementUtils.countMethodDeclaration(pd.method));
		// 再进行插装
		for (ActionBlock ab : pd.actions) {
			handleTrack(ast, ab.sourceBackToASTNode(), pd, ab);
		}
		for (DecisionBlock db : pd.decisions) {
			handleTrack(ast, db.sourceBackToASTNode(), pd, db);
			handleConditionEvaluation(ast, db.sourceBackToASTNode(), pd, db);
		}
		// randomly generate a serial number
		long serial = (long) (Math.random() * Long.MAX_VALUE);
		// add RT.startInvocation()
		addStartInvocation(ast, pd, serial);
		// add all skeleton definitions at the beginning
		// define the isolation graph
		pd.setMethodDeclarationSetup(generateSetupMethod(ast, pd, serial));
		addImportDeclaration(ast, pd);
	}

	/**
	 * 添加RT.startInvocation()到函数开头
	 * @param ast
	 * @param pd
	 */
	@SuppressWarnings("unchecked")
	private void addStartInvocation(AST ast, ProblemDescription pd, long serial) {
		MethodInvocation mi = ast.newMethodInvocation();
		mi.setExpression(ast.newSimpleName(RT_NAME));
		mi.setName(ast.newSimpleName(RT_START_INVOCATION));
		mi.arguments().add(ast.newNumberLiteral(serial + "L"));
		Statement stat = ast.newExpressionStatement(mi);
		insertBefore(ast, pd.method.getBody(), stat);
	}

	@SuppressWarnings("unchecked")
	private void addImportDeclaration(AST ast, ProblemDescription pd) {
		// import rt.runtime.RT;
		CompilationUnit cu = null;
		try {
			cu = (CompilationUnit) pd.method.getParent().getParent();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		ImportDeclaration id = ast.newImportDeclaration();
		id.setName(ASTUtils.inlineQualifiedNameToName(ast, RT_PACKAGE + "." + RT_NAME));
		cu.imports().add(id);
	}

	@SuppressWarnings("unchecked")
	private MethodDeclaration generateSetupMethod(AST ast, 
			ProblemDescription pd,
			long invocationSerialNumber) {
		MethodDeclaration md = ast.newMethodDeclaration();
		Block block = ast.newBlock();
		
		{
			// RT.beginSetup();
			MethodInvocation mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_SETUP_BEGIN_FUN));
			block.statements().add(ast.newExpressionStatement(mi));
			
			// set invocation serial number
			mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_SET_INVOCATION_SERIAL_NUMBER_FUN));
			mi.arguments().add(ast.newNumberLiteral(invocationSerialNumber + "L"));
			block.statements().add(ast.newExpressionStatement(mi));
			
			// notify cyclomatic complexity
			mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_NOTIFY_CYCLOMATIC_COMPLEXITY_FUN));
			mi.arguments().add(ast.newNumberLiteral("" + (pd.decisions.size() + 1)));
			block.statements().add(ast.newExpressionStatement(mi));
			
			// notify #stat
			mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_NOTIFY_STATEMENT_COUNT_FUN));
			mi.arguments().add(ast.newNumberLiteral("" + pd.getOriginalStatementCount()));
			block.statements().add(ast.newExpressionStatement(mi));
		}
		
		// add targets
		for (int i = skeletons.size() - 1; i >= 0; i--) {
			PropFormula pf = skeletons.get(i);
			StringLiteral str = ast.newStringLiteral();
			str.setLiteralValue(PropFormula.strRepr(pf));
			
			MethodInvocation mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_BIND_ID_SKELETON));
			mi.arguments().add(ast.newNumberLiteral("" + i));
			mi.arguments().add(str);
			
			block.statements().add(ast.newExpressionStatement(mi));
		}
		
		//-set targets:
		//RT.addTarget(STATEMENT, 0);
		//RT.addTarget(STATEMENT, 1);
		//...
		for (TestTarget target : pd.statementTargets) {
			block.statements().add(
					createAddTargetStatement(ast, pd,  TestTarget.Category.STATEMENT, target));
		}
		//RT.addTarget(BRANCH, 0, 1);
		//RT.addTarget(BRANCH, 2);
		for (TestTarget target : pd.branchTargets) {
			block.statements().add(
					createAddTargetStatement(ast, pd,  TestTarget.Category.BRANCH, target));
		}
		
		//-set distance:
		//RT.setDistance(0, 2, 1.0);	-- target, node, dist
		//...
		for (int i = 0; i < pd.graphSize(); i++) {
			List<Boolean> isolation = new ArrayList<Boolean>();
			List<Double> distance = new ArrayList<Double>();
			CfgUtils.calcIsolationGraph(pd, i, isolation, distance);
			for (int j = 0; j < pd.graphSize(); j++) {
				ASTNode dist = null;
				if (distance.get(j) >= Double.MAX_VALUE) {
					dist = ast.newQualifiedName(ast.newSimpleName(RT_NAME), ast.newSimpleName(RT_CONST_MAX_DISTANCE));
				} else {
					dist = ast.newNumberLiteral("" + distance.get(j));
				}
				
				MethodInvocation mi = ast.newMethodInvocation();
				mi.setExpression(ast.newSimpleName(RT_NAME));
				mi.setName(ast.newSimpleName(RT_SET_DISTANCE_FUN));
				mi.arguments().add(ast.newNumberLiteral("" + i));
				mi.arguments().add(ast.newNumberLiteral("" + j));
				mi.arguments().add(dist);
				
				block.statements().add(ast.newExpressionStatement(mi));
				
//				System.out.print('\t');
//				System.out.print('[');
//				System.out.print(j);
//				System.out.print(']');
//				System.out.print(isolation.get(j) ? "@" : "");
//				System.out.print((distance.get(j) >= Double.MAX_VALUE) ? "Inf" : distance.get(j));
			}
//			System.out.println();
		}
		
		{
			// RT.endSetup();
			MethodInvocation mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_SETUP_END_FUN));
			block.statements().add(ast.newExpressionStatement(mi));
		}
		
		md.setConstructor(false);
		// annotation: @Override
		MarkerAnnotation ma = ast.newMarkerAnnotation();
		ma.setTypeName(ast.newSimpleName("Override"));
		md.modifiers().add(ma);
		// public
		md.modifiers().add(ast.newModifier(ModifierKeyword.PUBLIC_KEYWORD));
		// void
		md.setReturnType2(ast.newPrimitiveType(PrimitiveType.VOID));
		// setup()
		md.setName(ast.newSimpleName(RA_SETUP_FUN));
		// {...}
		md.setBody(block);
		
		return md;
	}

	/**
	 * 
	 * @param statement
	 * @param testTarget
	 * @return 
	 */
	@SuppressWarnings("unchecked")
	private Statement createAddTargetStatement(AST ast, ProblemDescription pd, 
			Category category, TestTarget target) {
		MethodInvocation mi = ast.newMethodInvocation();
		mi.setExpression(ast.newSimpleName(RT_NAME));
		mi.setName(ast.newSimpleName(RT_ADD_TARGET_FUN));
		mi.arguments().add(
				ASTUtils.makeQualifiedName(ast,
						TestTarget.class.getSimpleName(), 
						Category.class.getSimpleName(), 
						category.name()
						));
		if (target.isUnaryTarget()) {
			UnaryTarget ut = (UnaryTarget) target;
			mi.arguments().add(ast.newNumberLiteral("" + ut.block));
		} else if (target.isBinaryTarget()) {
			BinaryTarget bt = (BinaryTarget) target;
			mi.arguments().add(ast.newNumberLiteral("" + bt.first));
			mi.arguments().add(ast.newNumberLiteral("" + bt.second));
		} else {
			throw new IllegalArgumentException("unknown target type!");
		}
		return ast.newExpressionStatement(mi);
	}

	/**
	 * 在point的positive和negative边分别添加条件计算语句
	 * point只可能是：
	 * 1. IfStatement
	 * 2. ForStatement
	 * 3. WhileStatement
	 * 4. DoStatement
	 * 5. SwitchCase
	 * 
	 * 每一个条件判断处，会被注入语句监视条件判断的过程
	 * 之后马上要跟语句，读取条件距离
	 * 
	 * @param ast
	 * @param point
	 * @param db
	 */
	private void handleConditionEvaluation(AST ast, ASTNode point, 
			ProblemDescription pd, BasicBlock db) {
		if (point instanceof IfStatement) {
			handleCondEvalIfStatement(ast, (IfStatement) point);
		} else if (point instanceof ForStatement) {
			handleCondEvalForStatement(ast, (ForStatement) point);
		} else if (point instanceof WhileStatement) {
			handleCondEvalWhileStatement(ast, (WhileStatement) point);
		} else if (point instanceof DoStatement) {
			handleCondEvalDoStatement(ast, (DoStatement) point);
		} else if (point instanceof SwitchCase) {
			handleCondEvalSwitchCase(ast, (SwitchCase) point);
		} else {
			throw new RuntimeException("Invalid point for ConditionEvaluation: " + point.getClass().getName());
		}
	}

	private void handleCondEvalSwitchCase(AST ast, SwitchCase point) {
		// do nothing for switch case
		// SwitchCase是分情况讨论，此时做距离计算无意义
	}
	
	private void handleCondEvalDoStatement(AST ast, DoStatement point) {
		Expression condition = point.getExpression();
		
		FormulaBinding binding = new FormulaBinding();
		int sid = extractAndSaveSkeleton(condition, binding);
		PropFormula pf = skeletons.get(sid);
		Expression newExpr = createCondEvalUsingRT(ast, sid, pf, binding);
		
		Statement ps = createBranchEvaluation(ast, sid, true);
		Statement ns = createBranchEvaluation(ast, sid, false);
		
		point.setExpression(newExpr);
		
		insertBefore(ast, point.getBody(), ps);
		insertAfter(ast, point, ns);
	}

	private void handleCondEvalWhileStatement(AST ast, WhileStatement point) {
		Expression condition = point.getExpression();
		
		FormulaBinding binding = new FormulaBinding();
		int sid = extractAndSaveSkeleton(condition, binding);
		PropFormula pf = skeletons.get(sid);
		Expression newExpr = createCondEvalUsingRT(ast, sid, pf, binding);
		
		Statement ps = createBranchEvaluation(ast, sid, true);
		Statement ns = createBranchEvaluation(ast, sid, false);
		
		point.setExpression(newExpr);
		
		insertBefore(ast, point.getBody(), ps);
		insertAfter(ast, point, ns);
	}

	private void handleCondEvalForStatement(AST ast, ForStatement point) {
		Expression condition = point.getExpression();
		
		FormulaBinding binding = new FormulaBinding();
		int sid = extractAndSaveSkeleton(condition, binding);
		PropFormula pf = skeletons.get(sid);
		Expression newExpr = createCondEvalUsingRT(ast, sid, pf, binding);
		
		Statement ps = createBranchEvaluation(ast, sid, true);
		Statement ns = createBranchEvaluation(ast, sid, false);
		
		point.setExpression(newExpr);
		
		insertBefore(ast, point.getBody(), ps);
		insertAfter(ast, point, ns);
	}

	private void handleCondEvalIfStatement(AST ast, IfStatement point) {
		Expression condition = point.getExpression();
		
		FormulaBinding binding = new FormulaBinding();
		int sid = extractAndSaveSkeleton(condition, binding);
		PropFormula pf = skeletons.get(sid);
		Expression newExpr = createCondEvalUsingRT(ast, sid, pf, binding);
		
		Statement ps = createBranchEvaluation(ast, sid, true);
		Statement ns = createBranchEvaluation(ast, sid, false);
		
		point.setExpression(newExpr);
		
		insertBefore(ast, point.getThenStatement(), ps);
		if (point.getElseStatement() == null) {
			insertAfter(ast, point, ns);
		} else {
			insertBefore(ast, point.getElseStatement(), ns);
		}
	}

	/**
	 * 创建实用RT类实现的条件判断，用来替换原有的条件，例如
	 * (x >= y && !a.isGood() || c != null) is replaced with
	 * RT.BEGIN() && (RT.GT(0, x, y) && !RT.S(1, a.isGood()) || !RT.EQ(2, c, null)) && RT.END()
	 * Here, 
	 * (1) RT.BEGIN() and RT.END() are functions that always returns TRUE
	 * 		they are used to inform the RT to do setup and teardown
	 * (2) 0, 1, 2 are atomic id-s
	 * @param ast
	 * @param sid 条件skeleton对应的id
	 * @param pf
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Expression createCondEvalUsingRT(AST ast, int sid, PropFormula pf, FormulaBinding binding) {
		Expression replaced = createCondEvalUsingRTRecursive(ast, pf, binding);
		
		MethodInvocation rt_begin = ast.newMethodInvocation();
		rt_begin.setExpression(ast.newSimpleName(RT_NAME));
		rt_begin.arguments().add(ast.newNumberLiteral("" + sid));
		rt_begin.setName(ast.newSimpleName(RT_EVAL_BEGIN_FUN));

		MethodInvocation rt_end = ast.newMethodInvocation();
		rt_end.setExpression(ast.newSimpleName(RT_NAME));
		rt_end.arguments().add(ast.newNumberLiteral("" + sid));
		rt_end.setName(ast.newSimpleName(RT_EVAL_END_FUN));
		
		return ExpressionUtils.createConjunction(ast, 
				ExpressionUtils.createConjunction(ast, 
						rt_begin, replaced), rt_end);
	}

	private Expression createCondEvalUsingRTRecursive(AST ast, PropFormula pf, FormulaBinding binding) {
		if (pf.isAtom()) {
			PropAtom pa = (PropAtom) pf;
			Expression expr = createPredicateExpression(ast, pa.stub, binding.get(pa.stub));
			if (!pa.positive) {
				PrefixExpression negation = ast.newPrefixExpression();
				negation.setOperator(PrefixExpression.Operator.NOT);
				negation.setOperand(expr);
				return negation;
			} else {
				return expr;
			}
		} else {
			ComposedFormula cf = (ComposedFormula) pf;
			
			List<PropFormula> subs = cf.getSubFormulas();
			if (subs.size() < 2) {
				throw new IllegalArgumentException("#subs = " + subs.size() + ", invalid.");
			}
			Expression comb = cf.isConjunction() ?
				ExpressionUtils.createConjunction(ast, 
						createCondEvalUsingRTRecursive(ast, subs.get(0), binding), 
						createCondEvalUsingRTRecursive(ast, subs.get(1), binding)) :
				ExpressionUtils.createDisjunction(ast, 
						createCondEvalUsingRTRecursive(ast, subs.get(0), binding), 
						createCondEvalUsingRTRecursive(ast, subs.get(1), binding));
			for (int i = 3; i < subs.size(); i++) {
				comb = cf.isConjunction() ?
					ExpressionUtils.createConjunction(ast, comb,
							createCondEvalUsingRTRecursive(ast, subs.get(i), binding)): 
					ExpressionUtils.createDisjunction(ast, comb,
							createCondEvalUsingRTRecursive(ast, subs.get(i), binding)); 
			}
			ParenthesizedExpression pe = ast.newParenthesizedExpression();
			pe.setExpression(comb);
			return pe;
		}
	}
	
	/**
	 * 从Expression转换成基于RT.predicate的表达式
	 * 此处的Expression已经是原子形式
	 * NOTE: NNF中的原子命题，不包括 negation
	 * @param ast
	 * @param expression
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Expression createPredicateExpression(AST ast, int stub, Expression expr) {
		expr = ExpressionUtils.retainParenthesizedChild(expr);
		Expression wrapped = null;
		if (expr instanceof InfixExpression) {
			InfixExpression ie = (InfixExpression) expr;
			InfixExpression.Operator op = ie.getOperator();

			if (op == InfixExpression.Operator.EQUALS ||
					op == InfixExpression.Operator.NOT_EQUALS||
					op == InfixExpression.Operator.GREATER ||
					op == InfixExpression.Operator.GREATER_EQUALS ||
					op == InfixExpression.Operator.LESS ||
					op == InfixExpression.Operator.LESS_EQUALS) {
				MethodInvocation mi = ast.newMethodInvocation();
				String opstr = null;
				if (op == InfixExpression.Operator.EQUALS) {
					// ==
					opstr = RT_PRED_EQ;
				} else if (op == InfixExpression.Operator.NOT_EQUALS) {
					// !=
					opstr = RT_PRED_NE;
				} else if (op == InfixExpression.Operator.GREATER) {
					// >
					opstr = RT_PRED_GT;
				} else if (op == InfixExpression.Operator.GREATER_EQUALS) {
					// >=
					opstr = RT_PRED_GE;
				} else if (op == InfixExpression.Operator.LESS) {
					// <
					opstr = RT_PRED_LT;
				} else if (op == InfixExpression.Operator.LESS_EQUALS) {
					// <=
					opstr = RT_PRED_LE;
				} else {
					// impossible
					opstr = "???";
				}
				mi.setExpression(ast.newSimpleName(RT_NAME));
				mi.setName(ast.newSimpleName(opstr));
				mi.arguments().add(ast.newNumberLiteral("" + stub));
				mi.arguments().add(ASTNode.copySubtree(ast, ie.getLeftOperand()));
				mi.arguments().add(ASTNode.copySubtree(ast, ie.getRightOperand()));
				wrapped = mi;
			}
		}
		if (wrapped != null) {
			return wrapped;
		} else {
			// solo
			MethodInvocation mi = ast.newMethodInvocation();
			mi.setExpression(ast.newSimpleName(RT_NAME));
			mi.setName(ast.newSimpleName(RT_PRED_SO));
			mi.arguments().add(ast.newNumberLiteral("" + stub));
			mi.arguments().add(ASTNode.copySubtree(ast, expr));
			return mi;
		}
	}

	/**
	 * 当最近的条件成立时，计算“不成立”的距离
	 * @param ast
	 * @param sid Skeleton ID
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Statement createBranchEvaluation(AST ast, int sid, boolean positive) {
		MethodInvocation mi = ast.newMethodInvocation();
		mi.setExpression(ast.newSimpleName(RT_NAME));
		mi.setName(ast.newSimpleName(
				positive ? RT_POSITIVE_DISTANCE_EVAL_FUN : RT_NEGATIVE_DISTANCE_EVAL_FUN));
		mi.arguments().add(ast.newNumberLiteral("" + sid));
		Statement ret = ast.newExpressionStatement(mi);
		return ret;
	}

	/**
	 * 1. Extract skeleton
	 * 2. Save it to 'skeletons'
	 * 3. return the ID
	 * @param condition
	 * @param binding
	 * @return
	 */
	private int extractAndSaveSkeleton(Expression condition,
			FormulaBinding binding) {
		int sid = skeletons.size();
		skeletons.add(ExpressionUtils.expr2skeleton(condition, true, binding));
		return sid;
	}

	/**
	 * 在point前面添加针对BasicBlock的跟踪代码
	 * 1. SwitchCase前面不跟踪（无法实现）
	 * @param ast
	 * @param point
	 * @param ab
	 */
	private void handleTrack(AST ast, ASTNode point, 
			ProblemDescription pd, BasicBlock bb) {
		if (point instanceof SwitchCase) {
			// do nothing
		} else {
			Statement newEntry = createTrackStatement(ast, pd, bb);
			insertBefore(ast, point, newEntry);
		}
	}

	@SuppressWarnings("unchecked")
	private Statement createTrackStatement(AST ast, ProblemDescription pd, 
			BasicBlock ab) {
		MethodInvocation mi = ast.newMethodInvocation();
		mi.setExpression(ast.newSimpleName(RT_NAME));
		mi.setName(ast.newSimpleName(RT_TRACK_FUN));
		mi.arguments().add(ast.newNumberLiteral("" + pd.node2id(ab)));
		Statement ret = ast.newExpressionStatement(mi);
		return ret;
	}
	
	/**
	 * 将newEntry插入到point同等级的前面
	 * 例如：
	 * for (int i = 0; i < 10; i++)
	 *   point
	 * 需要转化成
	 * for (int i = 0; i < 10; i++) {
	 *   newEntry
	 *   point
	 * }
	 * 即：newEntry需要跟point在同一个语句块中。不能因为插入语句改变了其语义结构
	 * @param point
	 * @param newEntry
	 */
	@SuppressWarnings("unchecked")
	private void insertBefore(AST ast, ASTNode point, ASTNode newEntry) {
		if (point instanceof Block) {
			Block block = (Block) point;
			block.statements().add(0, newEntry);
		} else {
			ASTNode parent = point.getParent();
			if (!(parent instanceof Statement)) {
				throw new RuntimeException("Invalid parent type: " + parent.getClass().getName());
			} else {
				insertBeforeChild(ast, parent, point, newEntry);
			}
		}
	}

	/**
	 * Insert a statement before a 'child' in 'parent'
	 * 1. child 需要是 parent 的"直接"子节点
	 * 2. child 必定不是 Block, Try 或者 Synchronized
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	private void insertBeforeChild(AST ast, ASTNode parent, ASTNode child, ASTNode newEntry) {
		if (parent instanceof Block) {
			insertBeforeChildBlock(ast, (Block) parent, child, newEntry);
		} else if (parent instanceof IfStatement) {
			insertBeforeChildIfStatement(ast, (IfStatement) parent, child, newEntry);
		} else if (parent instanceof ForStatement) {
			insertBeforeChildForStatement(ast, (ForStatement) parent, child, newEntry);
		} else if (parent instanceof WhileStatement) {
			insertBeforeChildWhileStatement(ast, (WhileStatement) parent, child, newEntry);
		} else if (parent instanceof DoStatement) {
			insertBeforeChildDoStatement(ast, (DoStatement) parent, child, newEntry);
		} else if (parent instanceof SwitchStatement) {
			insertBeforeChildSwitchStatement(ast, (SwitchStatement) parent, child, newEntry);
		} else {
			throw new RuntimeException("Invalid parent statement: " + parent.getClass().getName());
		}
	}

	@SuppressWarnings("unchecked")
	private void insertBeforeChildSwitchStatement(AST ast,
			SwitchStatement parent, ASTNode child, ASTNode newEntry) {
		int index = parent.statements().indexOf(child);
		if (index != -1) {
			parent.statements().add(index, newEntry);
		} else {
			incompleteConsideration();
		}
	}

	private void insertBeforeChildDoStatement(AST ast,
			DoStatement parent, ASTNode child, ASTNode newEntry) {
		if (child == parent.getBody()) {
			Statement body = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, body, newEntry));
		} else {
			incompleteConsideration();
		}
	}

	private void insertBeforeChildWhileStatement(AST ast,
			WhileStatement parent, ASTNode child, ASTNode newEntry) {
		if (child == parent.getBody()) {
			Statement body = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, body, newEntry));
		} else {
			incompleteConsideration();
		}
	}

	private void insertBeforeChildForStatement(AST ast,
			ForStatement parent, ASTNode child, ASTNode newEntry) {
		if (parent.getBody() == child) {
			Statement old = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, newEntry, old));
		} else if (child instanceof Expression) {
			if (parent.initializers().indexOf(child) != -1) {
				// actually, index must be 0
				// we should not add it in the initializer, 
				// instead, add it before this ForStatement
				insertBefore(ast, parent, newEntry);
			} else if (parent.updaters().indexOf(child) != -1) {
				// actually, index must be 0
				// we should not add it in the updator, 
				// instead, add it at the end of the body
				insertAfter(ast, parent.getBody(), newEntry);
			}
		} else {
			incompleteConsideration();
		}
	}

	/**
	 * child必定不是Block
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	private void insertBeforeChildIfStatement(AST ast,
			IfStatement parent, ASTNode child, ASTNode newEntry) {
		if (parent.getThenStatement() == child) {
			Statement thenStat = parent.getThenStatement();
			parent.setThenStatement(createTempBlock(ast));
			parent.setThenStatement(wrapWithBlock(ast, newEntry, thenStat));
		} else if (parent.getElseStatement() == child) {
			Statement elseStat = parent.getElseStatement();
			parent.setElseStatement(createTempBlock(ast));
			parent.setElseStatement(wrapWithBlock(ast, newEntry, elseStat));
		} else {
			incompleteConsideration();
		}
	}

	/**
	 * 在Block中插入
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void insertBeforeChildBlock(AST ast, 
			Block parent, ASTNode child, ASTNode newEntry) {
		List stats = parent.statements();
		int i = stats.indexOf(child);
		if (i == -1) {
			throw new RuntimeException("Internal error!");
		} else {
			stats.add(i, newEntry);
		}
	}

	/**
	 * 将newEntry插入到point同等级的后面
	 * 例如：
	 * for (int i = 0; i < 10; i++)
	 *   point
	 * 需要转化成
	 * for (int i = 0; i < 10; i++) {
	 *   newEntry
	 *   point
	 * }
	 * 即：newEntry需要跟point在同一个语句块中。不能因为插入语句改变了其语义结构
	 * @param point
	 * @param newEntry
	 */
	@SuppressWarnings("unchecked")
	private void insertAfter(AST ast, ASTNode point, ASTNode newEntry) {
		if (point instanceof Block) {
			Block block = (Block) point;
			block.statements().add(newEntry);
		} else {
			ASTNode parent = point.getParent();
			if (!(parent instanceof Statement)) {
				throw new RuntimeException("Invalid parent type: " + parent.getClass().getName());
			} else {
				insertAfterChild(ast, parent, point, newEntry);
			}
		}
	}

	/**
	 * Insert a statement after a 'child' in 'parent'
	 * 1. child 需要是 parent 的"直接"子节点
	 * 2. child 必定不是 Block, Try 或者 Synchronized
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	private void insertAfterChild(AST ast, ASTNode parent, ASTNode child, ASTNode newEntry) {
		if (parent instanceof Block) {
			insertAfterChildBlock(ast, (Block) parent, child, newEntry);
		} else if (parent instanceof IfStatement) {
			insertAfterChildIfStatement(ast, (IfStatement) parent, child, newEntry);
		} else if (parent instanceof ForStatement) {
			insertAfterChildForStatement(ast, (ForStatement) parent, child, newEntry);
		} else if (parent instanceof WhileStatement) {
			insertAfterChildWhileStatement(ast, (WhileStatement) parent, child, newEntry);
		} else if (parent instanceof DoStatement) {
			insertAfterChildDoStatement(ast, (DoStatement) parent, child, newEntry);
		} else if (parent instanceof SwitchStatement) {
			insertAfterChildSwitchStatement(ast, (SwitchStatement) parent, child, newEntry);
		} else {
			throw new RuntimeException("Invalid parent statement: " + parent.getClass().getName());
		}
	}

	@SuppressWarnings("unchecked")
	private void insertAfterChildSwitchStatement(AST ast,
			SwitchStatement parent, ASTNode child, ASTNode newEntry) {
		int index = parent.statements().indexOf(child);
		if (index != -1) {
			parent.statements().add(index + 1, newEntry);
		} else {
			incompleteConsideration();
		}
	}

	private void insertAfterChildDoStatement(AST ast,
			DoStatement parent, ASTNode child, ASTNode newEntry) {
		if (child == parent.getBody()) {
			Statement body = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, newEntry, body));
		} else {
			incompleteConsideration();
		}
	}

	private void insertAfterChildWhileStatement(AST ast,
			WhileStatement parent, ASTNode child, ASTNode newEntry) {
		if (child == parent.getBody()) {
			Statement body = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, newEntry, body));
		} else {
			incompleteConsideration();
		}
	}

	private void insertAfterChildForStatement(AST ast,
			ForStatement parent, ASTNode child, ASTNode newEntry) {
		if (parent.getBody() == child) {
			Statement old = parent.getBody();
			parent.setBody(createTempBlock(ast));
			parent.setBody(wrapWithBlock(ast, old, newEntry));
		} else if (child instanceof Expression) {
			if (parent.initializers().indexOf(child) != -1) {
				// actually, index must be 0
				// we should not add it in the initializer, 
				// instead, add it at the beginning of the body
				insertBefore(ast, parent.getBody(), newEntry);
			} else if (parent.updaters().indexOf(child) != -1) {
				// actually, index must be 0
				// we should not add it in the updator, 
				// instead, add it after this ForStatement
				insertAfter(ast, parent, newEntry);
			}
		} else {
			incompleteConsideration();
		}
	}

	/**
	 * child必定不是Block
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	private void insertAfterChildIfStatement(AST ast,
			IfStatement parent, ASTNode child, ASTNode newEntry) {
		if (parent.getThenStatement() == child) {
			Statement thenStat = parent.getThenStatement();
			parent.setThenStatement(createTempBlock(ast));
			parent.setThenStatement(wrapWithBlock(ast, thenStat, newEntry));
		} else if (parent.getElseStatement() == child) {
			Statement elseStat = parent.getElseStatement();
			parent.setElseStatement(createTempBlock(ast));
			parent.setElseStatement(wrapWithBlock(ast, elseStat, newEntry));
		} else {
			incompleteConsideration();
		}
	}
	
	/**
	 * 在Block中插入
	 * @param parent
	 * @param child
	 * @param newEntry
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void insertAfterChildBlock(AST ast, 
			Block parent, ASTNode child, ASTNode newEntry) {
		List stats = parent.statements();
		int i = stats.indexOf(child);
		if (i == -1) {
			throw new RuntimeException("Internal error!");
		} else {
			stats.add(i + 1, newEntry);
		}
	}

	/**
	 * 创建一个Block，作为临时占位符
	 * 例如，将 
	 * if (cond) 
	 *   f() 
	 * 替换成
	 * if (cond) 
	 * {
	 *   f()
	 * }
	 * 时，需要先将 f() 取出，此时对于IfStatement又需要一个合法的Statement，所以先用一个零食的Block来替换
	 * @param ast
	 * @return
	 */
	private Block createTempBlock(AST ast) {
		return ast.newBlock();
	}

	/**
	 * 将若干语句用Block包裹住
	 * @param newEntry
	 * @param thenStat
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Block wrapWithBlock(AST ast, ASTNode... stats) {
		Block block = ast.newBlock();
		for (ASTNode s : stats) {
			block.statements().add(s);
		}
		return block;
	}

	/**
	 * Report an incomplete consideration
	 */
	private void incompleteConsideration() {
		throw new RuntimeException("Internal error!");
	}
}
