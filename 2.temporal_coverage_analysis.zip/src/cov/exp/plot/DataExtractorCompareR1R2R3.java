package cov.exp.plot;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DataExtractorCompareR1R2R3 extends AbstractDataExtractor {
	private static final String FILE_RAW_DATA = "./data/results/20140622-185138-comp-r1-r2-r3.txt";
	public static final String FILE_PATH_R1_R2 = "./data/gnuplot/compare123/r1_r2.txt";
	public static final String FILE_PATH_R2_R3 = "./data/gnuplot/compare123/r2_r3.txt";
	public static final String FILE_PATH_R1_R3 = "./data/gnuplot/compare123/r1_r3.txt";
	
	private static final String STR_NOTHING = "[Nothing]";
	
	public static class Triple {
		double r1;
		double r2;
		double r3;
	}
	
	public static void main(String[] args) throws IOException {
		List<Triple> data = new ArrayList<>();
		try (FileInputStream fis = new FileInputStream(FILE_RAW_DATA); 
				Scanner scanner = new Scanner(fis)) {
			while (scanner.hasNext()) {
				Triple t = new Triple();
				// 4 16 6 64 1 1 2 1 50 0.641 0.641 0.641 0.8019396732313537 0.8019396732313537 0.8019396732313537
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				scanner.nextDouble();
				t = parse(scanner.nextLine());
				if (t != null)
					data.add(t);
			}
			ensureFile(FILE_PATH_R1_R2);
			ensureFile(FILE_PATH_R2_R3);
			ensureFile(FILE_PATH_R1_R3);
			FileWriter r1r2 = new FileWriter(FILE_PATH_R1_R2);
			FileWriter r2r3 = new FileWriter(FILE_PATH_R2_R3);
			FileWriter r1r3 = new FileWriter(FILE_PATH_R1_R3);
			for (Triple t : data) {
				r1r2.append("" + t.r1 + " " + t.r2 + "\n");
				r2r3.append("" + t.r2 + " " + t.r3 + "\n");
				r1r3.append("" + t.r1 + " " + t.r3 + "\n");
			}
			r1r2.close();
			r2r3.close();
			r1r3.close();
		}
		System.out.println("OK!");
	}

	private static Triple parse(String line) {
		// sr1 sr2 sr1 ar1 ar2 ar3
		Triple t = new Triple();
		String[] parts = line.trim().split("\\s+");
		
		if (parts[0].equals(STR_NOTHING) || parts[1].equals(STR_NOTHING) || parts[2].equals(STR_NOTHING)) {
			return null;
		} else {
			t.r1 = Double.parseDouble(parts[0]);
			t.r2 = Double.parseDouble(parts[1]);
			t.r3 = Double.parseDouble(parts[2]);
			return t;
		}
	}
}
