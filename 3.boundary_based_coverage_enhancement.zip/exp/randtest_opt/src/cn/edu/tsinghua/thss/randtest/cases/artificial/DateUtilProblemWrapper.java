package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.DateUtil;
import cn.edu.tsinghua.thss.randtest.cases.DateUtilRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class DateUtilProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Integer.class)
				);
		return fp;
	}

	@Override
	public Object invoke(Input input) {
		return DateUtil.isLeapYear((Integer) input.data[0]);
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new DateUtilRuntimeAssist();
	}

}
