package algorithm.test;

import junit.framework.TestCase;
import algorithm.InvHyperbolicSine;

public class InvHyperbolicSineTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T5_7, T9_12, T14_16, T2_3, T12_14]
	public void test00() {
		double x = InvHyperbolicSine.asinh(-5.021295506555762E-5D);
		double y = (-5.021295504445695E-5);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_4, T5_7, T12_13, T9_12]
	public void test01() {
		double x = InvHyperbolicSine.asinh(0.03672715111D);
		double y = (0.03671889934234624);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T5_7, T14_15, T9_12, T2_3, T12_14]
	public void test02() {
		double x = InvHyperbolicSine.asinh(-0.0064001057D);
		double y = (-0.0064000620079739156);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T5_7, T9_11, T2_3]
	public void test03() {
		double x = InvHyperbolicSine.asinh(-0.09895864015422758D);
		double y = (-0.09879783388598967);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T5_6, T2_4]
	public void test04() {
		double x = InvHyperbolicSine.asinh(0.1703724D);
		double y = (0.16955875735014453);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
}
