package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument.skeleton;

import java.util.ArrayList;
import java.util.List;

public class ComposedFormula extends PropFormula {
	public static final byte CONJUNCTION = 1;
	public static final byte DISJUNCTION = 2;
	
	private byte connector;
	private List<PropFormula> subs = new ArrayList<PropFormula>();
	
	public ComposedFormula(byte connector) {
		if (connector != CONJUNCTION && connector != DISJUNCTION) {
			throw new IllegalArgumentException("Invalid connector: " + connector);
		}
		this.connector = connector;
	}
	
	public boolean isConjunction() {
		return (connector == CONJUNCTION);
	}
	
	public boolean isDisjunction() {
		return (connector == DISJUNCTION);
	}
	
	public void addSubFormula(PropFormula formula) {
		subs.add(formula);
	}

	public void addSubFormulas(List<PropFormula> subs) {
		this.subs.addAll(subs);
	}
	
	public List<PropFormula> getSubFormulas() {
		return subs;
	}

	public static byte parseConnector(char c) {
		if (c == '&') {
			return CONJUNCTION;
		} else if (c == '|') {
			return DISJUNCTION;
		} else {
			throw new IllegalArgumentException("unknown connector: " + c);
		}
	}

	public static ComposedFormula createConjunction() {
		return new ComposedFormula(CONJUNCTION);
	}

	public static ComposedFormula createDisjunction() {
		return new ComposedFormula(DISJUNCTION);
	}
}
