package algorithm.test;

import junit.framework.TestCase;
import algorithm.ColdBranchTest;

public class ColdBranchTestTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T2_4]
	public void test00() {
		double x = ColdBranchTest.run(9.900510701240304D);
		double y = (0.0);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_3]
	public void test01() {
		double x = ColdBranchTest.run(10.000000041240435D);
		double y = (10.000000041240435);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T2_4]
	public void test02() {
		double x = ColdBranchTest.run(10.100505D);
		double y = (0.0);
		assertTrue(Math.abs(x - y) < 1e-8 || Math.abs(x - y) < (Math.abs(x) + Math.abs(y)) * 1e-8);
	}
	//<<case-end>>
}
