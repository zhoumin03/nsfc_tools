package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.exporter;

import java.io.IOException;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ActionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.DecisionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge.BranchType;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.extractor.CfgExtractor;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgSimplifier;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.ExpressionUtils;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;


public class GraphvizExporterTest {
	public static void main(String[] args) throws IOException {
		parseAndExportControlFlowGraph();
	}

	
	private static boolean parseAndExportControlFlowGraph() {
		final String filename = "./data/sample/SampleJavaProgram.java";
		final String typename = "SampleJavaProgram";
		final String[] methodnames = new String[] {
				"complexMethod", 
				"testFor",
				"testIf",
				"testCondition",
				};
		
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(FileUtils.readStringFromFile(filename).toCharArray());
		//parser.setSource("/*abc*/".toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
 
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);

		// search for the class
		cu.accept(new ASTVisitor() {
			public boolean visit(TypeDeclaration td) {
				String name = td.getName().getIdentifier();
				if (name.equals(typename)) {
					for (MethodDeclaration md : td.getMethods()) {
						String methodname = md.getName().getIdentifier();
						boolean found = false;
						for (String s : methodnames) {
							if (s.equals(methodname)) {
								found = true;
								break;
							}
						}
						if (found) {
							System.out.println("Found method: " + typename + "." + methodname);
							ControlFlowGraph cfg = CfgExtractor.extractFromMethodDeclaration(
									md.getAST(), md);
							GraphvizExporter ge = new GraphvizExporter();
							try {
								ge.export(cfg, null,
										"./data/exported/cfg/" + typename + "." + methodname + ".dot", 
										typename + "." + methodname, 
										true
										);
							} catch (IOException e) {
								e.printStackTrace();
							}
							// simplify and reduce
							CfgSimplifier.removeUnreachableBlocks(cfg);
							CfgSimplifier.removeEmptyBlocks(md.getAST(), cfg);
							try {
								ge.export(cfg, null,
										"./data/exported/cfg/" + typename + "." + methodname + ".simplified.dot", 
										typename + "." + methodname, 
										true
										);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				return true;
			}
		});
		
		return true;
	}

	@SuppressWarnings("unused")
	private static void dealWithMethod(MethodDeclaration method) {
		Block body = method.getBody();
		for (Object o: body.statements()) {
			System.out.println("---");
			Statement stat = (Statement) o;
			System.out.println(stat.toString());
		}
	}

	private static ControlFlowGraph generateControlFlowGraph() {
		// ENTRY -> B1 -(E)-> B2 -> B3 -> EXIT
		//          |-----(not E) --^
		AST ast = AST.newAST(AST.JLS3);
		Expression condition = ExpressionUtils.createBooleanLiteral(ast, true);
		
		BasicBlock entry = BasicBlock.newActionBlock();
		DecisionBlock bb1 = BasicBlock.newDecisionBlock(condition, null);
		ActionBlock bb2 = BasicBlock.newActionBlock();
		ActionBlock b3 = BasicBlock.newActionBlock();
		BasicBlock exit = BasicBlock.newActionBlock();
		
		CfgUtils.concatenate(entry, bb1);
		CfgUtils.concatenate(bb1, bb2, BranchType.TRUE_BRANCH);
		CfgUtils.concatenate(bb2, b3);
		CfgUtils.concatenate(bb1, b3, BranchType.FALSE_BRANCH);
		CfgUtils.concatenate(b3, exit);
		
		// b2:
		// x = 100;
		Assignment a = ast.newAssignment();
		a.setLeftHandSide(ast.newSimpleName("x"));
		a.setOperator(Assignment.Operator.ASSIGN);
		a.setRightHandSide(ast.newNumberLiteral("100"));
		// b3:
		// y = x + 1;
		// x = 2 * x;
		Assignment b = ast.newAssignment();
		b.setLeftHandSide(ast.newSimpleName("y"));
		b.setOperator(Assignment.Operator.ASSIGN);
		b.setRightHandSide(ExpressionUtils.createInfixExpression(ast, 
				InfixExpression.Operator.PLUS, 
				ast.newSimpleName("x"), 
				ast.newNumberLiteral("1")));
		Assignment c = ast.newAssignment();
		c.setLeftHandSide(ast.newSimpleName("x"));
		c.setOperator(Assignment.Operator.ASSIGN);
		c.setRightHandSide(ExpressionUtils.createInfixExpression(ast, 
				InfixExpression.Operator.TIMES, 
				ast.newNumberLiteral("2"), 
				ast.newSimpleName("x")));
		
		bb2.addStatement(ast.newExpressionStatement(b));
		bb2.addStatement(ast.newExpressionStatement(c));
		
		ControlFlowGraph cfg = new ControlFlowGraph(entry, exit);
		return cfg;
	}
	
	@SuppressWarnings("unused")
	private static boolean exportGenerateControlFlowGraph() {
		ControlFlowGraph cfg = generateControlFlowGraph();
		
		GraphvizExporter ge = new GraphvizExporter();
		boolean status;
		try {
			status = ge.export(cfg, null,
					"./data/exported/cfg/1.dot", "-test()", true);
		} catch (IOException e) {
			e.printStackTrace();
			status = false;
		}
		return status;
	}
}
