package cov.exp.algorithm;

import java.util.Arrays;
import java.util.Set;

public class AlgorithmBase {
	protected double weave(int n, double[] x, double[] y) {
		double sum = 0;
		for (int i = 0; i < n; i++) {
			sum += x[i] * y[i];
		}
		return sum;
	}

	/**
	 * A event (e.g. detecting a bug) can be triggered at each vertex j with the probability q[j]
	 * This funciton computes the probability that the event is triggered at least once in M steps.
	 * @param M
	 * @param ap
	 * @return
	 */
	public double triggerProb(int M, AbstractProblem ap) {
		boolean[] forbidden = new boolean[ap.n];
		Arrays.fill(forbidden, false);
		return triggerProb(M, ap, forbidden);
	}

	/**
	 * A event (e.g. detecting a bug) can be triggered at each vertex j with the probability q[j]
	 * This funciton computes the probability that the event is triggered at least once in M steps
	 * under the condition that:
	 * 
	 * -- Non of the a forbidden vertex is EVER reached --
	 * 
	 * i.e., P(bug_detected /\ no_forbidden_vertex_reached)
	 * 
	 * @param M
	 * @param ap
	 * @return
	 */
	public double triggerProb(int M, AbstractProblem ap, boolean[] forbidden) {
		// cy[i] : current locatin = v_i, and the event is already triggered
		// cn[i] : current locatin = v_i, and the event is not yet triggered
		// cy[i] + cn[i] : current locatin = v_i
		double[] cy = new double[ap.n];
		double[] cn = new double[ap.n];
		for (int i = 0; i < ap.n; i++) {
			if (forbidden[i]) {
				cy[i] = 0;
				cn[i] = 0;
			} else {
				cy[i] = ap.init[i] * ap.q[i];
				cn[i] = ap.init[i] * (1 - ap.q[i]);
			}
		}
		double[] ncy = new double[ap.n];
		double[] ncn = new double[ap.n];
		for (int k = 1; k <= M; k++) {
			for (int i = 0; i < ap.n; i++) {
				ncy[i] = 0;
				ncn[i] = 0;
				if (forbidden[i])
					continue;
				for (int j = 0; j < ap.n; j++) {
					ncy[i] += cy[j] * ap.p[j][i] + cn[j] * ap.p[j][i] * ap.q[i];
					ncn[i] += cn[j] * ap.p[j][i] * (1 - ap.q[i]);
				}
			}
			// switch them instead of create a new one, to avoid garbage collection
			double[] temp;
			temp = ncy; ncy = cy; cy = temp;
			temp = ncn; ncn = cn; cn = temp;
			// now, cy and cn are the most recent value.
		}
		
		double prob = 0;
		for (int i = 0; i < ap.n; i++) {
			prob += cy[i];
		}
		
		// good for garbage collection.
		cy = cn = ncy = ncn = null;
		
		return prob;
	}

	/**
	 * The probability that a path ever reaches at least one of the bins in T
	 * @param oap
	 * @param t
	 * @return
	 */
	public double reachProb(int M, AbstractProblem oap, Set<Integer> T) {
		boolean[] bm = new boolean[oap.n];
		for (Integer t : T) {
			bm[t] = true;
		}
		return reachProb(M, oap, bm);
	}

	/**
	 * The probability that a path ever reaches at least one of the bins in T
	 * @param oap
	 * @param t
	 * @return
	 */
	public double reachProb(int M, AbstractProblem oap, boolean[] T) {
		// first, compute the probability that none of the vertex is T is reached
		// set the probability q to 1 for every vertex
		AbstractProblem nap = new AbstractProblem();
		nap.n = oap.n;
		nap.init = oap.init;
		nap.p = oap.p;
		nap.q = new double[nap.n];
		for (int i = 0; i < nap.n; i++) {
			nap.q[i] = 1;
		}
		return (1 - triggerProb(M, nap, T));
	}

}
