package cn.edu.tsinghua.thss.randtest.rt.invoker;

import java.util.ArrayList;
import java.util.List;

import cn.edu.tsinghua.thss.randtest.rt.variation.Generator;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.TypeDef;

@SuppressWarnings("rawtypes")
public class FormalParameter {
	private List<Generator> generators;
	
	public FormalParameter() {
		generators = new ArrayList<Generator>();
	}
	
	public void addParameter(Generator generator) {
		generators.add(generator);
	}
	
	public int size() {
		return generators.size();
	}
	
	public Generator getGenerator(int idx) {
		return generators.get(idx);
	}

	/**
	 * 可以一个个加，也可以一起设定
	 * @param types
	 */
	public void setParameters(TypeDef ...types) {
		generators.clear();
		for (TypeDef td : types) {
			Generator g = GeneratorFactory.getInstance(td);
			if (g == null) {
				throw new IllegalArgumentException("no generator is registered for " + td);
			}
			generators.add(g);
		}
	}
	
}
