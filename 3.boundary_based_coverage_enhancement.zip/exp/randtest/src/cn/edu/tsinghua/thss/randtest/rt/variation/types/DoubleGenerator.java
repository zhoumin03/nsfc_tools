package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;


public class DoubleGenerator extends AbstractGenerator<Double> {
//	private static final double BIASED_DOUBLE_STD = 100000000.0;

	public void registerSpecials() {
		registerSpecial((double) 0);
		registerSpecial((double) 1);
		registerSpecial((double) -1);
		registerSpecial((double) 0.1);
		registerSpecial((double) -0.1);
	}
	
	@Override
	public Double nextRandom() {
		return rand.nextDouble();
	}

	@Override
	public Double nextBiasedRandom() {
		// NOTE: because Math.pow treats value larger than 1E308 as Infinity
		// the exponent here is maximized at Float.MAX_EXPONENT instead of Double.MAX_EXPONENT
		return (rand.nextDouble() - 0.5) * 2 * 
				Math.pow(10, logBiasedDouble(Float.MAX_EXPONENT));
	}

	@Override
	public Double nextNeighbour(Double current, double scale) {
		double maxDelta, delta;
		if (rand.nextBoolean()) {
			// scale, 10 percent difference
			maxDelta = (double) (current * 0.1 * scale);
		} else {
			// offset
			maxDelta = 1 * scale;
		}
		delta = (double) (maxDelta * (rand.nextFloat() - 0.5) / 0.5);
		return (double) (current + delta);
	}

	@Override
	public Double copy(Double origin) {
		return Double.valueOf(origin.doubleValue());
	}

	@Override
	public Double[] allNeighbours(Double current, double scale) {
		double maxDelta, delta;
		if (rand.nextBoolean()) {
			// scale, 10 percent difference
			maxDelta = (double) (current * 0.1 * scale);
		} else {
			// offset
			maxDelta = 1 * scale;
		}
		double length = rand.nextDouble();
		delta = (maxDelta * length);
		return new Double[] { current - delta, current + delta, round(current - delta), round(current + delta)};
	}

	private double round(double x) {
		boolean negative = (x < 0);
		x = Math.abs(x);
		// 指数部分
		double exponent = Math.pow(10, Math.floor(Math.log10(x)));
		// 去除指数部分
		x = x / exponent;
		// 对科学计数法的常数项进行四舍五入，选取6到10位有效数字
		double shift = Math.pow(10, rand.nextInt(10 - 6) + 6);
		x = Math.round(x * shift) / shift;
		// 恢复指数部分
		x = x * exponent;
		return negative ? -x : x;
	}
	
}
