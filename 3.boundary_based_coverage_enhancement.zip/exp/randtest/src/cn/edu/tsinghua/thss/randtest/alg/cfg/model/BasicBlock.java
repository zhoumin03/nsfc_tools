package cn.edu.tsinghua.thss.randtest.alg.cfg.model;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.Statement;

/**
 * An basic block
 * BB contains only basic statements
 * 
 * 一个BB无外乎以下4种情况：
 * 1. ENTRY or EXIT
 * 2. Other empty node
 * 3. Decision Node
 * 4. Action Node
 * 
 * 经过CfgSimplifier之后，应该不存在2的情况
 * 
 * ENTRY: 0in, 1out
 * EXIT: 1in, 0out
 * @author aleck
 *
 */
public abstract class BasicBlock {
	/**
	 * Return a new empty action block
	 * @return
	 */
	public static ActionBlock newActionBlock() {
		return new ActionBlock();
	}
	
	/**
	 * Return a new decision block with condition and source
	 * @return
	 */
	public static DecisionBlock newDecisionBlock(
			Expression condition, 
			Statement source) {
		return new DecisionBlock(condition, source);
	}
	
	/**
	 * Return a new empty decision block
	 * @return
	 */
	public static DecisionBlock newDecisionBlock() {
		return new DecisionBlock();
	}
	
	private List<Edge> inEdges;
	private List<Edge> outEdges;
	
	protected BasicBlock() {
		this.inEdges = new ArrayList<Edge>();
		this.outEdges = new ArrayList<Edge>();
	}
	
	public void addEdge(Edge edge) {
		if (edge.getSrc() == this) {
			if (!acceptOutEdgeType(edge)) {
				throw new IllegalArgumentException("unacceptable out edge type: " + edge);
			}
			outEdges.add(edge);
		} else if (edge.getDest() == this) {
			inEdges.add(edge);
		} else {
			throw new IllegalArgumentException("this edge is not connected to this basic block");
		}
	}
	
	/**
	 * 检查是否可以加入这一类的出边
	 * 比如ActionBlock只能加入NON_CONDITIONAL的边
	 * 比如DecisionBlock只能加入TRUE或者FALSE的边
	 */
	protected abstract boolean acceptOutEdgeType(Edge edge);

	public List<Edge> getInEdges() {
		return inEdges;
	}
	
	public List<Edge> getOutEdges() {
		return outEdges;
	}
	
	public List<BasicBlock> getInBlocks() {
		List<BasicBlock> inBlocks = new ArrayList<BasicBlock>();
		for (Edge e : inEdges) {
			inBlocks.add(e.getSrc());
		}
		return inBlocks;
	}
	
	public List<BasicBlock> getOutBlocks() {
		List<BasicBlock> outBlocks = new ArrayList<BasicBlock>();
		for (Edge e : outEdges) {
			outBlocks.add(e.getDest());
		}
		return outBlocks;
	}

	public int getOutDegree() {
		return outEdges.size();
	}

	public int getInDegree() {
		return inEdges.size();
	}

	public void removeOutEdge(Edge e) {
		outEdges.remove(e);
	}

	public void removeInEdge(Edge e) {
		inEdges.remove(e);
	}

	/**
	 * Empty block contains no statement
	 * @return
	 */
	public boolean isEmptyActionBlock() {
		return (isActionBlock() && ((ActionBlock)this).isEmpty());
	}

	/**
	 * Empty block contains SOME statement
	 * @return
	 */
	public boolean isActionBlock() {
		return (this instanceof ActionBlock);
	}

	/**
	 * Empty block contains some out edge that has condition labeled
	 * @return
	 */
	public boolean isDecisionBlock() {
		return (this instanceof DecisionBlock);
	}
	
	/**
	 * 追溯到产生这个Block的语句
	 * 1. 如果是Decision，则返回条件判断所在的语句(While/If/For/Do/SwitchCase)
	 * 2. 如果是Action，则返回statements里面的第一个语句
	 * @return
	 */
	public abstract ASTNode sourceBackToASTNode();
	
	/**
	 * return short string
	 */
	@Override
	public String toString() {
		return strRepr();
	}

	/**
	 * 返回一个简短的String表示
	 * @return
	 */
	protected abstract String strRepr();
}
