package cov.exp.plot;

import java.io.File;
import java.io.IOException;

abstract public class AbstractDataExtractor {
	protected static void ensureFile(File file) throws IOException {
		File dir = file.getParentFile();
		if (!dir.exists())
			dir.mkdirs();
		if (!file.exists())
			file.createNewFile();
	}

	protected static void ensureFile(String path) throws IOException {
		ensureFile(new File(path));
	}
}
