package algorithm.test;

import java.util.Arrays;
import junit.framework.TestCase;
import algorithm.HeapSort;

public class HeapSortTest extends TestCase {
	//--lines starts with '//--' are ommited
		//--$c: comment
		//--$$: case id
		//--$_: the expected return value
		//--$n: the n-th parameter
		//--always use with brackets to avoid ambiguity
		//--contents between <<case-begin>> and <<case-end>> are a single case
		
		//<<case-begin>>
		//#0, coverages: [T5_7, T12_15, T2_3, T24_16, T25_27, T19_24, T11_13, T6_9, T19_23, T14_8, T24_26, T26_28, T17_8, T11_14]
	public void test00() {
		Object[] data = (Object[]) (new java.lang.Object[]{2328937, 122510, -23, 0, -2});
		int[] a = new int[data.length];
		int[] b = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
			b[i] = (Integer) data[i];
		}
		HeapSort.sort(a);
		Arrays.sort(b);
		assertEquals(a.length, b.length);
		for (int i = 0; i < a.length; i++) {
			assertEquals(a[i],  b[i]);
		}
	}
		//<<case-end>>
		//<<case-begin>>
		//#1, coverages: [T17_21, T5_7, T12_15, T2_3, T14_18, T24_16, T25_27, T19_24, T11_13, T6_9, T18_22, T18_8, T19_23, T14_8, T24_26, T26_16, T11_14]
	public void test01() {
		Object[] data = (Object[]) (new java.lang.Object[]{-2147483648, -2147483648, 637282600, 1, 42892, -24});
		int[] a = new int[data.length];
		int[] b = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			a[i] = (Integer) data[i];
			b[i] = (Integer) data[i];
		}
		HeapSort.sort(a);
		Arrays.sort(b);
		assertEquals(a.length, b.length);
		for (int i = 0; i < a.length; i++) {
			assertEquals(a[i],  b[i]);
		}
	}
		//<<case-end>>
}
