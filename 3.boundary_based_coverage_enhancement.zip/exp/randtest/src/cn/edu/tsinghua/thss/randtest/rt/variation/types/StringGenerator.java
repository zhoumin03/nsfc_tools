package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.Generator;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.BasicTypeDef;

public class StringGenerator extends AbstractGenerator<String> {
	public static final int MAX_STRING_LENGTH = 10;

	private Generator<Character> element = null;
	
	@SuppressWarnings("unchecked")
	private void ensureCharGenerator() {
		if (element == null) {
			element = GeneratorFactory.getInstance(new BasicTypeDef(Character.class));
			if (element == null) {
				throw new RuntimeException("String generator relies on char generator, which is not found!");
			}
		}
	}
	
	@Override
	public String nextRandom() {
		int length = rand.nextInt(MAX_STRING_LENGTH);
		ensureCharGenerator();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			sb.append(element.nextByPolicy());
		}
		return sb.toString();
	}

	@Override
	public String nextBiasedRandom() {
		return nextRandom();
	}

	@Override
	public String nextNeighbour(String current, double scale) {
		if (current != null && current.length() > 0) {
			switch (rand.nextInt(3)) {
			case 0:
				return neighbourByEditingAnElement(current);
			case 1:
				return neighbourByAddingAnElement(current);
			case 2:
				return neighbourByRemovingAnElement(current);
			}
			// impossible code
			return null;
		} else {
			return neighbourByAddingAnElement(current);
		}
	}

	@Override
	public String[] allNeighbours(String current, double scale) {
		if (current != null && current.length() > 0) {
			String[] ret = new String[9];
			// generate 9 neighbours
			ret[0] = neighbourByAddingAnElement(current);
			ret[1] = neighbourByAddingAnElement(current);
			ret[2] = neighbourByAddingAnElement(current);
			ret[3] = neighbourByEditingAnElement(current);
			ret[4] = neighbourByEditingAnElement(current);
			ret[5] = neighbourByEditingAnElement(current);
			ret[6] = neighbourByRemovingAnElement(current);
			ret[7] = neighbourByRemovingAnElement(current);
			ret[8] = neighbourByRemovingAnElement(current);
			return ret;
		} else {
			String[] ret = new String[3];
			ret[0] = neighbourByAddingAnElement(current);
			ret[1] = neighbourByAddingAnElement(current);
			ret[2] = neighbourByAddingAnElement(current);
			return ret;
		}
	}

	@Override
	public String copy(String origin) {
		if (origin == null) {
			return null;
		} else {
			return new String(origin);
		}
	}

	private String neighbourByEditingAnElement(String current) {
		ensureCharGenerator();
		StringBuilder sb = new StringBuilder();
		int idx = rand.nextInt(current.length());
		for (int i = 0; i < idx; i++) {
			sb.append(current.charAt(i));
		}
		sb.append(element.nextNeighbour(current.charAt(idx), 1));
		for (int i = idx + 1; i < current.length(); i++) {
			sb.append(current.charAt(i));
		}
		return sb.toString();
	}

	private String neighbourByAddingAnElement(String current) {
		ensureCharGenerator();
		StringBuilder sb = new StringBuilder();
		if (current == null) {
			sb.append(element.nextByPolicy());
			return sb.toString();
		} else {
			int idx = rand.nextInt(current.length() + 1);
			for (int i = 0; i < idx; i++) {
				sb.append(current.charAt(i));
			}
			sb.append(element.nextByPolicy());
			for (int i = idx; i < current.length(); i++) {
				sb.append(current.charAt(i));
			}
			return sb.toString();
		}
	}

	private String neighbourByRemovingAnElement(String current) {
		ensureCharGenerator();
		StringBuilder sb = new StringBuilder();
		int idx = rand.nextInt(current.length());
		for (int i = 0; i < idx; i++) {
			sb.append(current.charAt(i));
		}
		for (int i = idx; i + 1 < current.length(); i++) {
			sb.append(current.charAt(i + 1));
		}
		return sb.toString();
	}

	@Override
	protected void registerSpecials() {
		registerSpecial(null);
		registerSpecial("");
		registerSpecial("a");
		registerSpecial("1");
	}

}
