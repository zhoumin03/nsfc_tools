package algorithm.test;

import java.util.Arrays;

import junit.framework.TestCase;
import algorithm.BinarySearch;

public class BinarySearchTest extends TestCase {
	//--lines starts with '//--' are ommited
		//--$c: comment
		//--$$: case id
		//--$_: the expected return value
		//--$n: the n-th parameter
		//--always use with brackets to avoid ambiguity
		//--contents between <<case-begin>> and <<case-end>> are a single case
		
		//<<case-begin>>
		//#0, coverages: [T2_4]
		public void test00() {
			Object[] data = (Object[]) (new java.lang.Object[]{-843890, 4542503, -213311, 1, 1280336, -2715787, -2147483648, 881532});
			int[] a = new int[data.length];
			for (int i = 0; i < data.length; i++) {
				a[i] = (Integer) data[i];
			}
			int fromIndex = (int) (-1);
			int toIndex = (int) (-1);
			int key = (int) (-8170);
			assertEquals((0), BinarySearch.binarySearch(a, fromIndex, toIndex, key));
		}
		//<<case-end>>
		//<<case-begin>>
		//#1, coverages: [T5_8, T5_7, T8_10, T2_3]
		public void test01() {
			Object[] data = (Object[]) (new java.lang.Object[]{-1, -2876, 377211, 405258462, 190096, 660471, 2147483647, -1, -43, 2147483647});
			int[] a = new int[data.length];
			for (int i = 0; i < data.length; i++) {
				a[i] = (Integer) data[i];
			}
			int fromIndex = (int) (0);
			int toIndex = (int) (10);
			int key = (int) (2147483647);
			assertEquals((9), BinarySearch.binarySearch(a, fromIndex, toIndex, key));
		}
		//<<case-end>>
		//<<case-begin>>
		//#2, coverages: [T5_8, T8_9, T5_7, T2_3]
		public void test02() {
			Object[] data = (Object[]) (new java.lang.Object[]{-60532, 3, -4, -293846748, 1, -10});
			int[] a = new int[data.length];
			for (int i = 0; i < data.length; i++) {
				a[i] = (Integer) data[i];
			}
			int fromIndex = (int) (0);
			int toIndex = (int) (2);
			int key = (int) (1);
			assertEquals((-2), BinarySearch.binarySearch(a, fromIndex, toIndex, key));
		}
		//<<case-end>>
}
