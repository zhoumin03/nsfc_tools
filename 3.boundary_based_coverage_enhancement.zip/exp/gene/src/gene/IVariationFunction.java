package gene;

import java.util.List;

public interface IVariationFunction {
	public List<ISolution> evolve(ISolution chromosmoe, double temperature);
}
