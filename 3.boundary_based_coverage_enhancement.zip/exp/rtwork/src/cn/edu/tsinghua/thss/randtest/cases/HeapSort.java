package cn.edu.tsinghua.thss.randtest.cases;

import java.util.Arrays;
import java.util.Random;
import cn.edu.tsinghua.thss.randtest.rt.RT;

public class HeapSort {
	private static void swap(int[] a, int l, int r) {
		int temp = a[l];
		a[l] = a[r];
		a[r] = temp;
	}
	
	public static void sort(int[] a) {
		RT.startInvocation(5413048718465083392L);
		RT.track(1);
		// put into a max-heap
		int i = (a.length - 1) / 2;
		RT.track(2);
		while (((RT.b(0)) && (RT.ge(0, i, 0))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			int j = i;
			RT.track(5);
			// stack = a[0, ..., i), i is the bound
			while (((RT.b(1)) && (RT.lt(0, j, a.length))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(7);
				int lchild = (j << 1) + 1;
				int rchild = (j << 1) + 2;
				RT.track(11);
				if (((RT.b(3)) && (((RT.lt(0, lchild, a.length)) && (RT.lt(1,
						rchild, a.length))))) && (RT.e(3))) {
					RT.pd(3);
					RT.track(13);
					int largerChild = (a[lchild] > a[rchild] ? lchild : rchild);
					RT.track(17);
					if (((RT.b(6)) && (RT.lt(0, a[j], a[largerChild])))
							&& (RT.e(6))) {
						RT.pd(6);
						RT.track(21);
						swap(a, j, largerChild);
						j = largerChild;
					} else {
						RT.nd(6);
						break;
					}
				} else {
					RT.nd(3);
					RT.track(14);
					if (((RT.b(5)) && (RT.lt(0, lchild, a.length))) && (RT.e(5))) {
						RT.pd(5);
						RT.track(18);
						// now, rchild >= bound
						if (((RT.b(7)) && (RT.lt(0, a[j], a[lchild]))) && (RT.e(7))) {
							RT.pd(7);
							RT.track(22);
							swap(a, j, lchild);
							j = lchild;
						} else {
							RT.nd(7);
							break;
						}
					} else {
						RT.nd(5);
						// both are out of bound
						break;
					}
				}
			}
			RT.nd(1);
			RT.track(8);
			i--;
		}
		RT.nd(0);
		RT.track(4);
		RT.track(6);
		// sort
		for (i = a.length - 1; ((RT.b(2)) && (RT.gt(0, i, 0))) && (RT.e(2)); i--) {
			RT.pd(2);
			RT.track(9);
			// 1. take out the current max
			int currentMax = a[0];
			// 2. put the last element into top and regulate
			a[0] = a[i];
			int j = 0;
			RT.track(12);
			// stack = a[0, ..., i), i is the bound
			while (((RT.b(4)) && (RT.lt(0, j, i))) && (RT.e(4))) {
				RT.pd(4);
				RT.track(15);
				int lchild = (j << 1) + 1;
				int rchild = (j << 1) + 2;
				RT.track(19);
				if (((RT.b(8)) && (((RT.lt(0, lchild, i)) && (RT.lt(1, rchild, i)))))
						&& (RT.e(8))) {
					RT.pd(8);
					RT.track(23);
					int largerChild = (a[lchild] > a[rchild] ? lchild : rchild);
					RT.track(25);
					if (((RT.b(10)) && (RT.lt(0, a[j], a[largerChild])))
							&& (RT.e(10))) {
						RT.pd(10);
						RT.track(27);
						swap(a, j, largerChild);
						j = largerChild;
					} else {
						RT.nd(10);
						break;
					}
				} else {
					RT.nd(8);
					RT.track(24);
					if (((RT.b(9)) && (RT.lt(0, lchild, i))) && (RT.e(9))) {
						RT.pd(9);
						RT.track(26);
						// now, rchild >= bound
						if (((RT.b(11)) && (RT.lt(0, a[j], a[lchild]))) && (RT.e(11))) {
							RT.pd(11);
							RT.track(28);
							swap(a, j, lchild);
							j = lchild;
						} else {
							RT.nd(11);
							break;
						}
					} else {
						RT.nd(9);
						// both are out of bound
						break;
					}
				}
			}
			RT.nd(4);
			RT.track(16);
			a[i] = currentMax;
			RT.track(20);
		}
		RT.nd(2);
	}
	
	public static void main(String[] args) {
		final int len = 100;
		final int[] a = new int[len];
		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			a[i] = rand.nextInt(100);
		}
		System.out.println(Arrays.toString(a));
		sort(a);
		for (int i = 0; i + 1 < a.length; i++) {
			if (a[i] > a[i + 1]) {
				System.out.println("error at index=" + i);
			}
		}
		System.out.println(Arrays.toString(a));
	}
}
