package gene;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import randtest.PathFitness;

/**
 * 保存fitness最高的n个解
 * @author aleck
 *
 */
public class TopNSolutionSet {
	private int size;
	private TreeSet<SolEntry> entries;
	
	public TopNSolutionSet(int size, IFitnessFunc fitness) {
		this.size = size;
		entries = new TreeSet<SolEntry>();
	}
	
	public void addSolEntry(SolEntry entry) {
		if (entries.size() < size || entry.fitness.compareTo(entries.last().fitness) < 0) {
			System.out.println("added to population.");
			entries.add(entry);
			if (entries.size() > size) {
				SolEntry elim = entries.pollLast();
				System.out.println("eliminated: " + elim.toString());
			}
		} else {
			System.out.println("ignored.");
		}
	}
	
	public void addSolution(ISolution c, IFitnessFunc ff) {
		System.out.println("new solution: " + c.toString());
		
		IFitnessValue fitness = ff.eval(c);
		
		SolEntry entry = new SolEntry();
		entry.solution = c;
		entry.fitness = fitness;
		
		System.out.println("fitness=" + fitness.toString());

		addSolEntry(entry);
	}

	public List<ISolution> getSolutions() {
		List<ISolution> solutions = new ArrayList<ISolution>();
		
		for (SolEntry e : entries) {
			solutions.add(e.solution);
		}
		
		return solutions;
	}

	public Iterable<SolEntry> listEntries() {
		return entries;
	}
	
	public SolEntry getBestFitEntry() {
		return entries.first();
	}
}
