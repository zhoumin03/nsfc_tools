package cn.edu.tsinghua.thss.randtest.alg.cfg.instrument;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
import org.eclipse.jdt.internal.formatter.DefaultCodeFormatter;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.text.edits.TextEdit;

import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.FileUtils;

/**
 * Export AST to Java program with instrumented code
 * @author aleck
 *
 */
public class JavaExporter {
	public static boolean exportToFile(String filename, ASTNode node) throws IOException {
		if (FileUtils.createFile(filename)) {
			FileOutputStream fos = new FileOutputStream(filename);
			fos.write(node.toString().getBytes());
			fos.close();
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Format the source code
	 * @param outputFilename
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static boolean format(String filename) {
		try {
			Map options = new HashMap();
			options.put(CompilerOptions.OPTION_Compliance, 
					CompilerOptions.VERSION_1_6);
			options.put(CompilerOptions.OPTION_TargetPlatform, 
					CompilerOptions.VERSION_1_6);
			options.put(CompilerOptions.OPTION_Source, 
					CompilerOptions.VERSION_1_6);
			DefaultCodeFormatter formatter = new DefaultCodeFormatter(null, options);
			String source = FileUtils.readStringFromFile(filename);
			TextEdit edit = formatter.format(DefaultCodeFormatter.K_COMPILATION_UNIT, 
					source, 
					0, source.length(), 
					0,
					null);
			IDocument doc = new Document(source);
			edit.apply(doc);
			source = doc.get();
			FileUtils.writeStringToFile(filename, source);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
