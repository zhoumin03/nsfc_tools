package cn.edu.tsinghua.thss.randtest.alg.cfg.model;

import java.util.NoSuchElementException;

/**
 * ENTRY: contains 0 in edge and 1 out edge
 * EXIT:  contains 1 in edge and 0 out edge
 * @author aleck
 *
 */
public class ControlFlowGraph {
	
	private BasicBlock entry;
	private BasicBlock exit;
	
	public ControlFlowGraph(BasicBlock entry, BasicBlock exit) {
		this.entry = entry;
		this.exit = exit;
	}
	
	public void setEntry(BasicBlock entry) {
		this.entry = entry;
	}

	public void setExit(BasicBlock exit) {
		this.exit = exit;
	}

	public BasicBlock getEntry() {
		return entry;
	}
	
	public BasicBlock getExit() {
		return exit;
	}

	/**
	 * ENTRY -> b1 -> b2 -> b3 -> EXIT
	 * this will return b1
	 */
	public BasicBlock getBasicBlockAfterEntry() {
		if (!hasValidEntry()) {
			throw new NoSuchElementException("no valid entry");
		} else {
			return entry.getOutEdges().get(0).getDest();
		}
	}
	
	/**
	 * ENTRY -> b1 -> b2 -> b3 -> EXIT
	 * this will return b3
	 */
	public BasicBlock getBasicBlockBeforeExit() {
		if (!hasValidExit()) {
			throw new NoSuchElementException("no valid exit");
		} else {
			return exit.getInEdges().get(0).getSrc();
		}
	}
	
	public boolean hasValidEntry() {
		return entry != null && 
				entry.getInDegree() == 0 && entry.getOutDegree() == 1;
	}
	
	public boolean hasValidExit() {
		return exit != null && 
				exit.getOutDegree() == 0 && exit.getInDegree() == 1;
	}
}
