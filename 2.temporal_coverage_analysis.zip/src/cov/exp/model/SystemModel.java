package cov.exp.model;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import cov.exp.algorithm.ExpParameter;


/**
 * The system model consists of:
 * 
 * (1) concrete state transition graph; 
 * (2) abstract coverage model (bins);
 * 
 * @author aleck
 *
 */
public class SystemModel {
	public ExpParameter params;
	public int numOfStates;
	public int numOfInputPatterns;
	public int numOfBins;
	
	// the set of initial states
	public final List<State> initials;
	public State[] states;
	public Bin[] bins;
	
	public SystemModel() {
		initials = new ArrayList<State>();
		// other fields are set by SystemGenerator
	}
	
	public void addInitial(State s) {
		s.initial = true;
		initials.add(s);
	}
	
	/**
	 * display the content of system model to a print stream
	 * @param ps
	 */
	public void display(PrintStream ps) {
		ps.println("-- System Model --");
		ps.println("input-pins: " + params.nInputPins);
		ps.println("flip-flops: " + params.nFlipflops);
		ps.println("#input-patterns: " + numOfInputPatterns);
		ps.println("#state: " + numOfStates);
		ps.println("#bins: " + numOfBins);
		ps.println("-- States --");
		for (int i = 0; i < numOfStates; i++) {
			State s = states[i];
			ps.print("S" + (s.flipflops) + " (" + binary(s.flipflops, params.nInputPins) + ")");
			ps.print(" B[" + s.bin.id() + "]");
			if (s.initial)
				ps.print("i");
			if (s.bug)
				ps.print("*");
			ps.println();
		}
		ps.println("-- Transitions --");
		for (int i = 0; i < numOfStates; i++) {
			State src = states[i];
			for (int j = 0; j < src.transitions.length; j++) {
				State dst = src.transitions[j];
				ps.println("S" + src.flipflops + " (" + binary(j, params.nInputPins) + ")--> " + "S" + dst.flipflops);
			}
		}
		ps.println("-- END --");
	}

	private String binary(int flipflops, int size) {
		String s = Integer.toBinaryString(flipflops);
		StringBuilder sb = new StringBuilder();
		for (int i = s.length(); i < size; i++) {
			sb.append('0');
		}
		sb.append(s);
		return sb.toString();
	}
}
