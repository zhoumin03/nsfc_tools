package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class InputModifier {
	/**
	 * 随机生成一个新的
	 * @param fp
	 * @return
	 */
	public static Input generateByPolicy(FormalParameter fp) {
		Input input = new Input(fp);
		for (int i = 0; i < fp.size(); i++) {
			input.data[i] = fp.getGenerator(i).nextByPolicy();
		}
		return input;
	}

	/**
	 * 随机生成一个新的
	 * @param fp
	 * @return
	 */
	public static Input generateByRandom(FormalParameter fp) {
		Input input = new Input(fp);
		for (int i = 0; i < fp.size(); i++) {
			input.data[i] = fp.getGenerator(i).nextRandom();
		}
		return input;
	}
	
	/**
	 * 随机生成一个新的(Biased)
	 * @param fp
	 * @return
	 */
	public static Input generateByBiasedRandom(FormalParameter fp) {
		Input input = new Input(fp);
		for (int i = 0; i < fp.size(); i++) {
			input.data[i] = fp.getGenerator(i).nextBiasedRandom();
		}
		return input;
	}
	
	/**
	 * 复制一份
	 * @param input
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Input copy(Input origin) {
		FormalParameter fp = origin.fp;
		Input input = new Input(fp);
		for (int i = 0; i < origin.fp.size(); i++) {
			input.data[i] = fp.getGenerator(i).copy(origin.data[i]);
		}
		return input;
	}
	
	@SuppressWarnings("unchecked")
	public static void copyField(Input src, Input dest, int idx) {
		if (src.fp != dest.fp) {
			throw new IllegalArgumentException("invalid copyField call, src.fp != dest.fp.");
		} else {
			FormalParameter fp = src.fp;
			if (idx > fp.size()) {
				throw new IllegalArgumentException("idx > |fp|");
			} else {
				dest.data[idx] = fp.getGenerator(idx).copy(src.data[idx]);
			}
		}
	}

	/**
	 * 进行一处微小变化
	 * @param input
	 */
	public static void mutateField(Input input, int fid) {
		FormalParameter fp = input.fp;
		if (fid >= fp.size()) {
			throw new IllegalArgumentException ("fid >= |fp|");
		} else {
			input.data[fid] = fp.getGenerator(fid).nextByPolicy();
		}
	}
}
