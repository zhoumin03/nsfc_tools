package rt.test.sample;


public class SUT {
	// A complex method which contains different kinds of structures
	public void run() {
		int i, j, k;
		i = j = 1;
		if (i == 1)
			k = 1;
		else
			k = 2;
		k = 0;
		if (i > 0 && (!(k < 0) || j != 0)) {
			if (j != 0) {
				k = 1;
			}
		} else if (i == 0) {
			
		} else {
			
		}
		i = 0;
	}
}
