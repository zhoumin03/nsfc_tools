package cn.edu.tsinghua.thss.randtest.alg.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SwitchCase;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ActionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.DecisionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.utils.CfgUtils;
import cn.edu.tsinghua.thss.randtest.alg.core.target.BinaryTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.UnaryTarget;

/**
 * 问题的描述
 * @author aleck
 *
 */
public class ProblemDescription {
	public final String packagename;
	public final String classname;
	public final String methodname;
	public final MethodDeclaration method;
	
	// the control flow graph
	public final ControlFlowGraph cfg;
	// the set test target
	public final List<TestTarget> statementTargets = new ArrayList<TestTarget>();
	public final List<TestTarget> branchTargets = new ArrayList<TestTarget>();
	// the set of decision nodes
	public final List<DecisionBlock> decisions = new ArrayList<DecisionBlock>();
	// the set of action nodes
	public final List<ActionBlock> actions = new ArrayList<ActionBlock>();
	
	/**
	 * 定义被测方法中的“条件框架定义”相关语句的方法
	 * mdDefineConditionSkeleton
	 * +
	 * 定义DistanceGraph的相关语句
	 * mdDefineDistanceGraph
	 */
	private MethodDeclaration mdSetup = null;
	// 原方法中的语句个数
	private int originalStatementCount = 0;
	
	// 在Instrument完成之后，我们需要一个 Integer <--> BasicBlock 的bimap
	// 然后才可以在算法中将track(5)和bb(id=5)对应起来
	
	// all basic blocks, id -> basic block 
	private final List<BasicBlock> nodes = new ArrayList<BasicBlock>();
	// reverse map: basic block -> id
	private final Map<BasicBlock, Integer> n2i = new HashMap<BasicBlock, Integer>();
	
	public ProblemDescription(String packagename, String classname, String methodname, 
			MethodDeclaration method, ControlFlowGraph cfg) {
		if (cfg == null) {
			throw new IllegalArgumentException("cfg == null!");
		}
		this.packagename = packagename;
		this.classname = classname;
		this.methodname = methodname;
		this.method = method;
		this.cfg = cfg;
		prepare();
	}
	
	/**
	 * prepare the problem description
	 */
	private void prepare() {
		collectBlocks();
		collectTargets();
	}

	private void collectTargets() {
		// classify targets
		for (int i = 0; i < nodes.size(); i++) {
			BasicBlock bb = nodes.get(i);
			if (bb.isActionBlock() && !bb.isEmptyActionBlock()) {
				statementTargets.add(new UnaryTarget(node2id(bb)));
			} else if (bb.isDecisionBlock()) {
				DecisionBlock db = (DecisionBlock) bb;
				Statement source = db.getConditionSource();
				if (source instanceof SwitchCase) {
					BasicBlock scut = db.getBlockOnTrueBranch();
					if (scut != null) {
						branchTargets.add(new UnaryTarget(node2id(scut)));
					}
				} else {
					BasicBlock bbnext;
					bbnext = db.getBlockOnTrueBranch();
					if (bbnext != null) {
						branchTargets.add(new BinaryTarget(node2id(bb), node2id(bbnext)));
					}
					bbnext = db.getBlockOnFalseBranch();
					if (bbnext != null) {
						branchTargets.add(new BinaryTarget(node2id(bb), node2id(bbnext)));
					}
				}
			}
		}
	}

	private void collectBlocks() {
		// classify blocks
		nodes.addAll(CfgUtils.collectForwardReachableNodesFromEntry(cfg));
		for (int i = 0; i < nodes.size(); i++) {
			BasicBlock bb = nodes.get(i);
			n2i.put(bb, i);
			if (bb.isActionBlock() && !bb.isEmptyActionBlock()) {
				actions.add((ActionBlock) bb);
			}
			if (bb.isDecisionBlock()) {
				decisions.add((DecisionBlock) bb);
			}
		}
	}

	public int node2id(BasicBlock bb) {
		return n2i.get(bb);
	}
	
	public BasicBlock id2node(int id) {
		return nodes.get(id);
	}

	public int graphSize() {
		return nodes.size();
	}

	public MethodDeclaration getMethodDeclarationSetup() {
		return mdSetup;
	}

	public void setMethodDeclarationSetup(MethodDeclaration mdSetup) {
		this.mdSetup = mdSetup;
	}

	public int getOriginalStatementCount() {
		return originalStatementCount;
	}

	public void setOriginalStatementCount(int originalStatementCount) {
		this.originalStatementCount = originalStatementCount;
	}
}
