package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class ColdBranchTest {
	public static double run(double x) {
		RT.startInvocation(4861507627805938688L);
		RT.track(1);
		final double error = 1e-6;
		RT.track(2);
		if (((RT.b(0)) && (((RT.lt(0, 100 - error, x * x)) && (RT.lt(1, x * x,
				100 + error))))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			return x;
		} else {
			RT.nd(0);
			RT.track(4);
			return 0;
		}
	}
}
