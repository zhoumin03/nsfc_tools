package cn.edu.tsinghua.thss.randtest.cases.test;

import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;

public class DoubleBarrierProblemWrapper extends ProblemWrapper {
	
	@Override
	public void registerTypeDefs() {
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				BASIC(Double.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new DoubleBarrierRuntimeAssist();
	}

	@Override
	public Object invoke(Input input) {
		return DoubleBarrier.f((Double) input.data[0]);
	}

}
