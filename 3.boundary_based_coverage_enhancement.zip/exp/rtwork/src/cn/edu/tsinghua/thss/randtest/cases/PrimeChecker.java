package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;

public class PrimeChecker {

	public boolean isPrime(int n) {
		RT.startInvocation(1479481501684884480L);
		RT.track(1);
		if (((RT.b(0)) && (RT.le(0, n, 1))) && (RT.e(0))) {
			RT.pd(0);
			RT.track(3);
			return false;
		} else {
			RT.nd(0);
			RT.track(2);
			if (((RT.b(1)) && (RT.gt(0, n, 100000000))) && (RT.e(1))) {
				RT.pd(1);
				RT.track(4);
				// I don't accept large input
				return false;
			}
			RT.nd(1);
		}
		RT.track(5);
		int m = (int) Math.sqrt(n);
		boolean isPrime = true;
		RT.track(7);
		RT.track(8);
		for (int i = 2; ((RT.b(2)) && (RT.le(0, i, m))) && (RT.e(2)); i++) {
			RT.pd(2);
			RT.track(9);
			if (((RT.b(3)) && (RT.eq(0, n % i, 0))) && (RT.e(3))) {
				RT.pd(3);
				RT.track(11);
				isPrime = false;
				break;
			}
			RT.nd(3);
			RT.track(12);
		}
		RT.nd(2);
		RT.track(10);
		// force isPrime = true|false to be covered
		if (((RT.b(4)) && (RT.so(0, isPrime))) && (RT.e(4))) {
			RT.pd(4);
			RT.track(13);
			return isPrime;
		} else {
			RT.nd(4);
			RT.track(14);
			return isPrime;
		}
	}
	
}
