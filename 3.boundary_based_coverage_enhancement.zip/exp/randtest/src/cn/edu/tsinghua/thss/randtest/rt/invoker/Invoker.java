package cn.edu.tsinghua.thss.randtest.rt.invoker;


public interface Invoker {
	// the invoker should block all exceptions
	public abstract Object invoke(Input input);
	// the string representation of the result
	public abstract String invokeStr(Input input);
}
