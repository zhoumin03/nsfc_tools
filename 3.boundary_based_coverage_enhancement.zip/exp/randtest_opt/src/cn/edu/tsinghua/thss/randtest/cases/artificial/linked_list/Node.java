package cn.edu.tsinghua.thss.randtest.cases.artificial.linked_list;

public class Node {
	public int x;
	public Node next;
}
