package cov.exp.algorithm;

import java.util.Random;

import cov.exp.model.Bin;
import cov.exp.model.Bits;
import cov.exp.model.State;
import cov.exp.model.SystemModel;

/**
 * 
 * @author Min
 *
 */
public class SystemGenerator {
	public SystemModel generate(ExpParameter params, Random rand) {
		// initialize the system model
		SystemModel model = new SystemModel();
		model.params = params;
		
		// generate states
		model.numOfStates = Bits.POWER[params.nFlipflops];
		model.states = new State[model.numOfStates];
		for (int i = 0; i < model.numOfStates; i++) {
			State s = new State();
			s.flipflops = i;
			model.states[i] = s;
		}
		
		// generate transitions
		model.numOfInputPatterns = Bits.POWER[params.nInputPins];
		for (int i = 0; i < model.numOfStates; i++) {
			State s = model.states[i];
			s.transitions = new State[model.numOfInputPatterns];
			for (int j = 0; j < model.numOfInputPatterns; j++) {
				int dest = rand.nextInt(model.numOfStates);
				s.transitions[j] = model.states[dest];
			}
		}
		
		// generate bug detect states
		int numBugDetectState = (int) (model.numOfStates * params.bugDetectStateRatio);
		if (numBugDetectState < 1)
			numBugDetectState = 1;
		if (numBugDetectState > model.numOfStates)
			numBugDetectState = model.numOfStates;
		for (int i = 0; i < numBugDetectState; i++) {
			int idx;
			do {
				idx = rand.nextInt(model.numOfStates);
			} while (model.states[idx].bug);
			model.states[idx].bug = true;
		}
		
		// generate bins
		model.numOfBins = params.nBins;
		model.bins = new Bin[model.numOfBins];
		for (int i = 0; i < model.numOfBins; i++) {
			Bin b = new Bin(i);
			model.bins[i] = b;
		}
		
		// attach states to bins
		for (int i = 0; i < model.numOfStates; i++) {
			int bid = rand.nextInt(model.numOfBins);
			model.bins[bid].attach(model.states[i]);
		}
		
		// generate initial states
		do {
			int i = rand.nextInt(model.numOfStates);
			model.addInitial(model.states[i]);
		} while (model.initials.size() < model.numOfStates * params.initialStateRatio);
		return model;
	}
}
