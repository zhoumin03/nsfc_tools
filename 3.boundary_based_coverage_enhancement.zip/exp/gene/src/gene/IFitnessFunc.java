package gene;

public interface IFitnessFunc {
	public IFitnessValue eval(ISolution solution);
}
