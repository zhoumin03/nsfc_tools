package cn.edu.tsinghua.thss.randtest.alg.cfg.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jdt.core.dom.AST;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge;

/**
 * Simplify a control flow graph
 * @author aleck
 *
 */
public class CfgSimplifier {
	/**
	 * Remove unreachable blocks, for instance:
	 * ENTRY --> B1 --> B2 --> EXIT
	 *           ^
	 *           |
	 *     ENTRY-+   <<-- this node is introduced when constructing subgraph, it should be removed
	 * @param cfg
	 */
	public static void removeUnreachableBlocks(ControlFlowGraph cfg) {
		// reachable 只用来做包含判断，与顺序无关，所以可以实用Set
		Set<BasicBlock> reachable = new HashSet<BasicBlock>(
				CfgUtils.collectForwardReachableNodesFromEntry(cfg));
		for (BasicBlock bb : reachable) {
			List<Edge> ins = new ArrayList<Edge>(bb.getInEdges());
			for (Edge e : ins) {
				if (!reachable.contains(e.getSrc())) {
					bb.removeInEdge(e);
				}
			}
		}
	}

	/**
	 * AST is needed because manipulation will be performed in the graph
	 * @param ast
	 * @param cfg
	 */
	public static void removeEmptyBlocks(AST ast, ControlFlowGraph cfg) {
		boolean reduced;
		do {
			reduced = false;
			// reachable中的元素顺序可能影响到最终的CFG形态。
			// 所以使用List，而不是Set
			List<BasicBlock> reachable = 
					CfgUtils.collectForwardReachableNodesFromEntry(cfg);
			for (BasicBlock bb : reachable) {
				// only reduce empty block which is neither ENTRY nor EXIT
				// 只删除 empty-and-non-decision node
				if (bb.isEmptyActionBlock() && bb != cfg.getEntry() && bb != cfg.getExit()) {
					// action block 跟的肯定是无条件跳转
					boolean canRemove = (bb.getOutDegree() == 1);
					if (canRemove) {
						Edge out = bb.getOutEdges().get(0);
						// 1. 将入边直接链接到后继
						List<Edge> ins = new ArrayList<Edge>(bb.getInEdges());
						for (Edge in : ins) {
							in.reattach(in.getSrc(), out.getDest());
						}
						// 2. 将唯一的出边删除
						out.detach();
					}
				}
			}
		} while (reduced);
	}
}
