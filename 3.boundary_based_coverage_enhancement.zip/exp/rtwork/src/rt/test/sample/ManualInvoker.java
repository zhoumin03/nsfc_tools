package rt.test.sample;

import cn.edu.tsinghua.thss.randtest.cases.TriangleClassifierRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;

public class ManualInvoker {
	public static void main(String[] args) {
		RuntimeAssist ra = new TriangleClassifierRuntimeAssist();
		ra.setup();
		// TriangleClassifier.classify(10, 326697008, -706475321);
		System.out.println("finished");
	}
}
