package cn.edu.tsinghua.thss.randtest.cases;

import cn.edu.tsinghua.thss.randtest.rt.RT;


public class ArrayIsMonotonic {
    private static final byte INCREASING = 1;
	private static final byte DECREASING = 2;

	/**
     * Check that an array is monotonically increasing or decreasing.
     *
     * @param val Values.
     * @param dir Ordering direction.
     * @param strict Whether the order should be strict.
     * @return {@code true} if sorted, {@code false} otherwise.
     */
    public static boolean isMonotonic(Comparable[] val,
                                      byte dir,
                                      boolean strict) {
        RT.startInvocation(7976262793227439104L);
										RT.track(1);
		Comparable previous = val[0];
        final int max = val.length;
        RT.track(2);
		RT.track(3);
		for (int i = 1; ((RT.b(0)) && (RT.lt(0, i, max))) && (RT.e(0)); i++) {
            RT.pd(0);
			RT.track(4);
			final int comp;
            RT.track(6);
			if (((RT.b(1)) && (RT.eq(0, dir, INCREASING))) && (RT.e(1))) {
                RT.pd(1);
				RT.track(8);
				comp = previous.compareTo(val[i]);
                RT.track(10);
				if (((RT.b(3)) && (RT.so(0, strict))) && (RT.e(3))) {
                    RT.pd(3);
					RT.track(13);
					if (((RT.b(4)) && (RT.ge(0, comp, 0))) && (RT.e(4))) {
                        RT.pd(4);
						RT.track(17);
						return false;
                    }
					RT.nd(4);
                } else {
                    RT.nd(3);
					RT.track(14);
					if (((RT.b(5)) && (RT.gt(0, comp, 0))) && (RT.e(5))) {
                        RT.pd(5);
						RT.track(18);
						return false;
                    }
					RT.nd(5);
                }
            } else {
				RT.nd(1);
				RT.track(9);
				if (((RT.b(2)) && (RT.eq(0, dir, DECREASING))) && (RT.e(2))) {
				    RT.pd(2);
					RT.track(11);
					comp = val[i].compareTo(previous);
				    RT.track(15);
					if (((RT.b(6)) && (RT.so(0, strict))) && (RT.e(6))) {
				        RT.pd(6);
						RT.track(19);
						if (((RT.b(7)) && (RT.ge(0, comp, 0))) && (RT.e(7))) {
				            RT.pd(7);
							RT.track(22);
							return false;
				        }
						RT.nd(7);
				    } else {
				        RT.nd(6);
						RT.track(20);
						if (((RT.b(8)) && (RT.gt(0, comp, 0))) && (RT.e(8))) {
				           RT.pd(8);
							RT.track(23);
						return false;
				        }
						RT.nd(8);
				    }
				} else {
					RT.nd(2);
					RT.track(12);
					throw new RuntimeException("impossible");
				}
			}

            RT.track(16);
			previous = val[i];
			RT.track(21);
        }
        RT.nd(0);
		RT.track(5);
		return true;
    }


}
