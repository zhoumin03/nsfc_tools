package algorithm;

public class TriangleClassifier {
	public static enum TriangleType {
		INVALID_TRIANGLE,
		ACUTE_TRIANGLE,
		RIGHT_TRIANGLE,
		OBTUSE_TRIANGLE,
	}
	
	public static TriangleType classify(int a, int b, int c) {
		if (a <= 0 || b <= 0 || c <= 0) {
			return TriangleType.INVALID_TRIANGLE;
		} else {
			if (a > b) {
				int t = a;
				a = b;
				b = t;
			}
			if (b > c) {
				int t = b;
				b = c;
				c = t;
			}
			if (a > b) {
				int t = a;
				a = b;
				b = t;
			}
			if (a + b <= c) {
				return TriangleType.INVALID_TRIANGLE;
			} else {
				int delta = a * a + b * b - c * c;
				if (delta > 0) {
					return TriangleType.ACUTE_TRIANGLE;
				} else if (delta < 0) {
					return TriangleType.OBTUSE_TRIANGLE;
				} else {
					return TriangleType.RIGHT_TRIANGLE;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		TriangleType type = classify(1, 2, 3);
		System.out.println(type);
	}
}
