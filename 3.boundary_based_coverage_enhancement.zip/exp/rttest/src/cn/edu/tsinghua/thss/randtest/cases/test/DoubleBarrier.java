package cn.edu.tsinghua.thss.randtest.cases.test;

public class DoubleBarrier {
	public static int f(double x) {
		if (x <= 1) {
			return 1;
		} else {
			return 0;
		}
	}
}
