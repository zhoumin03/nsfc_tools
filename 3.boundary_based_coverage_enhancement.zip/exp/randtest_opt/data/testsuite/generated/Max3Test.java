package algorithm.test;

import algorithm.Max3;
import junit.framework.TestCase;

public class Max3Test extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T4_5, T2_4]
	public void test00() {
		assertEquals((3),
				Max3.max((Integer) (1),
						(Integer) (-28),
						(Integer) (3)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T2_4, T4_6]
	public void test01() {
		assertEquals((2147483647),
				Max3.max((Integer) (2147483647),
						(Integer) (-145343),
						(Integer) (2147483647)));
	}
	//<<case-end>>
}
