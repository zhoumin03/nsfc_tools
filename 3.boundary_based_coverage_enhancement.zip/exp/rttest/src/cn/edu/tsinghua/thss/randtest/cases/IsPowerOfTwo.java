package cn.edu.tsinghua.thss.randtest.cases;

public class IsPowerOfTwo {
	public static boolean isPowerOfTwo(long n) {
		if (n > 0) {
			if ((n & (n - 1)) == 0) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
		// return (n > 0) && ((n & (n - 1)) == 0);	
	}
}
