package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import java.util.Arrays;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractWrappedGenerator;
import cn.edu.tsinghua.thss.randtest.rt.variation.Generator;

/**
 * 生成数组的类
 * @author aleck
 *
 * @param <T>
 */
public class ArrayGenerator<T> extends AbstractWrappedGenerator<T[]> {
	private static final int MAX_ARRAY_LENGTH = 10;

	@SuppressWarnings("unchecked")
	@Override
	public T[] nextRandom() {
		int length = rand.nextInt(MAX_ARRAY_LENGTH);
		Generator<T> element = getDependentGenerator(0);
		T[] ret = (T[]) new Object[length];
		for (int i = 0; i < length; i++) {
			ret[i] = element.nextByPolicy();
		}
		return ret;
	}
	
	@Override
	public T[] nextBiasedRandom() {
		return nextRandom();
	}

	@Override
	public T[] nextNeighbour(T[] current, double scale) {
		if (current != null && current.length > 0) {
			switch (rand.nextInt(3)) {
			case 0:
				return neighbourByEditingAnElement(current);
			case 1:
				return neighbourByAddingAnElement(current);
			case 2:
				return neighbourByRemovingAnElement(current);
			}
			// impossible code
			return null;
		} else {
			return neighbourByAddingAnElement(current);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public T[][] allNeighbours(T[] current, double scale) {
		if (current != null && current.length > 0) {
			T[][] ret = (T[][]) new Object[3][];
			ret[0] = neighbourByAddingAnElement(current);
			ret[1] = neighbourByEditingAnElement(current);
			ret[2] = neighbourByRemovingAnElement(current);
			return ret;
		} else {
			T[][] ret = (T[][]) new Object[1][];
			ret[0] = neighbourByAddingAnElement(current);
			return ret;
		}
	}

	@Override
	public T[] copy(T[] origin) {
		if (origin == null) {
			return null;
		} else {
			return Arrays.copyOf(origin, origin.length);
		}
	}

	private T[] neighbourByEditingAnElement(T[] current) {
		@SuppressWarnings("unchecked")
		Generator<T> element = getDependentGenerator(0);
		T[] ret = copy(current);
		int idx = rand.nextInt(current.length);
		// the element may be null, should check it before finding the neighbor
		if (current[idx] == null)
			ret[idx] = element.nextBiasedRandom();
		else
			ret[idx] = element.nextNeighbour(current[idx], 1);
		return ret;
	}

	@SuppressWarnings("unchecked")
	private T[] neighbourByAddingAnElement(T[] current) {
		Generator<T> element = getDependentGenerator(0);
		if (current == null) {
			T[] ret = (T[]) new Object[1];
			ret[0] = element.nextByPolicy();
			return ret;
		} else {
			T[] ret = (T[]) new Object[current.length + 1];
			int idx = rand.nextInt(current.length + 1);
			T ne = element.nextByPolicy();
			for (int i = 0; i < idx; i++) {
				ret[i] = current[i];
			}
			ret[idx] = ne;
			for (int i = idx; i < current.length; i++) {
				ret[i + 1] = current[i];
			}
			return ret;
		}
	}

	@SuppressWarnings("unchecked")
	private T[] neighbourByRemovingAnElement(T[] current) {
		T[] ret = (T[]) new Object[current.length];
		int idx = rand.nextInt(current.length);
		for (int i = 0; i < idx; i++) {
			ret[i] = current[i];
		}
		for (int i = idx; i + 1 < current.length; i++) {
			ret[i] = current[i + 1];
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void registerSpecials() {
		Generator<T> generator = getDependentGenerator(0);
		registerSpecial(null);
		registerSpecial((T[]) new Object[] { generator.nextSpecial() });
	}

}
