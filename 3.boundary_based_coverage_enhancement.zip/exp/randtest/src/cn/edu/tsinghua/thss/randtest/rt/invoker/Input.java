package cn.edu.tsinghua.thss.randtest.rt.invoker;

import java.util.Arrays;

public class Input {
	public final FormalParameter fp;
	public final Object[] data;
	
	public Input(FormalParameter fp) {
		this.fp = fp;
		data = new Object[fp.size()];
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append('{');
		for (int i = 0; i < data.length; i++) {
			sb.append("P");
			sb.append(i);
			sb.append("=");
			sb.append(dataStr(data[i]));
			sb.append(";");
		}
		sb.append('}');
		return sb.toString();
	}
	
	private String dataStr(Object obj) {
		if (obj == null) {
			return "null";
		} else if (obj.getClass().isArray()) {
			return Arrays.toString((Object[]) obj);
		} else {
			return obj.toString();
		}
	}
	
}
