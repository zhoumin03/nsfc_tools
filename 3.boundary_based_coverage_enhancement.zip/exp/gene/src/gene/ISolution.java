package gene;

public class ISolution {

}
