package randtest;

import gene.ISolution;

public class TestInput extends ISolution {
	public int a;
	public int b;
	public int c;
	
	@Override
	public String toString() {
		return "[a=" + a + ", b=" + b + ", c=" + c + "]";
	}
}
