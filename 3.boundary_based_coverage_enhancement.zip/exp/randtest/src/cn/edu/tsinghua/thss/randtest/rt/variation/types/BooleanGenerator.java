package cn.edu.tsinghua.thss.randtest.rt.variation.types;

import cn.edu.tsinghua.thss.randtest.rt.variation.AbstractGenerator;

public class BooleanGenerator extends AbstractGenerator<Boolean> {

	public void registerSpecials() {
		registerSpecial(true);
		registerSpecial(false);
	}
	
	@Override
	public Boolean nextRandom() {
		return rand.nextBoolean();
	}

	@Override
	public Boolean nextBiasedRandom() {
		return nextRandom();
	}

	@Override
	public Boolean nextNeighbour(Boolean current, double scale) {
		return (current ? false : true);
	}

	@Override
	public Boolean copy(Boolean origin) {
		return Boolean.valueOf(origin.booleanValue());
	}

	@Override
	public Boolean[] allNeighbours(Boolean current, double scale) {
		return new Boolean[] { current ? false : true };
	}

}
