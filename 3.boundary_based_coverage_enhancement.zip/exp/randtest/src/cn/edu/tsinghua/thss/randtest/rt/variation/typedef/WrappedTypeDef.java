package cn.edu.tsinghua.thss.randtest.rt.variation.typedef;

import java.util.ArrayList;
import java.util.List;

public abstract class WrappedTypeDef extends TypeDef {
	
	@SuppressWarnings("rawtypes")
	protected Class top;
	protected List<TypeDef> deps = new ArrayList<TypeDef>();

	public List<TypeDef> getDependencies() {
		return deps;
	}
}
