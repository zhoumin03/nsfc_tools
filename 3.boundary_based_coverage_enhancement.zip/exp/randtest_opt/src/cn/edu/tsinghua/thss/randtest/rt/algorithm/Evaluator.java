package cn.edu.tsinghua.thss.randtest.rt.algorithm;

import java.util.List;

import cn.edu.tsinghua.thss.randtest.alg.core.target.BinaryTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.TestTarget;
import cn.edu.tsinghua.thss.randtest.alg.core.target.UnaryTarget;
import cn.edu.tsinghua.thss.randtest.rt.RT;

public class Evaluator {
	public static enum Strategy {
		NODE_ONLY,
		NODE_PLUS_DIST,
	}
	
	private final Strategy strategy;
	
	public Evaluator(Strategy strategy) {
		if (strategy == null) {
			throw new IllegalArgumentException("strategy should not be null.");
		}
		this.strategy = strategy;
	}
	
	// idx:		0		1		2		3
	// block:	b1		b2		b3		b4
	// dist:	-1		b1->~b2	b2->~b3	b3->~b4
	//                      ^-- note, ~bx means not bx
	public double evaluate(TestTarget target, List<Integer> trace, List<Double> traceDist) {
		if (target.isUnaryTarget()) {
			return evaluateUnaryTarget((UnaryTarget)target, trace, traceDist);
		} else if (target.isBinaryTarget()) {
			return evaluateBinaryTargetBoundaryDistance((BinaryTarget)target, trace, traceDist);
		} else {
			throw new RuntimeException("unknown test target type: " + target);
		}
	}

	
	/**
	 * 当前目标是BinaryTarget
	 * 
	 * 情况有3种：
	 * 1. 没有到达first
	 * 2. 到达了first，但是走了另外一条分支
	 * 3. 到达了first，并且到达了second
	 * 
	 * 注：此时，first肯定是second的一个Isolation Node
	 * @param target
	 * @param trace
	 * @param traceDist
	 * @return
	 */
	private double evaluateBinaryTargetBoundaryDistance(
			BinaryTarget target,
			List<Integer> trace, 
			List<Double> traceDist) {
		int last = -1;
				
		double bestFitness = -RT.MAX_DISTANCE;
		
		Double lastIsolationDistance = null;
		int size = trace.size();
		
		for (int i = 0; i < size; i++) {
			int current = trace.get(i);
			double isolationDistance = RT.queryIsolationDistance(target.first, current);
			double fitness;
			
			if (last == target.first) {
				if (current == target.second) {
					// 最后走的 branch: first -> second
					if (strategy == Strategy.NODE_PLUS_DIST) {
						// (-1, 0]
						fitness = traceDist.get(i);
						// always larger than 1 compared with the other target
					} else if (strategy == Strategy.NODE_ONLY) {
						fitness = 0;
					} else {
						throw new RuntimeException("unknown evaluation strategy: " + strategy);
					}
				} else {
					// 上一步已经到达 first ，但是这一步没有走 second
					if (strategy == Strategy.NODE_PLUS_DIST) {
						// (-2, -1]
						fitness = -1 + traceDist.get(i);	
					} else if (strategy == Strategy.NODE_ONLY) {
						fitness = -1;
					} else {
						throw new RuntimeException("unknown evaluation strategy: " + strategy);
					}
				}
				if (fitness > bestFitness) {
					bestFitness = fitness;
				}
			} else if (isolationDistance + 1e-6 >= RT.MAX_DISTANCE) {
				// 从当前节点已经不可达 first
				// 可以断言，lastIsolationDistance <= -1，因为上一个点肯定是一个 Isolation Point
				// 如果已经不可能到first了，则计算到first的距离
				if (lastIsolationDistance == null) {
					// 第一个点便是不可到达的点
					System.out.println(String.format("ERROR: target(%s) is unreachable from current block(%d)", target, current));
					bestFitness = -RT.MAX_DISTANCE;
					break;
				} else {
					double inEdgeDist = traceDist.get(i);
					// 多 -1 因为此时的 isoDist 计算的是到 first 的
					if (strategy == Strategy.NODE_PLUS_DIST) {
						// (-inf, -2]
						fitness = (-lastIsolationDistance) + inEdgeDist - 1;
					} else if (strategy == Strategy.NODE_ONLY) {
						// 最终希望的是 first -> second，所以 -1
						fitness = -lastIsolationDistance - 1;
					} else {
						throw new RuntimeException("unknown evaluation strategy: " + strategy);
					}
					if (fitness > bestFitness) {
						bestFitness = fitness;
					}
					break;
				}
			}
			
			lastIsolationDistance = isolationDistance;
			last = current;
		}
		if (bestFitness > 1e-6) {
			throw new RuntimeException("Fatal Error: wrong fitness: " + bestFitness);
		}
		return bestFitness;
	}

	/**
	 * 当前目标是BinaryTarget，并且在当前执行不可达时，需要计算其距离
	 * Precondition: target肯定没有被当前覆盖到
	 * 
	 * 情况有两种：
	 * 1. 没有到达first
	 * 2. 到达了first，但是走了另外一条分支
	 * 
	 * 注：此时，first肯定是second的一个Isolation Node
	 * @param target
	 * @param trace
	 * @param traceDist
	 * @return
	 */
	@SuppressWarnings("unused")
	private double evaluateBinaryTargetIsolationDistance(BinaryTarget target,
			List<Integer> trace, List<Double> traceDist) {
		int last = -1;
		
		double bestFitness = -RT.MAX_DISTANCE;
		
		Double lastIsolationDistance = null;
		int size = trace.size();
		
		for (int i = 0; i < size; i++) {
			int current = trace.get(i);
			double isolationDistance = RT.queryIsolationDistance(target.first, current);
			double fitness;
			
			if (last == target.first) {
				if (current == target.second) {
					throw new RuntimeException("the target is not expected to be covered.");
				}
				// 上一步已经到达 first ，但是这一步没有走 second
				if (strategy == Strategy.NODE_PLUS_DIST) {
					fitness = traceDist.get(i);	
				} else if (strategy == Strategy.NODE_ONLY) {
					fitness = -1;
				} else {
					throw new RuntimeException("unknown evaluation strategy: " + strategy);
				}
				if (fitness > bestFitness) {
					bestFitness = fitness;
				}
			} else if (isolationDistance + 1e-6 >= RT.MAX_DISTANCE) {
				// 可以断言，lastIsolationDistance <= -1，因为上一个点肯定是一个 Isolation Point
				// 如果已经不可能到first了，则计算到first的距离
				if (lastIsolationDistance == null) {
					// 第一个点便是不可到达的点
					System.out.println(String.format("ERROR: target(%s) is unreachable from current block(%d)", target, current));
					bestFitness = -RT.MAX_DISTANCE;
					break;
				} else {
					double inEdgeDist = traceDist.get(i);
					// 多 -1 因为此时的 isoDist 计算的是到 first 的
					if (strategy == Strategy.NODE_PLUS_DIST) {
						fitness = (-lastIsolationDistance) + (inEdgeDist + 1) - 1;
					} else if (strategy == Strategy.NODE_ONLY) {
						// 最终希望的是 first -> second，所以 -1
						fitness = -lastIsolationDistance - 1;
					} else {
						throw new RuntimeException("unknown evaluation strategy: " + strategy);
					}
					if (fitness > bestFitness) {
						bestFitness = fitness;
					}
					break;
				}
			}
			
			lastIsolationDistance = isolationDistance;
			last = current;
		}
		if (bestFitness > 1e-6) {
			throw new RuntimeException("Fatal Error: wrong fitness: " + bestFitness);
		}
		return bestFitness;
	}

	/**
	 * 当钱目标是UnaryTarget，并且在当前执行不可达时，需要计算其距离
	 * Precondition: target肯定没有被当前覆盖到
	 * @param target
	 * @param trace
	 * @param traceDist
	 * @return
	 */
	private double evaluateUnaryTarget(UnaryTarget target,
			List<Integer> trace, List<Double> traceDist) {
		int targetBlock = target.block;
		Double lastIsolationDistance = null;
		double bestFitness = -RT.MAX_DISTANCE;

		// 循环中，isolationDist增加的可能性是有的
		int size = trace.size();
		for (int i = 0; i < size; i++) {
			int blockId = trace.get(i);
			double fitness = 0;
			double isolationDistance = RT.queryIsolationDistance(targetBlock, blockId);
			
			if (isolationDistance + 1e-6 >= RT.MAX_DISTANCE) {
				// target is unreachable from this block
				// 可以断言，lastIsolationDistance <= -1，因为上一个点肯定是一个 Isolation Point
				if (lastIsolationDistance == null) {
					// 第一个点便是不可到达的点
					System.out.println(String.format("ERROR: target(%s) is unreachable from current block(%d)", target, blockId));
					bestFitness = -RT.MAX_DISTANCE;
					break;
				} else {
					double inEdgeDist = traceDist.get(i);
					if (strategy == Strategy.NODE_PLUS_DIST) {
						// 其中, inEdgeDist + 1 >= 0，表示离对的边的距离
						fitness = (-lastIsolationDistance) + (inEdgeDist + 1);
					} else if (strategy == Strategy.NODE_ONLY) {
						// -lastIsolationDistance <= -1
						fitness = -lastIsolationDistance;
					} else {
						throw new RuntimeException("unknown evaluation strategy: " + strategy);
					}
					if (fitness > bestFitness) {
						bestFitness = fitness;
					}
					break;
				}
			}
			lastIsolationDistance = isolationDistance;
		}
		if (bestFitness > 1e-6) {
			throw new RuntimeException("Fatal Error: wrong fitness: " + bestFitness);
		}
		return bestFitness;
	}
}
