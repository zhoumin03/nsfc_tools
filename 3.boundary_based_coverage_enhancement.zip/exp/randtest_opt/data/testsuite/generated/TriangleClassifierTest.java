package algorithm.test;

import junit.framework.TestCase;
import algorithm.TriangleClassifier;
import algorithm.TriangleClassifier.TriangleType;

public class TriangleClassifierTest extends TestCase {
	//--lines starts with '//--' are ommited
	//--$c: comment
	//--$$: case id
	//--$_: the expected return value
	//--$n: the n-th parameter
	//--always use with brackets to avoid ambiguity
	//--contents between <<case-begin>> and <<case-end>> are a single case
	
	//<<case-begin>>
	//#0, coverages: [T3_6, T13_15, T10_11, T8_10, T1_3, T6_8]
	public void test00() {
		assertEquals((TriangleType.ACUTE_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (1),
						(Integer) (1),
						(Integer) (1)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#1, coverages: [T13_15, T8_9, T3_5, T10_11, T1_3, T6_7]
	public void test01() {
		assertEquals((TriangleType.ACUTE_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (32),
						(Integer) (31),
						(Integer) (8)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#2, coverages: [T3_6, T8_10, T1_3, T6_8, T10_12]
	public void test02() {
		assertEquals((TriangleType.INVALID_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (2),
						(Integer) (2),
						(Integer) (10)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#3, coverages: [T1_2]
	public void test03() {
		assertEquals((TriangleType.INVALID_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (-1),
						(Integer) (1666580515),
						(Integer) (1)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#4, coverages: [T13_14, T14_16, T3_5, T10_11, T8_10, T1_3, T6_7]
	public void test04() {
		assertEquals((TriangleType.OBTUSE_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (3),
						(Integer) (2),
						(Integer) (2)));
	}
	//<<case-end>>
	//<<case-begin>>
	//#5, coverages: [T3_5, T8_10, T1_3, T6_7, T10_12]
	public void test05() {
		assertEquals((TriangleType.INVALID_TRIANGLE), 
				TriangleClassifier.classify(
						(Integer) (10),
						(Integer) (1),
						(Integer) (8)));
	}
	//<<case-end>>
}
