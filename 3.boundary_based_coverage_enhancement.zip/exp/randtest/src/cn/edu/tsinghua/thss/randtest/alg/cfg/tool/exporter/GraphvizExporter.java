package cn.edu.tsinghua.thss.randtest.alg.cfg.tool.exporter;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.eclipse.jdt.core.dom.ASTNode;

import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ActionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.BasicBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.ControlFlowGraph;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.DecisionBlock;
import cn.edu.tsinghua.thss.randtest.alg.cfg.model.Edge;
import cn.edu.tsinghua.thss.randtest.alg.cfg.tool.external.GraphVizDotFile;
import cn.edu.tsinghua.thss.randtest.alg.core.ProblemDescription;

public class GraphvizExporter {
	private Map<BasicBlock, Integer> idmap;
	private List<BasicBlock> bbs;
	
	public synchronized boolean export(
			ControlFlowGraph cfg, 
			ProblemDescription problem, 
			String filename, 
			String graphName,
			boolean convertToPng
			) throws IOException {
		idmap = new HashMap<BasicBlock, Integer>();
		bbs = new ArrayList<BasicBlock>();
		Stack<BasicBlock> visitStack = new Stack<BasicBlock>();
		
		BasicBlock entry = cfg.getEntry();
		
		// explore and collect all nodes
		idmap.put(entry, 0);
		bbs.add(entry);
		visitStack.push(entry);
		while (!visitStack.isEmpty()) {
			BasicBlock current = visitStack.pop();
			for (BasicBlock bb : current.getOutBlocks()) {
				if (idmap.containsKey(bb)) {
					// exists, ignore
				} else {
					// bb -> id
					idmap.put(bb, bbs.size());
					// id -> bb
					bbs.add(bb);
					visitStack.push(bb);
				}
			}
		}
		
		GraphVizDotFile gvdf = new GraphVizDotFile(filename);
		if (!gvdf.open()) {
			throw new IOException("can not write to dot file: " + filename);
		}
		
		// setup style
		gvdf.appendLine(
				"graph [fontsize=20 labelloc=\"t\" label=\"Control Flow Graph (" +
				graphName +
				")\" splines=true overlap=false rankdir = \"LR\"];");
		gvdf.appendLine("ratio = auto;");
		  
		// export all nodes
		for (BasicBlock bb : bbs) {
			gvdf.appendLine(formatNodeLine(cfg, problem, bb));
		}
		// export all edges
		for (BasicBlock bb : bbs) {
			for (Edge e : bb.getOutEdges()) {
				gvdf.appendLine(formatEdgeLine(problem, e));
			}
		}
		
		gvdf.close();
		idmap = null;
		bbs = null;
		
		if (convertToPng) {
			return generatePng(filename);
		} else {
			return true;
		}
	}

	private synchronized boolean generatePng(String dotFileName) {
		File dotFile = new File(dotFileName);
		if (!dotFile.exists()) {
			return false;
		}
		
		String pngFilePath = dotFile.getPath().concat(".png");
		
		// this dot command has no output
		String[] cmd = new String[] {
				"/usr/bin/dot",
				"-Tpng",
				"-o",
				pngFilePath,
				dotFile.getPath()
		};
		try {
			File workdir = new File(System.getProperty("user.dir"));
			Process proc = Runtime.getRuntime().exec(cmd, null, workdir);
			// wait for 5 sec
			long timeout = System.currentTimeMillis() + 5000;
			while (System.currentTimeMillis() < timeout) {
				try {
					proc.exitValue();
					InputStream is = proc.getInputStream();
					int c;
					while ((c = is.read()) != -1) {
						System.out.write(c);
					}
					break;
				} catch (IllegalThreadStateException e) {
					// not yet terminated
					try {
						Thread.sleep(100);
					} catch (InterruptedException ex) {
					}
				}
			}
			try {
				proc.exitValue();
				// not yet terminated, should interrupt
				proc.destroy();
			} catch (IllegalThreadStateException e) {
				// do nothing
			}
			File pngFile = new File(pngFilePath);
			return pngFile.exists();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	private String formatEdgeLine(ProblemDescription problem, Edge e) {
		int idSrc = idmap.get(e.getSrc());
		int idDest = idmap.get(e.getDest());
		String cond = "";
		if (e.isConditionalBranch()) {
			if (e.isTrueBranch()) {
				cond = "T";
			} else if (e.isFalseBranch()) {
				cond = "F";
			} else {
				throw new RuntimeException("Error: branch is neither TRUE nor FALSE");
			}
		}
		String line = "state" + idSrc + " -> state" + idDest + " [ " +
				"fontcolor=\"black\" label = \"" + cond + "\" ];";
		return line;
	}

	/**
	 * 描述BasicBlock的一行
	 * @param problem 
	 * @param bb
	 * @return
	 */
	private String formatNodeLine(ControlFlowGraph cfg, 
			ProblemDescription problem, BasicBlock bb) {
		int id = idmap.get(bb);
		
		String fgc, bgc;
		if (bb == cfg.getEntry() || bb == cfg.getExit()) {
			fgc = "white";
			bgc = "black";
		} else if (bb.isDecisionBlock()) {
			fgc = "black";
			bgc = "gray";
		} else {
			fgc = "black";
			bgc = "white";
		}
		
		String label = null;
		if (bb == cfg.getEntry()) {
			label = "ENTRY";
		} else if (bb == cfg.getExit()) {
			label = "EXIT";
		} else {
			if (bb.isActionBlock()) {
				label = statementListToString((ActionBlock) bb);
			} else {
				DecisionBlock db = (DecisionBlock) bb;
				label = db.getCondition().toString();
				if (db.sourceBackToASTNode() == null) {
					label = label + "@NULL";
				}
			}
		}

		label = "[" + (bb.isDecisionBlock() ? "decision;" : "action;") +
				"In:" + bb.getInDegree() + ";" + 
				"Out:" + bb.getOutDegree() + 
				"]\n" + label;
		
		if (problem != null) {
			try {
				int nodeid = problem.node2id(bb);
				label = "[ID=" + nodeid + "]\n" + label;
			} catch (Exception e) {
			}
		}
		
		label = makeGraphvizString(label);
		
		String shape = "rectangle";
		
		String line = "state" + id + " [ style=\"filled\" " + 
				"fillcolor=\"" + bgc + "\" fontcolor=\"" + fgc + "\" " + 
				"fontname = \"Courier New\" shape = \"" + shape + "\" " +
				"label=\"" + label + "\" ]";
		return line;
	}

	/**
	 * Make a string acceptable by GraphViz
	 * 1. replace all "\"" to "\\\""
	 * 2. replace all "\n" to "\\n"
	 * 
	 * @param statementListToString
	 * @return
	 */
	private String makeGraphvizString(String s) {
		// NOTE: always remenber that replaceAll takes a regex
		// Therefore, "\\n" and "\\\\n" will do the job.
		return s.replaceAll("\"", "\\\"").replaceAll("\\n", "\\\\n");
	}

	private String statementListToString(ActionBlock bb) {
		StringBuilder sb = new StringBuilder();
		for (ASTNode stat : bb.getStatements()) {
			sb.append(stat.toString());
		}
		return sb.toString();
	}
}
