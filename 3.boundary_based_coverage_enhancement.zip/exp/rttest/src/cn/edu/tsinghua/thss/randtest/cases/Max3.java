package cn.edu.tsinghua.thss.randtest.cases;

public class Max3 {
	public static int max(int x, int y, int z) {
		int m = x;
		if (y > m)
			m = x;
		if (z > m)
			m = z;
		return m;
	}
}
