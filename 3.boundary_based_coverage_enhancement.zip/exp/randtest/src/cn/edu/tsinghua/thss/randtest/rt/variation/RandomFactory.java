package cn.edu.tsinghua.thss.randtest.rt.variation;

import java.util.Random;

/**
 * 统一生成所有的Random
 * 是否根据时间来生成种子
 * @author aleck
 *
 */
public class RandomFactory {
	private static long GLOBAL_RANDOM_SEED = 0;
	private static Random rand = new Random(0);
	
	public static Random newInstance(boolean useFixedSeed) {
		long seed;
		if (useFixedSeed) {
			// 每次往后加上一个数，避免出现每个维度都按照相同序列生成的问题
			seed = GLOBAL_RANDOM_SEED + rand.nextInt();
		} else {
			seed = System.nanoTime();
		}
		return new Random(seed);
	}

	/**
	 * 生成一个新的实例
	 * @return
	 */
	public static Random newInstance() {
		return newInstance(true);
	}
}
