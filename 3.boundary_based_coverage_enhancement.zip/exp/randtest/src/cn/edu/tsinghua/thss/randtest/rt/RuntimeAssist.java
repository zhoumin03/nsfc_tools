package cn.edu.tsinghua.thss.randtest.rt;

/**
 * 用于初始化运行环境的类
 * @author aleck
 *
 */
public abstract class RuntimeAssist {
	public abstract void setup();
}
