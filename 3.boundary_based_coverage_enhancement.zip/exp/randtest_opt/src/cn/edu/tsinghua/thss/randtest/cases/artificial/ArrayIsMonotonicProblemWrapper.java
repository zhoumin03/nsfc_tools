package cn.edu.tsinghua.thss.randtest.cases.artificial;

import cn.edu.tsinghua.thss.randtest.cases.ArrayIsMonotonic;
import cn.edu.tsinghua.thss.randtest.cases.ArrayIsMonotonicRuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.RuntimeAssist;
import cn.edu.tsinghua.thss.randtest.rt.algorithm.wrapper.ProblemWrapper;
import cn.edu.tsinghua.thss.randtest.rt.invoker.FormalParameter;
import cn.edu.tsinghua.thss.randtest.rt.invoker.Input;
import cn.edu.tsinghua.thss.randtest.rt.variation.GeneratorFactory;
import cn.edu.tsinghua.thss.randtest.rt.variation.typedef.ArrayType;
import cn.edu.tsinghua.thss.randtest.rt.variation.types.ArrayGenerator;

public class ArrayIsMonotonicProblemWrapper extends ProblemWrapper {

	@Override
	public void registerTypeDefs() {
		GeneratorFactory.registerDependentInstance(new ArrayGenerator<Integer>(), 
				ArrayType.class, 
				BASIC(Integer.class)
				);
	}

	@Override
	public Object invoke(Input input) {
		Comparable[] val = toArray(Comparable.class, (Object[]) input.data[0]); 
		Byte dir = (Byte) input.data[1];
		Boolean strict = (Boolean) input.data[2];
		return ArrayIsMonotonic.isMonotonic(val, dir, strict);
	}

	@Override
	protected FormalParameter createFormalParameter() {
		FormalParameter fp = new FormalParameter();
		fp.setParameters(
				DEP(ArrayType.class, BASIC(Integer.class)),
				BASIC(Byte.class),
				BASIC(Boolean.class)
				);
		return fp;
	}

	@Override
	protected RuntimeAssist createRuntimeAssist() {
		return new ArrayIsMonotonicRuntimeAssist();
	}

}
