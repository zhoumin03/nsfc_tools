package cov.exp.model.maybe;

public class Just<T> extends Maybe<T> {
	public T value;
	
	public Just(T v) {
		value = v;
	}

	public static<T> Just<T> create(T v) {
		return new Just<T>(v);
	}

	@Override
	public String toString() {
		return "" + value;
	}

}
