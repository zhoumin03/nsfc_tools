package cn.edu.tsinghua.thss.randtest.cases;

import java.util.Arrays;
import cn.edu.tsinghua.thss.randtest.rt.RT;

public class BubbleSort {
	public static void sort(int[] a) {
		RT.startInvocation(2205097497476983808L);
		RT.track(1);
		RT.track(2);
		for (int i = 0; ((RT.b(0)) && (RT.lt(0, i, a.length))) && (RT.e(0)); i++) {
			RT.pd(0);
			RT.track(3);
			RT.track(5);
			for (int j = 1; ((RT.b(1)) && (RT.lt(0, i + j, a.length))) && (RT.e(1)); j++) {
				RT.pd(1);
				RT.track(6);
				if (((RT.b(2)) && (RT.gt(0, a[i], a[i + j]))) && (RT.e(2))) {
					RT.pd(2);
					RT.track(8);
					int temp = a[i];
					a[i] = a[i + j];
					a[i + j] = temp;
				}
				RT.nd(2);
				RT.track(9);
			}
			RT.nd(1);
			RT.track(7);
		}
		RT.nd(0);
	}
	
	public static void main(String[] args) {
		Integer[] b = new Integer[10];
		int[] a = new int[] {3, 2, 35, 6, 2, 5};
		// a = b;
		BubbleSort.sort(a);
		System.out.println(Arrays.toString(a));
	}
}
